﻿using System.Linq;
using System.Web.Mvc;
using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Repositories;

namespace CheckTrack.Controllers
{
    public class QuotationController : Controller
    {
        // GET: Quotation

        private CategoryRepository _category;
        private QuotationRepository _quotation;
        

        public QuotationController()
        {
            _category = new CategoryRepository(new DBContent());
        }

        public ActionResult ucQuotation()
        {
            ViewBag.Title = "Quotation";
            return View();
        }
        public ActionResult ucQuotationTnC()
        {
            ViewBag.Title = "Quotation TnC";
            return View();
        }
        public ActionResult ucQuotationActivity()
        {
            ViewBag.Title = "Quotation Activity";
            return View();
        }
        public ActionResult ucQuotationAdmin()
        {
            ViewBag.Title = "Quotation Admin";
            return View();
        }
        public ActionResult ucQuotationCC2()
        {
            ViewBag.Title = "Quotation CC2";
            return View();
        }
        public ActionResult ucQuotationDetail2()
        {
            ViewBag.Title = "Quotation Detail2";
            return View();
        }
        public ActionResult ucQuotationMovements()
        {
            ViewBag.Title = "Quotation Movements";
            return View();
        }

        public ActionResult ucQuotationRegister()
        {
            return View();
        }


        public ActionResult insertPrcode(QTHeaderReq QtheaderReq, int Id)
        {
            if (Id == 0)
            {
                _category.Insertprj(QtheaderReq);
                ViewBag.Message = "Insert product...";
            }
            else
            {
            }
            return View();
        }
        //public ActionResult insertPrcode(string prcode,string qty)
        //{
        //    PrcodeReq objpr = new PrcodeReq();
        //    objpr.prcode = prcode;
        //    objpr.qty = qty;
        //   // objpr.qta_id = "0";
        //    var obj = _category.Insertprj(objpr);
        //    return Json("objpr", JsonRequestBehavior.AllowGet);
        //}


        public ActionResult GetAllProductcodelist()
        {
            var result = _category.GetAllProductcodelist().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public ActionResult ucQuotation(int? enqM_Id)
        {
              //List Enquiry
            var itemsEnquiryMaster = _category.ListEnquiry().ToList();
            if (itemsEnquiryMaster != null)
            {
                ViewBag.dataEnquiry = itemsEnquiryMaster;
            }

            //List company code
            var itemsCompany = _category.ListCompanyCode().ToList();
            if (itemsCompany != null)
            {
                ViewBag.datacode = itemsCompany;
            }

            //List contact person
            var itemsContact = _category.ListContact().ToList();
            if (itemsContact != null)
            {
                ViewBag.datacontact = itemsContact;
            }

            //List Designation
            var itemDesignation = _category.Listdesignation().ToList();
            if (itemDesignation != null)
            {
                ViewBag.datadesignation = itemDesignation;
            }

            //if (enqM_Id != null)
            //{
            //    var result = _common.ListEnquiry(enqM_Id).FirstOrDefault();
            //    if (result != null)
            //    {
            //        return View(result);
            //    }
            //    else
            //    {
            //        ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
            //        return View();
            //    }
            //} 
            return View();
        }

        [HttpPost]
        public JsonResult ucQuotationList(string enqM_RegNo)
        {
            if (enqM_RegNo != null)
            {
                var result = _category.ListEnquirylist(enqM_RegNo).ToList();
                if (result != null)
                {
                    QTHeaderResp obj = new QTHeaderResp();
                    obj.enqM_RegDate = result[0].enqM_RegDate;
                    obj.enqM_ProjectName = result[0].enqM_ProjectName;
                    obj.enqM_TenderNo = result[0].enqM_TenderNo;
                    obj.enqM_TenderDate = result[0].enqM_TenderDate;
                    obj.enqM_ClosingDate = result[0].enqM_ClosingDate;




                    return Json(obj);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return Json(null);
                }
            }
            else
            {
                return Json(null);
            }
        }

        public ActionResult ucQuotationMovementsJson()
        {
            var result = _category.Listquotation().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        // public ActionResult ucQuotation(EnquiryReq enquiryReq, int enqM_Id)
        // {
        //     if (enqM_Id == 0)
        //     {   
        //         _quotation.InsertQuotationHdr(quotationHdrReq);
        //         ViewBag.Message = "Insert Quotation...";
        //     }
        //     else
        //     {
        //         _quotation.UpdateQuotationHdr(quotationHdrResp);
        //         ViewBag.Message = "Update Quotation...";
        //     }
        //     //return View();
        //     return RedirectToAction("ucEnquiryMaster", "Enquiry");
        // }


        //[HttpPost]

        //public ActionResult ucQuotation(QTHeaderReq qtheaderreq, int qtM_Id)
        //{
        //    if (qtM_Id == 0)
        //    {
        //        _quotation.InsertQuotationHdr(qtheaderreq);
        //        ViewBag.Message = "Insert Enquiry...";
        //    }
        //    else
        //    {

        //    }
        //    return View();
        //   // return RedirectToAction("ucQuotation", "Quotation");
        //}

    }
}