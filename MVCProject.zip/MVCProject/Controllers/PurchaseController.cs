﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Repositories;
using System.Linq;
using System.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Web;

namespace MVCProject.Controllers
{
    public class PurchaseController : Controller
    {
        private PurchaseRepository _purchase;
        public PurchaseController()
        {
            _purchase = new PurchaseRepository(new DBContent());
        }

        //Page : Purchase Master
        public ActionResult Index()
        {
            return View();
        }

        //Page : Purchase Master
        public ViewResult ucPO()
        {
            ViewBag.title = "Purchase Order";
            return View();
        }

        //Page : Purchase Order Tax
        public ViewResult ucPurchaseOrderTax()
        {
            ViewBag.title = "Purchase OrderTax";
            return View();
        }

        //Page : Purchase Requisition
        public ViewResult ucPR()
        {
            ViewBag.title = "Purchase Requisition";
            return View();
        }

        //Page : Purchase Register
        public ViewResult ucPORegister()
        {
            ViewBag.title = "Purchase Register";
            return View();
        }

        //Page : Purchase Order
        //[HttpGet]
        //public ActionResult ucPOMaster()
        //{
        //    //For Vendor LList
        //    var itemsVendor = _purchase.ListVendor().ToList();
        //    if (itemsVendor != null)
        //    {
        //        ViewBag.dataVendor = itemsVendor;
        //    }
        //}

        //Method - To extract all rows 
        //Page : WorkOrder Register
        public ActionResult ucPurchaseRegisterJson(int? p1, DateTime? d1, DateTime? d2)
        {
            var result = _purchase.GetPurchaseRegister(p1, d1, d2).ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        

    }
}