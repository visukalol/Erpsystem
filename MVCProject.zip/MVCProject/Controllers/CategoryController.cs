﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Repositories;
using System.Linq;
using System.Web.Mvc;
using System;
using System.Reflection;
using System.Collections.Generic;

namespace MVCProject.Controllers
{
    public class CategoryController : Controller
    {
        //Variable Declaration of Repository
        private CategoryRepository _category;

        //Initialiaze of Repository
        public CategoryController()
        {
            _category = new CategoryRepository(new DBContent());
        }

        //Method - Default Index Page of controller 
        //Page: Category
        public ActionResult Index()
        {
            return View();
        }

        //Method - Default view 
        //Page: Category Register
        public ActionResult ucCategoryRegister()
        {
            return View();
        }

        //Method - To extract all rows 
        //Page : Category Register
        public ActionResult ucCategoryRegisterJson()
        {
            var result = _category.GetAllCategory().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ucCategoryMaster()
        {
            return View();
        }

        //Method - Master Page view by selection from Registration Page 
        //Page: Category Master
        [HttpGet]
        public ActionResult ucCategoryMaster(int? catM_Id)
        {
            if (catM_Id != null)
            {
                var result = _category.GetAllCategory().Where(i => i.catM_Id == catM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucCategoryMaster(
            string catM_Name,string catM_Description,
            string catM_Code,int catM_Id)
        {
            CategoryReq obj = new CategoryReq();
            obj.catM_Name = catM_Name;
            obj.catM_Description = catM_Description;
            obj.catM_Code = catM_Code;
            obj.catM_Id = catM_Id;
            if (catM_Id == 0)
            {
                _category.InsertCategory(obj);
            }
            else
            {
                _category.UpdateCategory(obj);
            }
            ViewBag.Message = "Insert Category...";
            return View();            
        }
        [HttpPost]
        public ActionResult ucCategoryDeleteMaster(string catM_Name, string catM_Description, string catM_Code, int catM_Id)
        {
            CategoryReq obj = new CategoryReq();
            obj.catM_Name = catM_Name;
            obj.catM_Description = catM_Description;
            obj.catM_Code = catM_Code;
            obj.catM_Id = catM_Id;
            if (catM_Id == 0)
            {
              //  _category.InsertCategory(obj);
            }
            else
            {
                _category.DeleteCategory(obj);
            }
            ViewBag.Message = "Insert Category...";
            return View();
        }
        //[HttpPost]
        //public ActionResult ucCategoryMaster(GetCategoryResp categoryResp, int catM_Id, string flag)
        //{
        //    if (flag == "UPDATE")
        //    {
        //        var obj = _category.UpdateCategory(categoryResp);
        //        ViewBag.Message = "Update Category...";
        //    }
        //    else if (flag == "DELETE")
        //    {
        //        var obj = _category.DeleteCategory(categoryResp);
        //        ViewBag.Message = "Delete Category...";
        //    }
        //    return View();
        //}
    }
}