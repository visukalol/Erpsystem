﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Repositories;
using System.Linq;
using System.Web.Mvc;

namespace CheckTrack.Controllers
{
    public class VendorController : Controller
    {
        private VendorRepository _vendor;

        //Initialiaze of Repository
        public VendorController()
        {
            _vendor = new VendorRepository(new DBContent());
        }

        //Vendor Master : Start    

        //Method - Master Page view
        //Page: Vendor Master
        [HttpGet]
        public ActionResult ucVendorMaster(int? vndM_Id)
        {
            if (vndM_Id != null)
            {
                var result = _vendor.GetAllVendor().Where(i => i.vndM_Id == vndM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                }
            }
            else
            {
                return View();
            }

        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucVendorMaster(VendorReq vendorReq, int vndM_Id)
        {
            if (vndM_Id == 0)
            {
                _vendor.InsertVendor(vendorReq);
                ViewBag.Message = "Insert Vendor...";
            }
            else
            {
                _vendor.UpdateVendor(vendorReq);
                ViewBag.Message = "Update Vendor...";
            }
            return RedirectToAction("ucVendorRegisterJson");
        }

        [HttpPost]
        public ActionResult ucVendorDeleteMaster(VendorReq vendorReq, int vndM_Id)
        {
            if (vndM_Id == 0)
            {
            }
            else
            {
                _vendor.DeleteVendor(vendorReq);
                ViewBag.Message = "Delete Vendor...";
            }
            return View();
        }

        public ActionResult ucVendorLocationJson(int? Cid, string flag)
        {
            if (Cid != null)
            {
                var result = _vendor.GetAllVendorLocation(Cid, flag).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _vendor.GetAllVendorLocation(0, "0").ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ucVendorRawMaterialJson(int? Cid)
        {
            if (Cid != null)
            {
                var result = _vendor.GetAllVendorRawMaterial(Cid).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _vendor.GetAllVendorRawMaterial(0).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ucVendorLocationContactJson(int? Cid)
        {
            if (Cid != null)
            {
                var result = _vendor.GetAllVendorLocationContact(Cid).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _vendor.GetAllVendorLocationContact(0).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }
        //Client Location based on Company Code
        //Company code derive from Json Function and pass to Controller Method 
        public ActionResult ucVendorBankJson(int? Cid, string flag)
        {
            if (Cid != null)
            {
                var result = _vendor.VendorBankMaster(Cid, flag).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _vendor.VendorBankMaster(0, "").ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        //Page - Vendor Master : End

        //Page - Vendor Register : Start
        public ActionResult ucVendorRegister()
        {
            ViewBag.title = "Vendor Register";
            return View();
        }
        public ActionResult ucVendorRegisterJson()
        {
            var result = _vendor.GetAllVendor().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        //Page - Vendor Register : End


        public ActionResult ucVendorARCMaster()
        {
            ViewBag.title = "VendorAR Master";
            return View();
        }
        public ActionResult ucVendorLocation()
        {
            ViewBag.title = "Vendor Location";
            return View();
        }
    }
}