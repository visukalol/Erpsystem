﻿using MVCProject.Models;
using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCProject.Controllers
{
    public class LoginController : Controller
    {
        private LoginRepository _login;
        private StaffRepository _staff;
        public LoginController()
        {
            _login = new LoginRepository(new ChecnTrack_MainDB());
            _staff = new StaffRepository(new ChecnTrack_MainDB());
        }

        // GET: Login
        [HttpGet]
        public ActionResult Login()
        {
            var itemLocation = _login.forlogin().ToList();
            if (itemLocation != null)
            {
                ViewBag.Location = itemLocation;
            }
            return View();
        }

        [HttpPost]
        public ActionResult Login(Login login)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = _login.CheckLogin(login.UserName,login.Password,Convert.ToInt32(login.Location));
                    if (result != null)
                    {
                        if (result.stfM_isActive == true)
                        {
                            Session["username"] = login.UserName;
                            Session["rolename"] = result.RoleName;
                            ViewBag.username = login.UserName;
                            return RedirectToAction("Dashboard");
                        }
                    }
                    
                    
                }
                var itemLocation = _login.forlogin().ToList();
                if (itemLocation != null)
                {
                    ViewBag.Location = itemLocation;
                }

                return View();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            }

        // GET: Login
        public ActionResult Register()
        {
            return View();
        }
        public ActionResult logout()
        {
            Session["username"] = "";
            Session["rolename"] = "";
            return RedirectToAction("Login");
        }
        public ActionResult Dashboard()
        {

            return View();
        }

        //register:post
        [HttpPost]
        public ActionResult Register(StaffReq staffReq)
        {
            _staff.InsertStaff(staffReq);
            return View();

        }

        
    }
}