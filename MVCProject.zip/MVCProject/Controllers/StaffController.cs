﻿using MVCProject.Models.ResponseModel;
using MVCProject.Models.RequestModel;
using MVCProject.Repositories;
using System.Linq;
using System.Web.Mvc;
using MVCProject.Models.DBModel;
using System.ComponentModel.DataAnnotations;

namespace CheckTrack.Controllers
{
    public class StaffController : Controller
    {

        //Variable Declaration of Repository
        private StaffRepository _staff;
        private CommonRepository _common;

        //Initialiaze of Repository
        public StaffController()
        {
            _staff = new StaffRepository(new ChecnTrack_MainDB());
            _common = new CommonRepository(new DBContent(), new ChecnTrack_MainDB());
        }

        //Method - Default Index Page of controller 
        //Page: Category
        public ActionResult Index()
        {
            return View();
        }

        //Method - Default view 
        //Page: Register
        public ActionResult ucStaffRegister()
        {
            return View();
        }

        //Method - To extract all rows 
        //Page : Category Register
        public ActionResult ucStaffRegisterJson()
        {
            var result = _staff.GetAllStaff().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ucStaffMaster()
        {
            return View();
        }

        //Method - Master Page view by selection from Registration Page 
        //Page: Category Master
        [HttpGet]
        public ActionResult ucStaffMaster(int? stfM_Id)
        {
            var itemsRole = _common.ListAllRoles().ToList();
            if (itemsRole != null)
            {
                ViewBag.dataRole = itemsRole;
            }

            //location 
            var itemsLocation = _common.ListLocation().ToList();
            if (itemsLocation != null)
            {
                ViewBag.Location = itemsLocation;
            }

            if (stfM_Id != null)
            {
                var result = _staff.GetAllStaff().Where(i => i.stfM_Id == stfM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    //GetStaffResp obj = new GetStaffResp();
                    return View();
                }
            }
            else
            {
                //GetStaffResp obj = new GetStaffResp();
   
                return View();
            }
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucStaffMaster(StaffReq staffReq, int stfM_Id)
        {
            if (stfM_Id == 0)
            {
                _staff.InsertStaff(staffReq);
                ViewBag.Message = "Insert Staff...";
            }
            else
            {
                _staff.UpdateStaff(staffReq);
                ViewBag.Message = "Update Staff...";
            }

            //location 
            var itemsLocation = _common.ListLocation().ToList();
            if (itemsLocation != null)
            {
                ViewBag.Location = itemsLocation;
            }
            return View();
        }

        [HttpPost]
        public ActionResult ucStaffDeleteMaster(StaffReq staffReq, int stfM_Id)
        {
            if (stfM_Id == 0)
            {
            }
            else
            {
                _staff.DeleteStaff(staffReq);
                ViewBag.Message = "Delete Staff...";
            }
            return View();
        }

        //Method : Update Record
        //[HttpGet]
        //public JsonResult RoleListJson()
        //{
        //var result = _staff.GetAllRoles().ToList();
        //    return Json(result, JsonRequestBehavior.AllowGet);
        //}
    }
}