﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCProject.Models;
using MVCProject.Repositories;
using MVCProject.Models.DBModel;

namespace CheckTrack.Controllers
{
    public class InvoiceController : Controller
    {

        //Variable Declaration of Repository
        private InvoiceRepository _invoice;
        //private CommonRepository _common;

        //Initialiaze of Repository
        public InvoiceController()
        {
            _invoice = new InvoiceRepository(new DBContent());
            //_common = new CommonRepository(new DBContent(), new ChecnTrack_MainDB());
        }

        // GET: Invoice
        public ActionResult ucInvoice()
        {
            ViewBag.Title = "Excise Invoice Entry";

            return View();
        }
        public ActionResult ucInvoiceDetails()
        {
            ViewBag.Title = "";
            return View();
        }
        public ActionResult ucInvoiceGST()
        {
            ViewBag.Title = "GST Invoice";
            return View();
        }
        public ActionResult ucInvoiceGSTDetails()
        {
            ViewBag.Title = "";
            return View();
        }
        public ActionResult ucInvoiceRegister()
        {
            return View();
        }

        //Method - To extract all rows 
        //Page : WorkOrder Register
        public ActionResult ucInvoiceRegisterJson(int? p1, DateTime? d1, DateTime? d2, int? p2)
        {
            var result = _invoice.GetInvoiceRegister(p1, d1, d2, p2).ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ucInvoiceTax()
        {
            ViewBag.Title = "Invoice Entry [Trading]";
            return View();
        }
        public ActionResult ucInvoiceTaxDetails()
        {
            ViewBag.Title = "";
            return View();
        }
        //for Invoice Report
        //public ActionResult] ucInvoiceReport()
        //{
        //    ViewBag.Title = "";
        //    return View();
        //}
    }
}