﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Repositories;
using System.Linq;
using System.Web.Mvc;
using System;
using System.Reflection;
using System.Collections.Generic;

namespace CheckTrack.Controllers
{
    public class RawMaterialController : Controller
    {
        //Variable Declaration of Repository
        private RawMaterialRepository _rawMaterial;
        private CommonRepository _common;

        //Initialiaze of Repository
        public RawMaterialController()
        {
            _rawMaterial = new RawMaterialRepository(new DBContent());
            _common = new CommonRepository(new DBContent(), new ChecnTrack_MainDB());
        }

        //Method - Default Index Page of controller 
        //Page: RawMaterial
        public ActionResult Index()
        {
            return View();
        }

        //Method - Default view 
        //Page: RawMaterial Register
        public ActionResult ucRawMaterialRegister()
        {
            return View();
        }

        //Method - Default view 
        //Page: RawMaterialCategory Register
        public ActionResult ucRawMaterialCategoryRegister()
        {
            return View();
        }

        //Page: RawMaterialCategory Register
        public ActionResult ucRawMaterialCategoryRegisterJson()
        {
            var result = _rawMaterial.GetRawCategory().ToList();
            if (result != null)
            { ViewBag.Message = "Page Refreshed..."; }
            else
            {
                { ViewBag.Message = "Page not refreshed...Kindly check again..."; }
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //Method - Default view 
        //Page: RawMaterial Category Master
        public ActionResult ucRawMaterialCategoryMaster(int? rawC_Id)
        {
            var itemsCat1 = _common.ListCat1().ToList();
            if (itemsCat1 != null)
            {
                ViewBag.dataCat1 = itemsCat1;
            }
            var itemsCat2 = _common.ListCat2().ToList();
            if (itemsCat2 != null)
            {
                ViewBag.dataCat2 = itemsCat2;
            }
            var itemsCat3 = _common.ListCat3().ToList();
            if (itemsCat3 != null)
            {
                ViewBag.dataCat3 = itemsCat3;
            }
            var itemsCat4 = _common.ListCat4().ToList();
            if (itemsCat4 != null)
            {
                ViewBag.dataCat4 = itemsCat4;
            }
            var itemsCat5 = _common.ListCat5().ToList();
            if (itemsCat5 != null)
            {
                ViewBag.dataCat5 = itemsCat5;
            }
            return View();
        }

        //Method - To extract all rows 
        //Page : RawMaterial Register
        public ActionResult ucRawMaterialRegisterJson()
        {
            var result = _rawMaterial.GetAllRawMaterial().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult RawMaterialCategoryJson()
        {
            var result = _rawMaterial.GetRawCategoryInfo().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ucRawMaterialMaster()
        {
            return View();
        }

        //Method - Master Page view by selection from Registration Page
        //Page: RawMaterial Master
        [HttpGet]
        public ActionResult ucRawMaterialMaster(int? rawM_Id)
        {
            var itemsCategory = _common.ListCategory().ToList();
            if (itemsCategory != null)
            {
                ViewBag.dataCategory = itemsCategory;
            }
            
            var types = new List<PricingMethod>();
            types.Add(new PricingMethod() { Value = "0", Text = "Select a Type" });
            types.Add(new PricingMethod() { Value = "1", Text = "LIFO" });
            types.Add(new PricingMethod() { Value = "2", Text = "FIFO" });
            ViewBag.PriceMethod = types;

            if (rawM_Id != null)
            {
                var result = _rawMaterial.GetAllRawMaterial().Where(i => i.rawM_Id == rawM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucRawMaterialMaster(RawMaterialReq rawmaterialReq, int rawM_Id)
        {
            if (rawM_Id == 0)
            {
                _rawMaterial.InsertRawMaterial(rawmaterialReq);
                ViewBag.Message = "Insert RawMaterial...";
            }
            else
            {
                _rawMaterial.UpdateRawMaterial(rawmaterialReq);
                ViewBag.Message = "Update RawMaterial...";
            }
            return RedirectToAction("ucRawMaterialMaster", "RawMaterial");
        }

        [HttpPost]
        public ActionResult ucRawMaterialDeleteMaster(RawMaterialReq rawmaterialReq, int rawM_Id)
        {
            if (rawM_Id == 0)
            {
            }
            else
            {
                _rawMaterial.DeleteRawMaterial(rawmaterialReq);
                ViewBag.Message = "Delete RawMaterial...";
            }
            return View();
        }

        //Method : Insert a new record in table 
        //Page: RawMaterialCategory Master
        [HttpPost]
        public ActionResult ucRawMaterialCategoryMaster(RawMaterialCategoryReq rawMaterialCategoryReq, int raw_Id)
        {
            if (raw_Id == 0)
            {
                _rawMaterial.InsertRawMaterialCategory(rawMaterialCategoryReq);
                ViewBag.Message = "Insert RawMaterial...";
            }
            else
            {
            }
            return Json("success");
        }
    }
}