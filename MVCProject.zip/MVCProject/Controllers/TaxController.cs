﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CheckTrack.Controllers
{
    public class TaxController : Controller
    {
        //Variable Declaration of Repository
        private TaxRepository _tax;

        //Initialiaze of Repository
        public TaxController()
        {
            _tax = new TaxRepository(new DBContent());
        }

        //Method - Default Index Page of controller 
        //Page: Tax

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ucTaxEntryRegister()
        {
            return View();
        }

        [HttpGet]
        public ActionResult ucTaxEntryMaster(int? txM_Id)
        {
            var itemsFormName = _tax.Listtaxdetail().ToList();
            if (itemsFormName != null)
            {
                ViewBag.dataFormName = itemsFormName;
            }

            if (txM_Id != null)
            {
                var result = _tax.GetAllTax().Where(i => i.txM_Id == txM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                }
            }
            else
            {
                return View();
            }
            
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucTaxEntryMaster(GetTaxEntryResp gettaxentryResp, int txM_Id)
        {
            if (txM_Id == 0)
            {
                _tax.InsertTax(gettaxentryResp);
                ViewBag.Message = "Insert Distributor...";
            }
            else
            {
                _tax.UpdateTax(gettaxentryResp);
                ViewBag.Message = "Update Distributor...";
            }
            //return View();
            return RedirectToAction("ucTaxJson", "Tax");
        }

        [HttpPost]
        public ActionResult ucTaxEntryDeleteMaster(GetTaxEntryResp taxentryReq, int txM_Id)
        {
            if (txM_Id == 0)
            {
                //_distributor.InsertDistributor(distributorReq);
                //ViewBag.Message = "Insert Category...";
            }
            else
            {
                _tax.DeleteTax(taxentryReq);
                ViewBag.Message = "Delete Distributor...";
            }
            return View();
        }

        //Code for : Formname List
        [HttpGet]
        //public JsonResult FormnameJson()
        //{
        //    var result = _tax.ListFormname().ToList();
        //    return Json(result, JsonRequestBehavior.AllowGet);
        //}

        //Method - To extract all rows 
        //Page : Tax Register
        public ActionResult ucTaxJson()
        {
            var result = _tax.GetAllTax().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}