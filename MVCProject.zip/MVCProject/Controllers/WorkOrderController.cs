﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Repositories;
using System.Linq;
using System.Web.Mvc;
using System.Collections.Generic;
using System;

namespace CheckTrack.Controllers
{
    public class WorkOrderController : Controller
    {
        //Variable Declaration of Repository
        private WorkOrderRepository _workOrder;
        private CommonRepository _common;

        //Initialiaze of Repository
        public WorkOrderController()
        {
            _workOrder = new WorkOrderRepository(new DBContent());
            _common = new CommonRepository(new DBContent(), new ChecnTrack_MainDB());
        }

        //Method - Default Index Page of controller 
        //Page: WorkOrder
        public ActionResult Index()
        {
            return View();
        }

        //Method - Default view 
        //Page: WorkOrder Register
        public ActionResult ucWorkOrderRegister()
        {
            var itemsUnits = _common.ListUnits().ToList();
            if (itemsUnits != null)
            {
                ViewBag.dataUnits = itemsUnits;
            }

            return View();
        }

        //Method - To extract all rows 
        //Page : WorkOrder Register
        public ActionResult ucWorkOrderRegisterJson(int? p1, DateTime? d1, DateTime? d2, int? p2)
        {
            var result = _workOrder.GetAllWorkOrder(p1,d1,d2,p2).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ucWorkOrderMaster()
        {
            return View();
        }

        //Method - Master Page view by selection from Registration Page 
        //Page: WorkOrder Master
        [HttpGet]
        public ActionResult ucWorkOrderMaster(int? woM_Id)
        {
            var itemsBuyer = _common.ListBuyer().ToList();
            if (itemsBuyer != null)
            {
                ViewBag.dataBuyer = itemsBuyer;
            }

            var itemsConsignee = _common.ListConsignee().ToList();
            if (itemsConsignee != null)
            {
                ViewBag.dataConsignee = itemsConsignee;
            }

            var itemsBuyerLocation = _common.ListBuyerLocation().ToList();
            if (itemsBuyerLocation != null)
            {
                ViewBag.dataBuyerLocation = itemsBuyerLocation;
            }

            var itemsConsigneeLocation = _common.ListConsigneeLocation().ToList();
            if (itemsConsigneeLocation != null)
            {
                ViewBag.dataConsigneeLocation = itemsConsigneeLocation;
            }

            var itemsDispatchMode = _common.ListDispatchMode().ToList();
            if (itemsDispatchMode != null)
            {
                ViewBag.dataDispatchMode = itemsDispatchMode;
            }

            var itemsUnits = _common.ListUnits().ToList();
            if (itemsUnits != null)
            {
                ViewBag.dataUnits = itemsUnits;
            }

            if (woM_Id != null)
            {    
                var result = _workOrder.GetWorkOrderMaster(woM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }
        //Method : Insert a new record in table 
        //Page: WorkOrder Master
        [HttpPost]
        public ActionResult ucWorkOrderMaster(
            WorkOrderInfoReq workOrderInfoReq, 
            WorkOrderDetailInfoReq workOrderDetailInfoReq, 
            WorkOrderDetailTaxInfoReq workOrderDetailTaxInfoReq, 
            workOrderTnCInfoReq workOrderTnCInfoReq)
        {
            var objH = _workOrder.InsertWorkOrder(workOrderInfoReq);
            var objD = _workOrder.InsertWorkOrderDetailInfo(workOrderDetailInfoReq);
            var objT = _workOrder.InsertWorkOrderDetailTaxInfo(workOrderDetailTaxInfoReq);
            var objC = _workOrder.InsertworkOrderTnCInfo(workOrderTnCInfoReq);
            ViewBag.Message = "Insert WorkOrder...";
            return View();
        }

        //[HttpPost]
        public ActionResult ucWorkOrderMaster(WorkOrderInfoResp workOrderInfoResp)
        {
            var obj = _workOrder.UpdateWorkOrder(workOrderInfoResp);
            ViewBag.Message = "Update WorkOrder...";
            return View();
        }

        //Method - To extract all rows 
        //Page : WorkOrder Item
        public ActionResult ListWorkOrderItemJson(int? Cid)
        {
            if (Cid != null)
            { 
                var result = _workOrder.GetWorkOrderDetailInfo().ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _workOrder.GetWorkOrderDetailInfo().ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        //Method - To extract all rows 
        //Page : WorkOrder Item Tax
        public ActionResult ListWorkOrderItemTaxJson(int? Cid)
        {
            if (Cid != null)
            {
                var result = _workOrder.GetWorkOrderDetailTaxInfo(Cid).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _workOrder.GetWorkOrderDetailTaxInfo(0).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        //Method - To extract all rows 
        //Page : WorkOrder TnC
        public ActionResult ListWorkOrderTnCJson(int? Cid)
        {
            if (Cid != null)
            {
                var result = _workOrder.GetTnCInfoOnWorkOrderId(Cid).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _workOrder.GetTnCInfoOnWorkOrderId(0).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        //List for Buyer
        [HttpGet]
        public JsonResult ListBuyerJson()
        {
            var result = _workOrder.ListBuyer().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }        

        //List for Location
        [HttpGet]
        public JsonResult ListBuyerLocationJson()
        {
            var result = _workOrder.ListBuyerLocation().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //List for Consignee
        [HttpGet]
        public JsonResult ListConsigneeJson()
        {
            var result = _workOrder.ListConsignee().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //List for Consignee Location
        [HttpGet]
        public JsonResult ListConsigneeLocationJson()
        {
            var result = _workOrder.ListConsigneeLocation().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //List for Units
        [HttpGet]
        public JsonResult ListUnitsJson()
        {
            var result = _common.ListUnits().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //List for Dispatch Modes
        [HttpGet]
        public JsonResult ListDispatchModeJson()
        {
            var result = _common.ListDispatchMode().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}