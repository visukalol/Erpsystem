﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Repositories;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using MVCProject.Models.ResponseModel;

namespace MVCProject.Controllers
{
    public class DistributorController : Controller
    {
        // Connection string
        private DistributorRepository _distributor;


        public DistributorController()
        {
            _distributor = new DistributorRepository(new DBContent());
        }

        //Default Page : Master Page        
        public ActionResult ucDistributorMaster()
        {
            return View();
        }

        //Method - Master Page view by selection from Registration Page 
        //Page: Distributor Master
        [HttpGet]
        public ActionResult ucDistributorMaster(int? dstM_Id)
        {
            if (dstM_Id != null)
            {
                var result = _distributor.GetAllDistributor().Where(i => i.dstM_Id == dstM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucDistributorMaster(DistributorReq distributorReq, int dstM_Id)
        {
            if (dstM_Id == 0)
            {
                _distributor.InsertDistributor(distributorReq);
                ViewBag.Message = "Insert Distributor...";
            }
            else
            {
                _distributor.UpdateDistributor(distributorReq);
                ViewBag.Message = "Update Distributor...";
            }            
            return View();
        }

        [HttpPost]
        public ActionResult ucDistributorDeleteMaster(DistributorReq distributorReq, int dstM_Id)
        {
            if (dstM_Id == 0)
            {
                //_distributor.InsertDistributor(distributorReq);
                //ViewBag.Message = "Insert Category...";
            }
            else
            {
                _distributor.DeleteDistributor(distributorReq);
                ViewBag.Message = "Delete Distributor...";
            }
            return View();
        }

        //[HttpPost]
        //public ActionResult ucDistributorMaster(GetDistributorResp distributorResp, string flag)
        //{
        //    if (flag == "UPDATE")
        //    {
        //        var obj = _distributor.UpdateDistributor(distributorResp);
        //        ViewBag.Message = "Update Distributor...";
        //    }
        //    else if (flag == "DELETE")
        //    {
        //        var obj = _distributor.DeleteDistributor(distributorResp);
        //        ViewBag.Message = "Delete Distributor...";
        //    }
        //    return View();
        //}

        // Page: Distributor Register
        public ActionResult ucDistributorRegister()
        {
            return View();
        }

        // Page : Distributor Register
        public ActionResult ucDistributorRegisterJson()
        {
            var result = _distributor.GetAllDistributor().ToList();
            if (result != null)
            { ViewBag.Message = "Page Refreshed..."; }
            else
            {
                { ViewBag.Message = "Page not refreshed...Kindly check again..."; }
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //Client Location based on Company Code
        //Company code derive from Json Function and pass to Controller Method 
        public ActionResult ucDistributorBankJson(int? Cid, string flag)
        {
            if (Cid != null)
            {
                var result = _distributor.DistributorBankMaster(Cid, flag).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _distributor.DistributorBankMaster(0, "").ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }
    }
}