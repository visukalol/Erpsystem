﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Repositories;
using System.Linq;
using System.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Web;
using MVCProject.Models.ResponseModel;

namespace MVCProject.Controllers
{
    public class ClientController : Controller
    {
        //Variable Declaration of Repository
        private ClientRepository _client;

        //        string temp = Request.QueryString["externalstring"];

        //Initialiaze of Repository
        public ClientController()
        {
            _client = new ClientRepository(new DBContent());
        }

        //Method - Default Index Page of controller 
        //Page: Client
        public ActionResult Index()
        {
            return View();
        }

        //Method - Default view 
        //Page: Client Register
        public ActionResult ucClientRegister()
        {
            return View();
        }

        //Method - To extract all rows 
        //Page : Register Page
        public ActionResult ucClientRegisterJson()
        {
            var result = _client.GetAllClient().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //Default Page : Master Page
        //[HttpGet]
        public ActionResult ucClientMaster()
        {
            return View();
        }

        //Method - Master Page view by selection from Registration Page 
        //Page: Master
        [HttpGet]
        public ActionResult ucClientMaster(int? clM_Id)
        {
            if (clM_Id != null)
            {
                var result = _client.GetAllClient().Where(i => i.clM_Id == clM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                };
            }
            else
            {
                var result = _client.GetAllClient().FirstOrDefault();
                return View(result); 
            }
        }

        //Client Location based on Company Code
        //Company code derive from Json Function and pass to Controller Method 
        public ActionResult ucClientLocationJson(int? Cid, string flag)
        {
            if (Cid != null)
            {
                var result = _client.GetAllClientLocations(Cid, flag).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _client.GetAllClientLocations(0, "0").ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            //return Json(null, JsonRequestBehavior.AllowGet);
        }

        //Client Contacts based on Location Code        
        public ActionResult ucClientContactsJson(int? Cid)
        {
            if (Cid != null)
            {
                var result = _client.GetClientContacts(Cid).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _client.GetClientContacts(0).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        //Client Location based on Company Code
        //Company code derive from Json Function and pass to Controller Method 
        public ActionResult ucClientBankJson(int? Cid, string flag)
        {
            if (Cid != null)
            {
                var result = _client.ClientBankMaster(Cid, flag).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _client.ClientBankMaster(0, "").ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucClientMaster(ClientReq clientReq, int clM_Id)
        {
            if (clM_Id == 0)
            {
                _client.InsertClient(clientReq);
                ViewBag.Message = "Insert Client...";
            }
            else
            {
                _client.UpdateClient(clientReq);
                ViewBag.Message = "Update Client...";
            }
            return View("ucClientRegister");
            //return RedirectToAction("ucClientRegister", "Client");
        }

        [HttpPost]
        public ActionResult ucClientDeleteMaster(ClientReq clientReq, int clM_Id)
        {
            if (clM_Id == 0)
            {
                //_client.InsertClient(clientReq);
                //ViewBag.Message = "Insert Category...";
            }
            else
            {
                _client.DeleteClient(clientReq);
                ViewBag.Message = "Delete Client...";
            }
            return View();
        }

    }
}