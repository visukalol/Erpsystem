﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Repositories;
using System.Linq;
using System.Web.Mvc;

namespace CheckTrack.Controllers
{
    public class ItemController : Controller
    {
        //Variable Declaration of Repository
        private ItemRepository _item;
        private CommonRepository _common;

        //Initialiaze of Repository
        public ItemController()
        {
            _item = new ItemRepository(new DBContent());
            _common = new CommonRepository(new DBContent(), new ChecnTrack_MainDB());
        }

        //Method - Default Index Page of controller 
        //Page: Category
        public ActionResult Index()
        {
            return View();
        }

        //Default view - Item Register        
        public ActionResult ucItemRegister()
        {
            var itemsCategory = _common.ListCategory().ToList();
            if (itemsCategory != null)
            {
                ViewBag.dataCategory = itemsCategory;
            }

            var itemsProductGroup = _common.ListProductGroup().ToList();
            if (itemsProductGroup != null)
            {
                ViewBag.dataProductGroup = itemsProductGroup;
            }

            return View();
        }
        //Default View - Item Master
        public ActionResult ucItemMaster()
        {
            return View();
        }
        //Default View - Item Group
        public ActionResult ucItemGroupRegister()
        {
            return View();
        }

        //Method - To extract all rows 
        //Page : Item Register
        public ActionResult ucItemRegisterJson(int? p1, int? p2)
        {
            var result = _item.GetAllItemCatGrp(p1, p2).ToList();
            if (result != null)
            { ViewBag.Message = "Page Refreshed..."; }
            else
            {
                { ViewBag.Message = "Page not refreshed...Kindly check again..."; }
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //Method - To extract all rows 
        //Page : Item Group Register
        public ActionResult ucItemGroupRegisterJson()
        {
            var result = _item.GetItemGroupItem().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //Method - Master Page view by selection from Registration Page 
        //Page: Master
        [HttpGet]
        public ActionResult ucItemMaster(int? itM_ID)
        {
            var itemsCategory = _common.ListCategory().ToList();
            if (itemsCategory != null)
            {
                ViewBag.dataCategory = itemsCategory;
            }

            var itemsProductGroup = _common.ListProductGroup().ToList();
            if (itemsProductGroup != null)
            {
                ViewBag.dataProductGroup = itemsProductGroup;
            }

            var itemsCertificate = _common.ListCertificate().ToList();
            if (itemsCertificate != null)
            {
                ViewBag.dataCertificate = itemsCertificate;
            }

            var itemsMaterial = _common.ListMaterial().ToList();
            if (itemsMaterial != null)
            {
                ViewBag.dataMaterial = itemsMaterial;
            }


            if (itM_ID != null)
            {
                var result = _item.GetAllItem().Where(i => i.itM_ID == itM_ID).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucItemMaster(ItemReq itemReq, int itM_Id)
        {
            if (itM_Id == 0)
            {
                _item.InsertItem(itemReq);
                ViewBag.Message = "Insert Item...";
            }
            else
            {
                _item.UpdateItem(itemReq);
                ViewBag.Message = "Update Item...";
            }
            var itemsCategory = _common.ListCategory().ToList();
            if (itemsCategory != null)
            {
                ViewBag.dataCategory = itemsCategory;
            }

            var itemsProductGroup = _common.ListProductGroup().ToList();
            if (itemsProductGroup != null)
            {
                ViewBag.dataProductGroup = itemsProductGroup;
            }

            var itemsCertificate = _common.ListCertificate().ToList();
            if (itemsCertificate != null)
            {
                ViewBag.dataCertificate = itemsCertificate;
            }

            var itemsMaterial = _common.ListMaterial().ToList();
            if (itemsMaterial != null)
            {
                ViewBag.dataMaterial = itemsMaterial;
            }

            return View();
        }

        [HttpPost]
        public ActionResult ucItemDeleteMaster(ItemReq itemReq, int itM_Id)
        {
            if (itM_Id == 0)
            {
            }
            else
            {
                _item.DeleteItem(itemReq);
                ViewBag.Message = "Delete Item...";
            }
            return View();
        }
    }
}