﻿using MVCProject.Models.DBModel;
using MVCProject.Repositories;
using System;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CheckTrack.Controllers
{
    public class EnquiryController : Controller
    {
        //Variable Declaration of Repository
        private EnquiryRepository _enquiry;
        private CommonRepository _common;

        //Initialiaze of Repository
        public EnquiryController()
        {
            _enquiry = new EnquiryRepository(new DBContent());
            _common = new CommonRepository(new DBContent(), new ChecnTrack_MainDB());
        }

        // GET: Enquiry Assign To
        public ActionResult ucEnquiryAssignTo()
        {
            //List Department
            var itemsDepartment = _common.ListDepartment().ToList();
            if (itemsDepartment != null)
            {
                ViewBag.dataDepartment = itemsDepartment;
            }

            //List Staff
            var itemsStaff = _common.ListStaff().ToList();
            if (itemsStaff != null)
            {
                ViewBag.dataStaff = itemsStaff;
            }

            //List Registration No
            var itemsRegNo = _common.ListRegNo().ToList();
            if (itemsRegNo != null)
            {
                ViewBag.dataRegNo = itemsRegNo;
            }


            ViewBag.title = "Enquiry Assign To";
            return View();
        }

        //list for Department wise Staff
        [HttpGet]
        public ActionResult ucEnquiryAssignToList(string stfM_Name)
        {
            //List Staff
            var itemsStaff = _common.ListDepartmentStaff(stfM_Name).ToList();
           
            return Json(itemsStaff, JsonRequestBehavior.AllowGet);
        }


        //Method : Insert a new record in table 
        //Page: Enquiry AssignTo Master
        [HttpPost]
        public ActionResult ucEnquiryAssignTo(EnquiryAssignInfoReq enquiryassigninfoReq, int enqA_Id)
        {
            if (enqA_Id == 0)
            {
                _enquiry.InsertEnquiryAssign(enquiryassigninfoReq);
                ViewBag.Message = "Insert Enquiry Assign To...";
            }
            else
            {
                //_enquiry.UpdateEnquiry(EnquiryActivityInfoReq);
                //ViewBag.Message = "Update Enquiry...";
            }
            return View();
        }

        // Method : Enquiry Assign Register data
        // Page : Enquiry Register
        public ActionResult ucEnquiryAssignToJson()
        {
            var result = _enquiry.GetAllAssignEnquiry().ToList();
            if (result != null)
            { ViewBag.Message = "Page Refreshed..."; }
            else
            {
                { ViewBag.Message = "Page not refreshed...Kindly check again..."; }
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //GET: Enquiry DivertTo
        [HttpGet]
        public ActionResult ucEnquiryDivertTo()
        {

            //List Registration No
            var itemsRegNo = _common.ListRegNo().ToList();
            if (itemsRegNo != null)
            {
                ViewBag.dataRegNo = itemsRegNo;
            }

            //List Distributor
            var itemsDistributor = _common.ListDistributor().ToList();
            if (itemsDistributor != null)
            {
                ViewBag.dataDistributor = itemsDistributor;
            }

            ViewBag.title = "Enquiry Divert To";
            return View();
        }

        //Method : Insert a new record in table 
        //Page: Enquiry DivertTo
        [HttpPost]
        public ActionResult ucEnquiryDivertTo(EnquiryDivertInfoReq EnquirydivertinfoReq)
        {
            var obj = _enquiry.InsertEnquiryDivert(EnquirydivertinfoReq);
            ViewBag.Message = "Insert Enquiry with status Divert To...";
            return View();
        }

        // Method : Enquiry Divert Register data
        // Page : Enquiry Divert To
        public ActionResult ucEnquiryDiverttoJson()
        {
            var result = _enquiry.GetAllDivertEnquiry().ToList();
            if (result != null)
            { ViewBag.Message = "Page Refreshed..."; }
            else
            {
                { ViewBag.Message = "Page not refreshed...Kindly check again..."; }
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        //Method - Master Page view by selection from Registration Page 
        //Page: Category Master
        [HttpGet]
        public ActionResult ucEnquiryMaster(int? enqM_Id)
        {
            //List Clients  
            var itemsClients = _common.ListBuyer().ToList();
            if (itemsClients != null)
            {
                ViewBag.dataClients = itemsClients;
            }

            //List Location
            //var p = "5299";
            var itemsLocation = _common.ListBuyerLocation().ToList();
            if (itemsLocation != null)
            {
                ViewBag.dataLocation = itemsLocation;
            }

            //List Designation
            var itemsDesignation = _common.ListDesignation().ToList();
            if (itemsDesignation != null)
            {
                ViewBag.dataDesignation = itemsDesignation;
            }

            //List Contacts
          var p1 = 5299;
            var itemsContacts = _common.ListContacts(p1).ToList();
            if (itemsContacts != null)
            {
                ViewBag.dataContacts = itemsContacts;
            }

            // List Status
            var itemsStatus = _common.ListStatus().ToList();
            if (itemsStatus != null)
            {
                ViewBag.dataStatus = itemsStatus;
            }

            // List Project Name
            var itemsProject = _common.ListProject().ToList();
            if (itemsProject != null)
            {
                ViewBag.dataProject = itemsProject;
            }

            //List Product Group
            var itemsProduct = _common.ListProductgroup().ToList();
            if (itemsProduct != null)
            {
                ViewBag.itemsProduct = itemsProduct;
            }

            if (enqM_Id != null)
            {
                var result = _enquiry.GetEnquiryOnId(enqM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucEnquiryMaster(EnquiryReq enquiryReq, int enqM_Id)
        {
            if (enqM_Id == 0)
            {
                _enquiry.InsertEnquiry(enquiryReq);
                ViewBag.Message = "Insert Enquiry...";
            }
            else
            {
                _enquiry.UpdateEnquiry(enquiryReq);
                ViewBag.Message = "Update Enquiry...";
            }
            //return View();
            return RedirectToAction("ucEnquiryMaster", "Enquiry");
        }

        [HttpPost]
        public ActionResult ucEnquiryDeleteMaster(EnquiryReq enquiryReq, int enqM_Id)
        {
            if (enqM_Id == 0)
            {
            }
            else
            {
                _enquiry.DeleteEnquiry(enquiryReq);
                ViewBag.Message = "Delete Enquiry...";
            }
            return View();
        }

        public ActionResult ucEnquiryMovements()
        {
            ViewBag.title = "Enquiry Movements";
            return View();
        }

        public ActionResult ucEnquiryMovementsJson(string p1, int? p2, DateTime? d1, DateTime? d2)
        {
            var result = _enquiry.EnquiryInfoOnStatus(p1, p2, d1, d2).ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ucEnquirynQuotationReports()
        {
            ViewBag.title = "Enquiry Quotation Reports";
            return View();
        }

        //GET: Enquiry Regret
        public ActionResult ucEnquiryRegret()
        {

            //List Registration No
            var itemsRegNo = _common.ListRegNo().ToList();
            if (itemsRegNo != null)
            {
                ViewBag.dataRegNo = itemsRegNo;
            }

            ViewBag.title = "Enquiry Regret";
            return View();
        }

        //Method : Insert a new record in table 
        //Page: Enquiry Regret
        [HttpPost]
        public ActionResult ucEnquiryRegret(EnquiryRegretInfoReq EnquiryRegretinfoReq)
        {
            var obj = _enquiry.InsertEnquiryRegret(EnquiryRegretinfoReq);
            ViewBag.Message = "Insert Enquiry with status Regret...";
            return View();
        }

        // Method : Enquiry Regret Register data
        // Page : Enquiry Regret
        public ActionResult ucEnquiryRegretJson()
        {
            var result = _enquiry.GetAllRegretEnquiry().ToList();
            if (result != null)
            { ViewBag.Message = "Page Refreshed..."; }
            else
            {
                { ViewBag.Message = "Page not refreshed...Kindly check again..."; }
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ucEnquiryRegister()
        {
            ViewBag.title = "Enquiry Register";
            return View();
        }

        //public ActionResult ucEnquiryRegisterJson(int? p1, bool? p2, DateTime? p3, DateTime? p4)
        public ActionResult ucEnquiryRegisterJson(int? p1, DateTime? p3, DateTime? p4)
        {
            var result = _enquiry.GetAllEnquiry(p1, p3, p4).ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

       

        //[HttpPost]
        //public ActionResult ucDesignations(DesignationsReq designationsReq)
        //{
        //    var obj = _enquiry.InsertDesignation(designationsReq);
        //    ViewBag.Message = "Insert Designation...";
        //    return View();

        //}
    }
}