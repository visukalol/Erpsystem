﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Repositories;

namespace CheckTrack.Controllers
{
    public class TnCController : Controller
    {
        //Variable Declaration of Repository
        private TnCRepository _tnc;

        //Initialiaze of Repository
        public TnCController()
        {
            _tnc = new TnCRepository(new ChecnTrack_MainDB());
        }

        //Method - Default Index Page of controller 
        //Page: TnC

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ucTnCMaster()
        {
            return View();
        }

        [HttpGet]
        public ActionResult ucTnCMaster(int? tncM_Id)
        {
            if (tncM_Id != null)
            {
                var result = _tnc.GetAllTnCMaster().Where(i => i.tncM_Id == tncM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucTnCMaster(TnCMasterReq tncReq, int tncM_Id)
        {
            if (tncM_Id == 0)
            {
                _tnc.InsertTnCMaster(tncReq);
                ViewBag.Message = "Insert TnC...";
            }
            else
            {
                _tnc.UpdateTnCMaster(tncReq);
                ViewBag.Message = "Update TnC...";
            }
            return View();
        }

        [HttpPost]
        public ActionResult ucTnCDeleteMaster(TnCMasterReq tncReq, int tncM_Id)
        {
            if (tncM_Id == 0)
            {
            }
            else
            {
                _tnc.DeleteTnCMaster(tncReq);
                ViewBag.Message = "Delete TnC...";
            }
            return View();
        }

        //Method - To extract all rows 
        //Page : TnC Register
        public ActionResult ucTnCRegisterJson()
        {
            var result = _tnc.GetAllTnCMaster().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        
        public ActionResult ucTnCRegister()
        {
            return View();
        }

        //TnC Description based on TnC Code
        //TnC code derive from Json Function and pass to Controller Method 
        public ActionResult ucTnCDescriptionJson(int? Cid)
        {
            //int QS = Convert.ToInt32(Request.QueryString[0].ToString());
            if (Cid != null)
            {
                var result = _tnc.GetTnCDescriptionInfo(Cid).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _tnc.GetTnCDescriptionInfo(0).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }
    }
}