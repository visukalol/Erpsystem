﻿using MVCProject.Models.DBModel;
using MVCProject.Models.ResponseModel.Location;
using MVCProject.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCProject.Controllers
{
    public class LocationController : Controller
    {
        //Variable Declaration of Repository
        private LocationRepository _location;

        //Initialiaze of Repository
        public LocationController()
        {
            _location = new LocationRepository(new DBContent());
        }

        // GET: Location
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ucLocationMaster()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ucLocationMaster(
            string LcM_clMId, string LcM_Code, string LcM_Address, 
            string LcM_City, string LcM_Country, string LcM_Zip, 
            string LcM_State, string LcM_ECC, string LcM_ER, 
            string LcM_CST, string LcM_VAT, string LcM_GSTiN, 
            string LCM_Flag)
        {
            LocationResp obj = new LocationResp();
            obj.LcM_clMId = Convert.ToInt32(LcM_clMId);
            obj.LcM_Address = LcM_Address;
            obj.LcM_City = LcM_City;
            obj.LcM_Code = LcM_Code;
            obj.LcM_Country = LcM_Country;
            obj.LcM_CST = LcM_CST;
            obj.LcM_ECC = LcM_ECC;
            obj.LcM_GSTiN = LcM_GSTiN;
            obj.LcM_State = LcM_State;
            obj.LcM_VAT = LcM_VAT;
            obj.LcM_Zip = LcM_Zip;
            obj.LCM_Flag = LCM_Flag;
            _location.Insertlocation(obj);
            ViewBag.Message = "Insert Location...";
            return View();
        }
    }
}