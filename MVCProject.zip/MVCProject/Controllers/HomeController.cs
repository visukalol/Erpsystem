﻿using MVCProject.Models.DBModel;
using MVCProject.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCProject.Controllers
{
    public class HomeController : Controller
    {
        private LoginRepository _login;
        public HomeController()
        {
            _login = new LoginRepository(new ChecnTrack_MainDB());
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult AboutJson()
        {
            var result = _login.CheckLogin("", "",0);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}