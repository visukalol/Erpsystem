﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Repositories;
using System.Linq;
using System.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Web;
using MVCProject.Models.ResponseModel.Location;

namespace CheckTrack.Controllers
{
    public class GeneralController : Controller
    {

        //Variable Declaration of Repository
        private FactoryRepository _factory;
        //Variable Declaration of Repository
        private CompanyRepository _company;
        private CommonRepository _common;

        //Initialiaze of Repository
        public GeneralController()
        {
            _factory = new FactoryRepository(new DBContent());
            _company = new CompanyRepository(new ChecnTrack_MainDB(),new DBContent());
            _common = new CommonRepository(new DBContent(), new ChecnTrack_MainDB());
        }

        public ActionResult ucBOMMaster()
        {
            ViewBag.title = "BOM Master";
            return View();
        }

        public ActionResult ucCertificates()
        {
            ViewBag.title = "Certificates";
            return View();
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucCertificates(CertificateReq certificateReq)
        {
            var obj = _factory.InsertCertificate(certificateReq);
            ViewBag.Message = "Insert Certificate...";
            return View();
        }

        [HttpPost]
        public ActionResult ucCertificates(CertificateResp certificateResp, string flag)
        {
            if (flag == "UPDATE")
            {
                var obj = _factory.UpdateCertificate(certificateResp);
                ViewBag.Message = "Update Certificate...";
            }
            else if (flag == "DELETE")
            {
                //var obj = _factory.DeleteCertificate(certificateResp);
                //ViewBag.Message = "Delete Certificate...";
            }
            return View();
        }

        public ActionResult ucGeneralItems()
        {
            ViewBag.title = "General Items";
            return View();
        }

        //Factory Master : Main Start        

        //Method - Master Page view 
        //Page: Factory Master
        [HttpGet]
        public ActionResult ucFactoryMaster(int? gfM_Id)
        {
            var result = _factory.GetAllFactory().Where(i => i.gfM_Id == gfM_Id).FirstOrDefault();
            //var result = _factory.GetAllFactory().FirstOrDefault();
            if (result != null)
            {
                return View(result);
            }
            else
            {
                ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                return View();
            }
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucFactoryMaster(FactoryReq factoryReq, int gfM_Id)
        {
            if (gfM_Id == 0)
            {
                _factory.InsertFactory(factoryReq);
                ViewBag.Message = "Insert Factory...";
            }
            else
            {
                _factory.UpdateFactory(factoryReq);
                ViewBag.Message = "Update Factory...";
            }
            return View();
        }

        //Page - Factory Register : Start
        public ActionResult ucFactoryRegister()
        {
            ViewBag.title = "Factory Register";
            return View();
        }
        public ActionResult ucFactoryRegisterJson()
        {
            var result = _factory.GetAllFactory().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        //Page - Factory Register : End

        //Factory Master : Main End

        //Godown Master : MAIN Start        

        //Method - Master Page view 
        //Page: Godown Master
        [HttpGet]
        public ActionResult ucGodownMaster(int? gfM_Id)
        {
            //var result = _factory.GetAllGodown().FirstOrDefault();
            var result = _factory.GetAllGodown().Where(i => i.gfM_Id == gfM_Id).FirstOrDefault();
            if (result != null)
            {
                return View(result);
            }
            else
            {
                ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                return View();
            }
        }

        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucGodownMaster(GodownReq godownReq, int gfM_Id)
        {
            if (gfM_Id == 0)
            {
                _factory.InsertGodown(godownReq);
                ViewBag.Message = "Insert Godown...";
            }
            else
            {
                _factory.UpdateGodown(godownReq);
                ViewBag.Message = "Update Godown...";
            }
            return View();
        }        

        //Page - Factory Register : Start
        public ActionResult ucGodownRegister()
        {
            ViewBag.title = "Godown Register";
            return View();
        }

        public ActionResult ucGodownRegisterJson()
        {
            var result = _factory.GetAllGodown().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        //Page - Factory Register : End

        //Factory Master : Main End

        //Company Master : Start    

        public ActionResult ucCompanyMaster()
        {
            return View();
        }

        //Method - Master Page view
        //Page: Company Master
        [HttpGet]
        public ActionResult ucCompanyMaster(int? cmpM_Id)
        {
            var itemsFY = _common.ListFinanceYear().ToList();
            if (itemsFY != null)
            {
                ViewBag.dataFY = itemsFY;
            }

            if (cmpM_Id != null)
            {
                var result = _company.GetAllCompany().Where(i => i.cmpM_Id == cmpM_Id).FirstOrDefault();
                if (result != null)
                {
                    return View(result);
                }
                else
                {
                    ViewBag.Message = "No Record found...Either you are Top of the Record or Last at the Record..";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }
        //Method : Insert a new record in table 
        //Page: Category Master
        [HttpPost]
        public ActionResult ucCompanyMaster(CompanyReq companyReq, int cmpM_Id)
        {
            if (cmpM_Id == 0)
            {
                _company.InsertCompany(companyReq);
                ViewBag.Message = "Insert Company...";
            }
            else
            {
                _company.UpdateCompany(companyReq);
                ViewBag.Message = "Update Company...";
            }
            var itemsFY = _common.ListFinanceYear().ToList();
            if (itemsFY != null)
            {
                ViewBag.dataFY = itemsFY;
            }

            return View();
        }        

        public ActionResult ucCompanyLocationJson(int? Cid, string flag)
        {
            if (Cid != null)
            {
                var result = _company.GetCompanyLocation(Cid, flag).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _company.GetCompanyLocation(0, "").ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ucCompanyBankMasterJson(int? Cid, string flag)
        {
            if (Cid != null)
            {
                var result = _company.CompanyBankMaster(Cid, flag).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _company.CompanyBankMaster(0, "").ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        //Company Master : End

        //Page - Company Register : Start
        public ActionResult ucCompanyRegister()
        {
            ViewBag.title = "Company Register";
            return View();
        }
        public ActionResult ucCompanyRegisterJson()
        {
            var result = _company.GetAllCompany().ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        //Page - Company Register : End

        public ActionResult ucLocations()
        {
            ViewBag.title = "Locations";
            return View();
        }
        public ActionResult ucDesignations()
        {
            ViewBag.title = "Designations";
            return View();
        }

        //For insert Designation
        [HttpPost]
        public ActionResult ucDesignations(DesignationReq designationReq)
        {
            //if 
            //{
                _factory.InsertDesignation(designationReq);
                ViewBag.Message = "Insert Distributor...";
            //}
            //else
            //{
            //    //_factory.UpdateDesignation(designationResp);
            //    //ViewBag.Message = "Update Distributor...";
            //}
            return View();
        }

        //For delete Designation
        //[HttpPost]
        //public ActionResult ucDistributorDeleteMaster(DistributorReq distributorReq, int dstM_Id)
        //{
        //    if (dstM_Id == 0)
        //    {
        //        //_distributor.InsertDistributor(distributorReq);
        //        //ViewBag.Message = "Insert Category...";
        //    }
        //    else
        //    {
        //        _factory.DeleteDistributor(distributorReq);
        //        ViewBag.Message = "Delete Distributor...";
        //    }
        //    return View();
        //}


        public ActionResult ucDesignationsreg()
        {
            var result = _factory.getalldesignation().ToList();
            if (result != null)
            { ViewBag.Message = "Page Refreshed..."; }
            else
            {
                { ViewBag.Message = "Page not refreshed...Kindly check again..."; }
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        ////Method : Insert a new record in table 
        ////Page: Category Master
        //[HttpPost]
        //public ActionResult ucDesignationMaster(DesignationReq designationReq)
        //{
        //    var obj = _factory.InsertDesignation(designationReq);
        //    ViewBag.Message = "Insert Designation...";
        //    return View();
        //}

        //[HttpPost]
        //public ActionResult ucDesignationMaster(DesignationResp designationResp, string flag)
        //{
        //    if (flag == "UPDATE")
        //    {
        //        var obj = _factory.UpdateDesignation(designationResp);
        //        ViewBag.Message = "Update Designation...";
        //    }
        //    else if (flag == "DELETE")
        //    {
        //        //var obj = _factory.DeleteDesignation(designationReq);
        //        //ViewBag.Message = "Delete Designation...";
        //    }
        //    return View();
        //}

        public ActionResult ucBankMaster()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ucBankMaster(
            int clM_Id, int bnkM_Id, string bnkM_Name, string bnkM_Branch, string bnkM_IFSC,
            string bnkM_AcNo, string bnkM_AcName, string bnkM_MICR,
            string bnkM_Flag )
        {
            ClientBankMasterResp obj = new ClientBankMasterResp();
            obj.clM_Id = Convert.ToInt32(clM_Id);
            obj.bnkM_Id = bnkM_Id;
            obj.bnkM_Name = bnkM_Name;
            obj.bnkM_Branch = bnkM_Branch;
            obj.bnkM_IFSC = bnkM_IFSC;
            obj.bnkM_AcNo = bnkM_AcNo;
            obj.bnkM_AcName = bnkM_AcName;
            obj.bnkM_MICR = bnkM_MICR;
            obj.bnkM_Flag = bnkM_Flag;
            _factory.InsertBankMaster(obj);
            ViewBag.Message = "Insert Bank Master...";
            return View();
        }

        public ActionResult ucContactMaster()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ucContactMaster(
            int vcntM_vLcMId, string vcntM_ContactPerson, string vcntM_Mobile, string vcntM_Resi,
            string vcntM_eMail, string vcntM_Phone1, string vcntM_Phone2,
            string vcntM_FAX, string vcntM_Flag)
        {
            LocationContactsResp obj = new LocationContactsResp();
            obj.vcntM_vLcMId = Convert.ToInt32(vcntM_vLcMId);
            obj.vcntM_ContactPerson = vcntM_ContactPerson;
            obj.vcntM_Mobile = vcntM_Mobile;
            obj.vcntM_Resi = vcntM_Resi;
            obj.vcntM_eMail = vcntM_eMail;
            obj.vcntM_Phone1 = vcntM_Phone1;
            obj.vcntM_Phone2 = vcntM_Phone2;
            obj.vcntM_FAX = vcntM_FAX;
            obj.vcntM_Flag = vcntM_Flag;
            _factory.InsertContactMaster(obj);
            ViewBag.Message = "Insert Contact Master...";
            return View();
        }

        //Client Location based on Company Code
        //Company code derive from Json Function and pass to Controller Method 
        public ActionResult ucGodownBankJson(int? Cid, string flag)
        {
            if (Cid != null)
            {
                var result = _factory.GodownBankMaster(Cid, flag).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _factory.GodownBankMaster(0, "").ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        //Client Location based on Company Code
        //Company code derive from Json Function and pass to Controller Method 
        public ActionResult ucFactoryBankJson(int? Cid, string flag)
        {
            if (Cid != null)
            {
                var result = _factory.FactoryBankMaster(Cid, flag).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _factory.FactoryBankMaster(0, "").ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        //Client Location based on Company Code
        //Company code derive from Json Function and pass to Controller Method 
        public ActionResult ucLocationContactsJson(int? Cid, string flag)
        {
            if (Cid != null)
            {
                var result = _factory.LocationContactMaster(Cid, flag).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = _factory.LocationContactMaster(0, "").ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }
    }
}