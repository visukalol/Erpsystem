﻿function load() {
    debugger;
    $('#tableID').DataTable({
        "ajax": {
            "url": "/Home/AboutJson",
            "dataSrc": function (json) {
                debugger;
                return json;
            }
        },
        'columns': [{ 'data': 'UserName' }],
    });
}


function validation(value,type,id) {
    if (type == "required") {


        if (value == "") {
            alert("Please enter a value")
        }
    }
    if (type == "phone") {


        if (value == "") {
            alert("Please enter a value")
        }
        else if (value.match(/\d/g).length != 10) {

            alert("Please enter a valid phone no")

        }
    }
    if (type == "email") {


        if (value == "") {
            alert("Please enter a value")
        }
        else if (email = /^([a-z0-9-._])+@([a-z]{2,4})+$/) {

            alert("Please enter a valid email")

        }
    }
    if (type == "password") {


        if (value == "") {
            alert("Please enter a value")
        }
        else if (pattern = "(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}") {

            alert("Please enter a valid password")

        }
    }
}