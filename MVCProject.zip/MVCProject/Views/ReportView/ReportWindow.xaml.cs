﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ChecknTrack.Data;
using System.Data;
using CrystalDecisions.Shared;
using CrystalDecisions.CrystalReports.Engine;
using System.Net.Mail;
using Microsoft.Win32;
using System.Configuration;
using System.IO;
using ChecknTrack.Common;

namespace ChecknTrack.View.ReportView
{
    /// <summary>

    /// Interaction logic for Window1.xaml
    /// </summary>
    /// 
    public partial class ReportWindow : Window, IcntReportInfo
    {
        private int docEnquiryId = 0;
        DataTable dtQuotationReport_Regular = null;
        DataTable dtQuotationReport_Group = null;
        DataTable dtQuotationReport = null;
        DataTable dtQuotationTnC = null;
        DataTable dtQuotationHome = null;
        DataTable dtInvoiceReport = null;
        DataTable dtDetailInvoiceReport = null;
        DataTable dtWorkOrderReport = null;
        DataTable dtPurchaseOrderReport = null;
        DataTable dtDetailWorkOrderReport = null;
        DataTable dtTaxReport = null;
        DataTable dtDtlTaxReport = null;

        StringBuilder sbFileSelected;

        private string _selectedDetailType = string.Empty;
        public ReportWindow()
        {
            MainWindow.Instance.Cursor = Cursors.Wait;
            InitializeComponent();

            //SortColumn = string.Empty;
            //SortDirection = string.Empty;
        }
        List<cntFile> _FileList;
        List<cntRecipient> _RecipientList;
        List<cntRecipient> _CCList;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            _FileList = new List<cntFile>();
            //if (DocumentType == "QuotationReport")
            //{
            //    sbFileSelected = new StringBuilder();
            //    List<ReportOption> ReportOptionList = new List<ReportOption>()
            //                                                                {
            //                                                                    new ReportOption(){OptionValue=1, OptionName="Priced Technical Bid", isMarked=false},
            //                                                                    new ReportOption(){OptionValue=2, OptionName="Unpriced Technical Bid", isMarked=false},
            //                                                                    new ReportOption(){OptionValue=3, OptionName="Priced Bid Summary", isMarked=false},
            //                                                                    new ReportOption(){OptionValue=4, OptionName="Commercial Bid", isMarked=false},
            //                                                                    new ReportOption(){OptionValue=5, OptionName="Commercial/Technical Deviation", isMarked=true}
            //                                                                };
            //    lstReportOptions.ItemsSource = ReportOptionList;
            //    FillRecipientsnCCs();
            //    lstRecipient.ItemsSource = _RecipientList;
            //    lstCC.ItemsSource = _CCList;
            //}
            this.CrystalReportsViewer1.ViewerCore.EnableDrillDown = false;
        }

        private void FillAnnextureOptions()
        {
            _FileList = new List<cntFile>();
            if (DocumentType == "QuotationReport" && lstReportOptions.Items.Count == 0)
            {
                sbFileSelected = new StringBuilder();
                List<ReportOption> ReportOptionList = new List<ReportOption>()
                                                                            {
                                                                                new ReportOption(){OptionValue=1, OptionName="Priced Technical Bid", isMarked=true},
                                                                                new ReportOption(){OptionValue=2, OptionName="Unpriced Technical Bid", isMarked=false},
                                                                                new ReportOption(){OptionValue=3, OptionName="Priced Bid Summary", isMarked=false},
                                                                                new ReportOption(){OptionValue=4, OptionName="Commercial Bid", isMarked=true},
                                                                                new ReportOption(){OptionValue=5, OptionName="Commercial/Technical Deviation", isMarked = blnCondition}
                                                                            };
                lstReportOptions.ItemsSource = ReportOptionList;
                FillRecipientsnCCs();
                //lstRecipient.ItemsSource = _RecipientList;
                lstCC.ItemsSource = _CCList;
            }
            if (DocumentType == "WorkOrderReport" && lstReportOptions.Items.Count == 0)
            {
                sbFileSelected = new StringBuilder();
                List<ReportOption> ReportOptionList = new List<ReportOption>()
                                                                            {
                                                                                new ReportOption(){OptionValue=1, OptionName="Priced Technical Bid", isMarked=true},
                                                                                new ReportOption(){OptionValue=2, OptionName="Unpriced Technical Bid", isMarked=false}
                                                                            };
                lstReportOptions.ItemsSource = ReportOptionList;
                FillRecipientsnCCs();
                //lstRecipient.ItemsSource = _RecipientList;
                lstCC.ItemsSource = _CCList;
            }
        }

        private void FillRecipientsnCCs()
        {
            DataView dvContacts = cntDB.Instance.GetContactListOnEnquiryId(this.EnquiryId);

            _RecipientList = new List<cntRecipient>();

            for (int i = 0; i < dvContacts.Count; i++)
            {
                _RecipientList.Add(new cntRecipient() { eMail = dvContacts[i]["cntM_eMail"].ToString() });
            }

            if (this.DocumentType == "QuotationReport")
            {
                dvContacts = null;
                dvContacts = cntDB.Instance.GetContactListOnQuotationId(this.DocumentId);

                _CCList = new List<cntRecipient>();

                for (int i = 0; i < dvContacts.Count; i++)
                {
                    _CCList.Add(new cntRecipient() { eMail = dvContacts[i]["cntM_eMail"].ToString() });
                }
            }
            if (this.DocumentType == "Regret Letter" || this.DocumentType == "Divert Letter")
            {
                dvContacts = null;
                dvContacts = cntDB.Instance.GetDistributorListOnEnquiryId(this.EnquiryId);

                _CCList = new List<cntRecipient>();

                for (int i = 0; i < dvContacts.Count; i++)
                {
                    _CCList.Add(new cntRecipient() { eMail = dvContacts[i]["dstM_eMail"].ToString() });
                }
            }
            lstRecipient.ItemsSource = _RecipientList;
        }

        private void FillRecipientsnCCs_WO()
        {

            DataView dvContacts = cntDB.Instance.workOrder.GetContactListOnWorkOrderId(this.DocumentId);

            _RecipientList = new List<cntRecipient>();

            for (int i = 0; i < dvContacts.Count; i++)
            {
                _RecipientList.Add(new cntRecipient() { eMail = dvContacts[i]["cntM_eMail"].ToString() });
            }

            //dvContacts = null;
            //dvContacts = cntDB.Instance.GetStaffListOnWorkOrderId(this.DocumentId);

            //_CCList = new List<cntRecipient>();

            //for (int i = 0; i < dvContacts.Count; i++)
            //{
            //    _CCList.Add(new cntRecipient() { eMail = dvContacts[i]["cntM_eMail"].ToString() });
            //}

            lstRecipient.ItemsSource = _RecipientList;
        }

        #region "ITnCReportInfo Members"
        private int _documentId = 0;
        public int DocumentId
        {
            get
            {
                return _documentId;
            }
            set
            {
                _documentId = value;
            }
        }

        private string _documentNo = string.Empty;
        public string DocumentNo
        {
            get
            {
                return _documentNo;
            }
            set
            {
                _documentNo = value;
            }
        }
        private string _productName = string.Empty;
        public string ProductName
        {
            get
            {
                return _productName;
            }
            set
            {
                _productName = value;
            }
        }

        private int _enquiryId = 0;
        public int EnquiryId
        {
            get
            {
                return _enquiryId;
            }
            set
            {
                _enquiryId = value;
            }
        }

        private int _productId = 0;
        public int ProductId
        {
            get
            {
                return _productId;
            }
            set
            {
                _productId = value;
            }
        }

        public int StaffId { get; set; }
        //Item Register Parameters
        public string ItemCode { get; set; }
        public string CategoryName { get; set; }
        public string ItemGroupName { get; set; }
        //
        public string CategoryCode { get; set; }
        //Client Register Parameters
        public string CompanyCode { get; set; }
        public string CompanyName { get; set; }
        public string LocationCity { get; set; }
        public string ContactPerson { get; set; }
        public string ContacteMail { get; set; }
        //
        public string SelectedEnquiryText { get; set; }

        private string _documentType = string.Empty;
        public string DocumentType
        {
            get
            {
                return _documentType;
            }
            set
            {
                _documentType = value;
                ReportHeading.Text = value;
                if (value.ToString() == "QuotationReport" || value.ToString() == "WorkOrderReport")
                {
                    lblAnnexures.Visibility = Visibility.Visible;
                    lstReportOptions.Visibility = Visibility.Visible;
                    imgReport.Visibility = Visibility.Hidden;
                    stkRefresh.Visibility = Visibility.Visible;
                }
                else if (value.ToString() == "Regret Letter" || value.ToString() == "Divert Letter")
                {
                    imgReport.Height = 175;
                    FillRecipientsnCCs();
                    //lstRecipient.ItemsSource = _RecipientList;
                    lstCC.ItemsSource = _CCList;
                }
                else
                {
                    imgReport.Visibility = Visibility.Visible;
                }
            }
        }

        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public string EnquiryStatus { get; set; }

        public string SortColumn { get; set; }
        public string SortDirection { get; set; }

        private string _currentDocument = string.Empty;
        public string CurrentDocument
        {
            get
            {
                return _currentDocument;
            }
            set
            {
                _currentDocument = value;
            }
        }
        private DataTable _dtReportData = null;
        public DataTable dtReportData
        {
            get
            {
                return _dtReportData;
            }
            set
            {
                _dtReportData = value;
            }
        }

        public Boolean blnCondition { get; set; }

        ReportDocument _rptDisplay;
        public void ShowReport(bool pShowWindow)
        {
            _rptDisplay = null;
            string mAddress = string.Empty;
            try
            {
                _rptDisplay = DisplayReport(this.DocumentType, pShowWindow);
                _rptDisplay.SetDatabaseLogon(cntDB.Instance.DBUser, cntDB.Instance.DBPassword, cntDB.Instance.DBServer, cntDB.Instance.DBName);
                switch (DocumentType)
                {
                    case "QuotationReport":
                        _rptDisplay.Subreports["rptQuotationHome.rpt"].DataDefinition.FormulaFields["fAnnexure"].Text = getAnnexureInfo();
                        _rptDisplay.Subreports["rptQuotationDocument.rpt"].DataDefinition.FormulaFields["fDocAnnexure"].Text = getAnnexureInfo("Priced Technical Bid");
                        _rptDisplay.Subreports["rptQuotationDocument.rpt"].DataDefinition.FormulaFields["fShow"].Text = (dtQuotationReport_Group.Rows.Count > 0).ToString();
                        _rptDisplay.Subreports["rptQuotationGroup.rpt"].DataDefinition.FormulaFields["fDocAnnexure"].Text = getAnnexureInfo("Priced Technical Bid");
                        _rptDisplay.Subreports["rptQuotationGroup.rpt"].DataDefinition.FormulaFields["fShow"].Text = "'Show'";
                        _rptDisplay.Subreports["rptQuotationDocument_Unpriced.rpt"].DataDefinition.FormulaFields["fDocAnnexure"].Text = getAnnexureInfo("Unpriced Technical Bid");
                        _rptDisplay.Subreports["rptQuotationGroup_Unpriced.rpt"].DataDefinition.FormulaFields["fDocAnnexure"].Text = getAnnexureInfo("Unpriced Technical Bid");
                        _rptDisplay.Subreports["rptQuotationSummary.rpt"].DataDefinition.FormulaFields["fDocAnnexure"].Text = getAnnexureInfo("Priced Bid Summary");
                        _rptDisplay.Subreports["rptQuotationTermsAndCondition.rpt"].DataDefinition.FormulaFields["fDocAnnexure"].Text = getAnnexureInfo("Commercial Bid");
                        _rptDisplay.Subreports["rptQuotation_StandardDeviation.rpt"].DataDefinition.FormulaFields["fDocAnnexure"].Text = getAnnexureInfo("Commercial/Technical Deviation");
                        break;
                    case "GSTInvoiceReport":
                        _rptDisplay.DataDefinition.FormulaFields["fFormName"].Text = "'" + this.CurrentDocument + "'";
                        _rptDisplay.DataDefinition.FormulaFields["fRange"].Text = "'" + Common.cntCommon.CurrentCompanyRange + "'";
                        _rptDisplay.DataDefinition.FormulaFields["fDivision"].Text = "'" + Common.cntCommon.CurrentCompanyDivision + "'";
                        _rptDisplay.DataDefinition.FormulaFields["fCommissionerate"].Text = "'" + Common.cntCommon.CurrentCompanyCommissionerate + "'";
                        _rptDisplay.DataDefinition.FormulaFields["fECC"].Text = Common.cntCommon.CurrentCompanyECC;
                        _rptDisplay.DataDefinition.FormulaFields["fCompanyGSTiN"].Text = "'" + Common.cntCommon.CurrentCompanyGST+ "'"; 

                        string[] _strAmts1 = this.SelectedEnquiryText.Split(';');
                        string _strWords1 = _strAmts1[0];

                        _strWords1 = ChecknTrack.Common.NumberToEnglish.changeNumericToWords(_strWords1);
                        if (!string.IsNullOrEmpty(_strWords1)) _strWords1 = _strWords1 + " only.";
                        _rptDisplay.DataDefinition.FormulaFields["fExciseInWords"].Text = "'" + _strWords1 + "'";

                        _strWords1 = _strAmts1[1];
                        _strWords1 = ChecknTrack.Common.NumberToEnglish.changeNumericToWords(_strWords1);
                        if (!string.IsNullOrEmpty(_strWords1)) _strWords1 = _strWords1 + " only.";
                        _rptDisplay.DataDefinition.FormulaFields["fCessInWords"].Text = "'" + _strWords1 + "'";

                        _strWords1 = _strAmts1[2];
                        _strWords1 = ChecknTrack.Common.NumberToEnglish.changeNumericToWords(_strWords1);
                        if (!string.IsNullOrEmpty(_strWords1)) _strWords1 = _strWords1 + " only.";
                        _rptDisplay.DataDefinition.FormulaFields["fHADSPInWords"].Text = "'" + _strWords1 + "'";

                        mAddress = string.Format("'{0}'", Common.cntCommon.CurrentCompanyAddress.Replace("\r\n", " ")); //;
                        _rptDisplay.DataDefinition.FormulaFields["fCompanyAddress"].Text = mAddress;
                        _rptDisplay.DataDefinition.FormulaFields["fVAT"].Text = string.Format("'VAT No.: {0}'", Common.cntCommon.CurrentCompanyVAT);
                        _rptDisplay.DataDefinition.FormulaFields["fCST"].Text = string.Format("'CST No.: {0}'", Common.cntCommon.CurrentCompanyCST);
                        _rptDisplay.DataDefinition.FormulaFields["fST"].Text = string.Format("'Service Tax No.: {0}'", Common.cntCommon.CurrentCompanyST);
                        _rptDisplay.DataDefinition.FormulaFields["fJurisdiction"].Text = string.Format("'Subject to {0} Jurisdiction'", Common.cntCommon.CurrentCompanyLocationName);
                        break;
                    case "InvoiceReport":
                        _rptDisplay.DataDefinition.FormulaFields["fFormName"].Text = "'" + this.CurrentDocument + "'";
                        _rptDisplay.DataDefinition.FormulaFields["fRange"].Text = "'" + Common.cntCommon.CurrentCompanyRange + "'";
                        _rptDisplay.DataDefinition.FormulaFields["fDivision"].Text = "'" + Common.cntCommon.CurrentCompanyDivision + "'";
                        _rptDisplay.DataDefinition.FormulaFields["fCommissionerate"].Text = "'" + Common.cntCommon.CurrentCompanyCommissionerate + "'";
                        _rptDisplay.DataDefinition.FormulaFields["fECC"].Text = Common.cntCommon.CurrentCompanyECC;

                        string[] _strAmts = this.SelectedEnquiryText.Split(';');
                        string _strWords = _strAmts[0];

                        _strWords = ChecknTrack.Common.NumberToEnglish.changeNumericToWords(_strWords);
                        if (!string.IsNullOrEmpty(_strWords)) _strWords = _strWords + " only.";
                        _rptDisplay.DataDefinition.FormulaFields["fExciseInWords"].Text = "'" + _strWords + "'";

                        _strWords = _strAmts[1];
                        _strWords = ChecknTrack.Common.NumberToEnglish.changeNumericToWords(_strWords);
                        if (!string.IsNullOrEmpty(_strWords)) _strWords = _strWords + " only.";
                        _rptDisplay.DataDefinition.FormulaFields["fCessInWords"].Text = "'" + _strWords + "'";

                        _strWords = _strAmts[2];
                        _strWords = ChecknTrack.Common.NumberToEnglish.changeNumericToWords(_strWords);
                        if (!string.IsNullOrEmpty(_strWords)) _strWords = _strWords + " only.";
                        _rptDisplay.DataDefinition.FormulaFields["fHADSPInWords"].Text = "'" + _strWords + "'";

                        mAddress = string.Format("'{0}'", Common.cntCommon.CurrentCompanyAddress.Replace("\r\n", " ")); //;
                        _rptDisplay.DataDefinition.FormulaFields["fCompanyAddress"].Text = mAddress;
                        _rptDisplay.DataDefinition.FormulaFields["fVAT"].Text = string.Format("'VAT No.: {0}'", Common.cntCommon.CurrentCompanyVAT);
                        _rptDisplay.DataDefinition.FormulaFields["fCST"].Text = string.Format("'CST No.: {0}'", Common.cntCommon.CurrentCompanyCST);
                        _rptDisplay.DataDefinition.FormulaFields["fST"].Text = string.Format("'Service Tax No.: {0}'", Common.cntCommon.CurrentCompanyST);
                        _rptDisplay.DataDefinition.FormulaFields["fJurisdiction"].Text = string.Format("'Subject to {0} Jurisdiction'", Common.cntCommon.CurrentCompanyLocationName);
                        break;

                    case "TradingInvoiceReport":
                        string[] _strAmts2 = this.SelectedEnquiryText.Split(';');
                        string _strWords2 = _strAmts2[0];
                        _rptDisplay.DataDefinition.FormulaFields["fFormName"].Text = "'" + this.CurrentDocument + "'";

                        _strWords2 = _strAmts2[3];
                        _strWords2 = ChecknTrack.Common.NumberToEnglish.changeNumericToWords(_strWords2);


                        mAddress = string.Format("'{0}'", Common.cntCommon.CurrentCompanyAddress.Replace("\r\n", " ")); //;
                        _rptDisplay.DataDefinition.FormulaFields["fCompanyAddress"].Text = mAddress;
                        _rptDisplay.DataDefinition.FormulaFields["fVAT"].Text = string.Format("'VAT No.: {0}'", Common.cntCommon.CurrentCompanyVAT);
                        _rptDisplay.DataDefinition.FormulaFields["fCST"].Text = string.Format("'CST No.: {0}'", Common.cntCommon.CurrentCompanyCST);
                        _rptDisplay.DataDefinition.FormulaFields["fST"].Text = string.Format("'Service Tax No.: {0}'", Common.cntCommon.CurrentCompanyST);
                        _rptDisplay.DataDefinition.FormulaFields["fJurisdiction"].Text = string.Format("'Subject to {0} Jurisdiction'", Common.cntCommon.CurrentCompanyLocationName);

                        break;
                    case "TaxInvoiceReport":
                        string[] _strAmts3 = this.SelectedEnquiryText.Split(';');
                        string _strWords3 = _strAmts3[0];

                        _rptDisplay.DataDefinition.FormulaFields["fFormName"].Text = "'" + this.CurrentDocument + "'";

                        mAddress = string.Format("'{0}'", Common.cntCommon.CurrentCompanyAddress.Replace("\r\n", " ")); //;
                        _rptDisplay.DataDefinition.FormulaFields["fCompanyAddress"].Text = mAddress;
                        _rptDisplay.DataDefinition.FormulaFields["fVAT"].Text = string.Format("'VAT No.: {0}'", Common.cntCommon.CurrentCompanyVAT);
                        _rptDisplay.DataDefinition.FormulaFields["fCST"].Text = string.Format("'CST No.: {0}'", Common.cntCommon.CurrentCompanyCST);
                        _rptDisplay.DataDefinition.FormulaFields["fST"].Text = string.Format("'Service Tax No.: {0}'", Common.cntCommon.CurrentCompanyST);
                        _rptDisplay.DataDefinition.FormulaFields["fJurisdiction"].Text = string.Format("'Subject to {0} Jurisdiction'", Common.cntCommon.CurrentCompanyLocationName);

                        _strWords3 = _strAmts3[3];
                        _strWords3 = ChecknTrack.Common.NumberToEnglish.changeNumericToWords(_strWords3);
                        break;
                    case "Regret Letter":
                        _rptDisplay.DataDefinition.FormulaFields["fConditionList"].Text = ConditionList;
                        break;

                    case "Enquiry Register":
                    case "EnquiryList_Client":
                    case "EnquiryList_Distributor":
                        _rptDisplay.DataDefinition.FormulaFields["Heading"].Text = string.Format("'LIST OF ENQUIRIES BETWEEN  {0}  TO  {1}'", this.DateFrom.ToString("dd-MMM-yyyy"), this.DateTo.ToString("dd-MMM-yyyy"));
                        break;
                    case "QuotationList_Client":
                        string _productheading = string.Empty;
                        if (ProductId > 0) _productheading = string.Format(" For [{0}]", ProductName.ToUpper().Trim());
                        _rptDisplay.DataDefinition.FormulaFields["Heading"].Text = string.Format("'LIST OF QUOTATION BETWEEN  {0}  TO  {1}{2}'", this.DateFrom.ToString("dd-MMM-yyyy"), this.DateTo.ToString("dd-MMM-yyyy"), _productheading);
                        _rptDisplay.DataDefinition.FormulaFields["fTotalBool"].Text = (ProductId > 0).ToString();
                        break;

                    case "Pending Enquiries":
                    case "Enquiry Movements":
                        _rptDisplay.DataDefinition.FormulaFields["Heading"].Text = string.Format("'LIST OF ENQUIRIES BETWEEN  {0}  TO  {1} assigned to {2}'", this.DateFrom.ToString("dd-MMM-yyyy"), this.DateTo.ToString("dd-MMM-yyyy"), this.SelectedEnquiryText);
                        break;
                    case "PurchaseOrderReport":
                        mAddress = string.Format("'{0}'", Common.cntCommon.CurrentCompanyAddress.Replace("\r\n", " ")); 
                        _rptDisplay.DataDefinition.FormulaFields["fCompanyAddress"].Text = mAddress;
                        _rptDisplay.DataDefinition.FormulaFields["fPAN"].Text = string.Format("'{0}'", Common.cntCommon.CurrentCompanyPAN);
                        _rptDisplay.DataDefinition.FormulaFields["fVAT"].Text = string.Format("'{0}'",  Common.cntCommon.CurrentCompanyVAT);
                        _rptDisplay.DataDefinition.FormulaFields["fCST"].Text =string.Format("'{0}'",  Common.cntCommon.CurrentCompanyCST);
                        _rptDisplay.DataDefinition.FormulaFields["fST"].Text = string.Format("'{0}'", Common.cntCommon.CurrentCompanyST);
                        _rptDisplay.DataDefinition.FormulaFields["fJurisdiction"].Text = string.Format("'Subject to {0} Jurisdiction'", Common.cntCommon.CurrentCompanyLocationName);
                        break;
                    case "WorkOrderReport":
                    case "WorkOrderReport_Unpriced":
                        break;
                    case "Quotation Register":
                    case "QuotationList_User":
                    case "QuotationList_Product":
                    case "Category Register":
                    case "Client Register":
                    case "Distributor Register":
                    case "Product Register":
                        break;
                }

                CrystalReportsViewer1.ViewerCore.ReportSource = _rptDisplay;
                this.CrystalReportsViewer1.ViewerCore.Zoom(51);
                if (pShowWindow)
                {
                    this.ShowDialog();
                }

                this.CrystalReportsViewer1.ViewerCore.BringIntoView();
            }
            catch (CrystalReportsException rex)
            {
                throw rex;
            }
            catch (FormulaException ex)
            {
                throw ex;
            }  
            catch ( Exception ex)
            {
                throw ex;
            }
            finally
            {
                MainWindow.Instance.Cursor = Cursors.Arrow;
            }
        }

        private ReportDocument DisplayReport(string pDocumentType, bool pShowWindow)
        {
            _rptDisplay = new ReportDocument();
            string _strReportFolder = ConfigurationManager.AppSettings["ReportFolder"].ToString();
            DataTable dtData = null;
            try
            {
                FillAnnextureOptions();
                switch (pDocumentType)
                {
                    case "QuotationReport":
                        dtQuotationHome = cntDB.Instance.getQuotationInfoOnId(this.DocumentId);
                        if (dtQuotationReport_Regular == null) dtQuotationReport_Regular = cntDB.Instance.getQuotationDocumentReport_Regular(this.DocumentId);
                        if (dtQuotationReport_Group == null) dtQuotationReport_Group = cntDB.Instance.getQuotationGroupDocumentReport(this.DocumentId);
                        if (dtQuotationReport == null) dtQuotationReport = cntDB.Instance.getQuotationDocumentReport(this.DocumentId);
                        if (dtQuotationTnC == null) dtQuotationTnC = cntDB.Instance.getTnCInfoOnQuotationIdReport(this.DocumentId);

                        _rptDisplay.Load(_strReportFolder + "rptQuotationReport.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.Subreports["rptQuotationHome.rpt"].SetDataSource(dtQuotationHome);
                        _rptDisplay.Subreports["rptQuotationDocument.rpt"].SetDataSource(dtQuotationReport_Regular);
                        _rptDisplay.Subreports["rptQuotationDocument_Unpriced.rpt"].SetDataSource(dtQuotationReport_Regular);
                        _rptDisplay.Subreports["rptQuotationGroup.rpt"].SetDataSource(dtQuotationReport_Group);
                        _rptDisplay.Subreports["rptQuotationGroup_Unpriced.rpt"].SetDataSource(dtQuotationReport_Group);
                        _rptDisplay.Subreports["rptQuotationSummary.rpt"].SetDataSource(dtQuotationReport);
                        _rptDisplay.Subreports["rptQuotationTermsAndCondition.rpt"].SetDataSource(dtQuotationTnC);
                        _rptDisplay.Subreports["rptQuotation_StandardDeviation.rpt"].SetDataSource(dtQuotationHome);

                        if (lstReportOptions.Items.Count > 0)
                        {
                            setParameters("pAnnPricedTech", (lstReportOptions.Items[0] as ReportOption).isMarked, _rptDisplay);
                            setParameters("pAnnUnPricedTech", (lstReportOptions.Items[1] as ReportOption).isMarked, _rptDisplay);
                            setParameters("pAnnSummary", (lstReportOptions.Items[2] as ReportOption).isMarked, _rptDisplay);
                            setParameters("pAnnTnC", (lstReportOptions.Items[3] as ReportOption).isMarked, _rptDisplay);
                            setParameters("pStandardDeviation", (lstReportOptions.Items[4] as ReportOption).isMarked, _rptDisplay);

                            setParameters("pShowQuotationDocument_Group", (dtQuotationReport_Group.Rows.Count > 0), _rptDisplay);
                            setParameters("pShowQuotationDocument_Regular", (dtQuotationReport_Regular.Rows.Count > 0), _rptDisplay);
                        }
                        else
                        {
                            setParameters("pAnnPricedTech", false, _rptDisplay);
                            setParameters("pAnnUnPricedTech", false, _rptDisplay);
                            setParameters("pAnnSummary", false, _rptDisplay);
                            setParameters("pAnnTnC", false, _rptDisplay);
                            setParameters("pStandardDeviation", false, _rptDisplay);

                            setParameters("pShowQuotationDocument_Group", (dtQuotationReport_Group.Rows.Count > 0), _rptDisplay);
                            setParameters("pShowQuotationDocument_Regular", (dtQuotationReport_Regular.Rows.Count > 0), _rptDisplay);
                        }

                        _selectedDetailType = string.Empty;
                        break;
                    case "GSTInvoiceReport":
                        dtInvoiceReport = cntDB.Instance.getInvoiceDocumentReport(this.DocumentId);
                        dtTaxReport = cntDB.Instance.getTaxInfoOnInvoiceId(this.DocumentId);
                        dtDtlTaxReport = cntDB.Instance.getInvoiceDetailItemAllTaxInfo(this.DocumentId);

                        _rptDisplay.Load(_strReportFolder + "rptGSTInvoiceReport.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(dtInvoiceReport.DefaultView);
                        _rptDisplay.Subreports["rptTax.rpt"].SetDataSource(dtTaxReport);
                        //_rptDisplay.Subreports["rptItemTax.rpt"].SetDataSource(dtDtlTaxReport);
                        break;

                    case "InvoiceReport":
                        dtInvoiceReport = cntDB.Instance.getInvoiceDocumentReport(this.DocumentId);
                        dtTaxReport = cntDB.Instance.getTaxInfoOnInvoiceId(this.DocumentId);
                        dtDtlTaxReport = cntDB.Instance.getInvoiceDetailItemAllTaxInfo(this.DocumentId);

                        _rptDisplay.Load(_strReportFolder + "rptExciseInvoiceReport.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(dtInvoiceReport.DefaultView);
                        _rptDisplay.Subreports["rptTax.rpt"].SetDataSource(dtTaxReport);
                        //_rptDisplay.Subreports["rptItemTax.rpt"].SetDataSource(dtDtlTaxReport);
                        break;

                    case "PurchaseOrderReport":
                        txtSubject.Text = "PurchaseOrder Report.";

                        // FillRecipientsnCCs_WO();
                        dtTaxReport = cntDB.Instance.po.getPOTaxSummaryInfoOnPOId(this.DocumentId);
                        dtPurchaseOrderReport = cntDB.Instance.po.getPurchaseOrderDocumentReport(this.DocumentId);

                        //dtTaxReport = cntDB.Instance.getTaxInfoOnInvoiceId(this.DocumentId);
                        //_rptDisplay.Load(_strReportFolder + "rptWOReport.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.Load(_strReportFolder + "POHomeReport.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(dtPurchaseOrderReport.DefaultView);
                        _rptDisplay.Subreports["rptPOTaxSummary.rpt"].SetDataSource(dtTaxReport);
                        _rptDisplay.Subreports["rptPOReport.rpt"].SetDataSource(dtPurchaseOrderReport);
                        //_rptDisplay.Subreports["rptPurchaseOrderReport_Unpriced.rpt"].SetDataSource(dtPurchaseOrderReport);
                        _rptDisplay.Subreports["rptPOTermsAndConditionReport.rpt"].SetDataSource(cntDB.Instance.po.getTnCInfoOnPurchaseOrderIdReport(this.DocumentId));

                        //                        setParameters("pAnnPricedTech", (lstReportOptions.Items[0] as ReportOption).isMarked, _rptDisplay);
                        //                      setParameters("pAnnUnPricedTech", (lstReportOptions.Items[1] as ReportOption).isMarked, _rptDisplay);

                        return _rptDisplay;


                    case "WorkOrderReport":
                        txtSubject.Text = "WorkOrder Report.";

                        FillRecipientsnCCs_WO();
                        dtTaxReport = cntDB.Instance.getWOTaxSummaryInfoOnWOId(this.DocumentId);
                        dtWorkOrderReport = cntDB.Instance.workOrder.getWorkOrderDocumentReport(this.DocumentId);

                        //dtTaxReport = cntDB.Instance.getTaxInfoOnInvoiceId(this.DocumentId);
                        //_rptDisplay.Load(_strReportFolder + "rptWOReport.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.Load(_strReportFolder + "WorkOrderHomeReport.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(dtWorkOrderReport.DefaultView);
                        _rptDisplay.Subreports["rptWOTaxSummary.rpt"].SetDataSource(dtTaxReport);
                        _rptDisplay.Subreports["rptWorkOrderReport.rpt"].SetDataSource(dtWorkOrderReport);
                        _rptDisplay.Subreports["rptWorkOrderReport_Unpriced.rpt"].SetDataSource(dtWorkOrderReport);
                        _rptDisplay.Subreports["rptWorkOrderTermsAndConditionReport.rpt"].SetDataSource(cntDB.Instance.workOrder.getTnCInfoOnWorkOrderIdReport(this.DocumentId));

                        setParameters("pAnnPricedTech", (lstReportOptions.Items[0] as ReportOption).isMarked, _rptDisplay);
                        setParameters("pAnnUnPricedTech", (lstReportOptions.Items[1] as ReportOption).isMarked, _rptDisplay);

                        return _rptDisplay;


                    case "WorkOrderReport_Unpriced":
                        txtSubject.Text = "WorkOrder Report.";

                        FillRecipientsnCCs_WO();
                        dtTaxReport = cntDB.Instance.getWOTaxSummaryInfoOnWOId(this.DocumentId);
                        dtWorkOrderReport = cntDB.Instance.workOrder.getWorkOrderDocumentReport(this.DocumentId);

                        //dtTaxReport = cntDB.Instance.getTaxInfoOnInvoiceId(this.DocumentId);
                        //_rptDisplay.Load(_strReportFolder + "rptWOReport.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.Load(_strReportFolder + "WorkOrderHomeReport_Unpriced.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(dtWorkOrderReport.DefaultView);
                        _rptDisplay.Subreports["rptWorkOrderReport_Unpriced.rpt"].SetDataSource(dtWorkOrderReport);
                        _rptDisplay.Subreports["rptWorkOrderTermsAndConditionReport.rpt"].SetDataSource(cntDB.Instance.workOrder.getTnCInfoOnWorkOrderIdReport(this.DocumentId));

                        //setParameters("pAnnPricedTech", (lstReportOptions.Items[0] as ReportOption).isMarked, _rptDisplay);
                        //setParameters("pAnnUnPricedTech", (lstReportOptions.Items[1] as ReportOption).isMarked, _rptDisplay);

                        return _rptDisplay;

                    case "TaxInvoiceReport":
                        dtInvoiceReport = cntDB.Instance.getInvoiceDocumentReport(this.DocumentId);
                        dtTaxReport = cntDB.Instance.getTaxInfoOnInvoiceId(this.DocumentId);
                        dtDtlTaxReport = cntDB.Instance.getInvoiceDetailItemAllTaxInfo(this.DocumentId);
                        _rptDisplay.Load(_strReportFolder + "rptTaxInvoiceReport.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(dtInvoiceReport.DefaultView);
                        _rptDisplay.Subreports["rptTax.rpt"].SetDataSource(dtTaxReport);
                        //_rptDisplay.Subreports["rptItemTax.rpt"].SetDataSource(dtDtlTaxReport);
                        break;

                    case "TradingInvoiceReport":
                        dtInvoiceReport = cntDB.Instance.getInvoiceDocumentReport(this.DocumentId);
                        dtTaxReport = cntDB.Instance.getTaxInfoOnInvoiceId(this.DocumentId);
                        dtDtlTaxReport = cntDB.Instance.getInvoiceDetailItemAllTaxInfo(this.DocumentId);
                        _rptDisplay.Load(_strReportFolder + "rptTradingInvoiceReport.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(dtInvoiceReport.DefaultView);
                        _rptDisplay.Subreports["rptTax.rpt"].SetDataSource(dtTaxReport);
                        //_rptDisplay.Subreports["rptItemTax.rpt"].SetDataSource(dtDtlTaxReport);
                        break;

                    case "Enquiry Register":
                        _rptDisplay.Load(_strReportFolder + "rptEnquiryRegister.rpt", OpenReportMethod.OpenReportByTempCopy);
                        dtData = cntDB.Instance.getEnquiryInfo(this.DateFrom, this.DateTo);
                        if (SortColumn != null && SortColumn.Trim().Length > 0)
                        {
                            dtData.DefaultView.Sort = string.Format("{0} {1}", SortColumn, SortDirection);
                        }
                        _rptDisplay.SetDataSource(dtData.DefaultView);
                        //_rptDisplay.SetDataSource(cntDB.Instance.getEnquiryInfo(this.DateFrom, this.DateTo));
                        btnSend.Visibility = Visibility.Hidden;

                        return _rptDisplay;

                    case "Enquiry Movements":
                        _rptDisplay.Load(_strReportFolder + "rptEnquiryMovementStatus.rpt", OpenReportMethod.OpenReportByTempCopy);
                        dtData = cntDB.Instance.getEnquiryMovementInfo(EnquiryStatus, this.StaffId, this.DateFrom, this.DateTo);
                        if (SortColumn != null && SortColumn.Trim().Length > 0)
                        {
                            dtData.DefaultView.Sort = string.Format("{0} {1}", SortColumn, SortDirection);
                        }
                        _rptDisplay.SetDataSource(dtData.DefaultView);
                        btnSend.Visibility = Visibility.Hidden;
                        return _rptDisplay;

                    case "Pending Enquiries":
                        _rptDisplay.Load(_strReportFolder + "rptEnquiryMovementStatus.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(cntDB.Instance.getPendingEnquiryInfo(this.StaffId, this.DateFrom, this.DateTo));
                        btnSend.Visibility = Visibility.Hidden;

                        return _rptDisplay;
                    case "Quotation Register":
                        _rptDisplay.Load(_strReportFolder + "rptQuotationRegister.rpt", OpenReportMethod.OpenReportByTempCopy);
                        dtData = cntDB.Instance.getAllQuotationRegisterInfo(this.DateFrom, this.DateTo);
                        if (SortColumn != null && SortColumn.Trim().Length > 0)
                        {
                            dtData.DefaultView.Sort = string.Format("{0} {1}", SortColumn, SortDirection);
                        }
                        _rptDisplay.SetDataSource(dtData.DefaultView);
                        //_rptDisplay.SetDataSource(cntDB.Instance.getQuotationRegisterInfo(this.DateFrom, this.DateTo));
                        btnSend.Visibility = Visibility.Hidden;
                        return _rptDisplay;

                    case "Regret Letter":
                        dtData = cntDB.Instance.getEnquiryInfoOnId(this.DocumentId);
                        _rptDisplay.Load(_strReportFolder + "rptRegretLetter.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(dtData);
                        if (docEnquiryId == 0) docEnquiryId = this.DocumentId;
                        return _rptDisplay;

                    case "Divert Letter":
                        _rptDisplay.Load(_strReportFolder + "rptDivertLetter.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(cntDB.Instance.getDivertedEnquiryInfo(this.DocumentId));
                        if (docEnquiryId == 0) docEnquiryId = this.DocumentId;
                        return _rptDisplay;

                    case "QuotationList_Client":
                        _rptDisplay.Load(_strReportFolder + "rptQuotationList_Client.rpt", OpenReportMethod.OpenReportByTempCopy);
                        dtData = cntDB.Instance.getQuotationItemInfoOnId(this.DateFrom, this.DateTo, this.EnquiryId, this.DocumentId);
                        if (ProductId > 0) dtData.DefaultView.RowFilter = string.Format("qtD_ItMId={0}", ProductId);
                        _rptDisplay.SetDataSource(dtData.DefaultView);
                        btnSend.Visibility = Visibility.Hidden;
                        return _rptDisplay;

                    case "QuotationList_Product":
                        _rptDisplay.Load(_strReportFolder + "rptQuotationList_Product.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(cntDB.Instance.getQuotationItemInfoOnId(this.DateFrom, this.DateTo, this.EnquiryId, this.DocumentId));
                        btnSend.Visibility = Visibility.Hidden;
                        return _rptDisplay;

                    case "QuotationList_User":
                        _rptDisplay.Load(_strReportFolder + "rptQuotationList_User.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(cntDB.Instance.getQuotationItemInfoOnId(this.DateFrom, this.DateTo, this.EnquiryId, this.DocumentId));
                        btnSend.Visibility = Visibility.Hidden;

                        return _rptDisplay;

                    case "EnquiryList_Client":
                        _rptDisplay.Load(_strReportFolder + "rptEnquiryList_Status.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(cntDB.Instance.getEnquiryInfoOnStatus_Client(EnquiryStatus, this.DateFrom, this.DateTo, this.EnquiryId));
                        btnSend.Visibility = Visibility.Hidden;

                        return _rptDisplay;

                    case "EnquiryList_Distributor":
                        _rptDisplay.Load(_strReportFolder + "rptEnquiryList_Distributor.rpt", OpenReportMethod.OpenReportByTempCopy);
                        _rptDisplay.SetDataSource(cntDB.Instance.getEnquiryInfoOnStatus_Distributor(EnquiryStatus, this.DateFrom, this.DateTo, this.EnquiryId));
                        btnSend.Visibility = Visibility.Hidden;

                        return _rptDisplay;

                    case "Category Register":
                        _rptDisplay.Load(_strReportFolder + "rptCategoryRegister.rpt", OpenReportMethod.OpenReportByTempCopy);
                        dtData = cntDB.Instance.getCategoryRegister(this.CategoryCode, this.ItemGroupName);
                        if (SortColumn != null && SortColumn.Trim().Length > 0)
                        {
                            dtData.DefaultView.Sort = string.Format("{0} {1}", SortColumn, SortDirection);
                        }
                        _rptDisplay.SetDataSource(dtData.DefaultView);
                        // _rptDisplay.SetDataSource(cntDB.Instance.getCategoryRegister(this.CategoryCode, this.ItemGroupName));
                        btnSend.Visibility = Visibility.Hidden;

                        return _rptDisplay;

                    case "Product Register":
                        _rptDisplay.Load(_strReportFolder + "rptItemRegister.rpt", OpenReportMethod.OpenReportByTempCopy);
                        dtData = cntDB.Instance.getFCGItemRegister(this.ItemCode, this.CategoryName, this.ItemGroupName);
                        if (SortColumn != null && SortColumn.Trim().Length > 0)
                        {
                            dtData.DefaultView.Sort = string.Format("{0} {1}", SortColumn, SortDirection);
                        }
                        _rptDisplay.SetDataSource(dtData.DefaultView);
                        //_rptDisplay.SetDataSource(cntDB.Instance.getFCGItemRegister(this.ItemCode, this.CategoryName, this.ItemGroupName));
                        btnSend.Visibility = Visibility.Hidden;

                        return _rptDisplay;

                    case "Client Register":
                        _rptDisplay.Load(_strReportFolder + "rptClientRegister.rpt", OpenReportMethod.OpenReportByTempCopy);
                        dtData = cntDB.Instance.getClientRegister(this.CompanyCode, this.CompanyName, this.LocationCity, this.ContactPerson, this.ContacteMail);
                        if (SortColumn != null && SortColumn.Trim().Length > 0)
                        {
                            dtData.DefaultView.Sort = string.Format("{0} {1}", SortColumn, SortDirection);
                        }
                        _rptDisplay.SetDataSource(dtData.DefaultView);
                        btnSend.Visibility = Visibility.Hidden;

                        return _rptDisplay;

                    case "Distributor Register":
                        _rptDisplay.Load(_strReportFolder + "rptDistributorRegister.rpt", OpenReportMethod.OpenReportByTempCopy);
                        dtData = cntDB.Instance.getDistributorRegister(this.CompanyName, this.ContactPerson);
                        if (SortColumn != null && SortColumn.Trim().Length > 0)
                        {
                            dtData.DefaultView.Sort = string.Format("{0} {1}", SortColumn, SortDirection);
                        }
                        _rptDisplay.SetDataSource(dtData.DefaultView);
                        //_rptDisplay.SetDataSource(cntDB.Instance.getDistributorRegister(this.CompanyName, this.ContactPerson));
                        btnSend.Visibility = Visibility.Hidden;

                        return _rptDisplay;
                }
            }
            catch (CrystalReportsException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }

            return _rptDisplay;
        }

        private void setParameters(string pramName, object pValue, ReportDocument pRptDisplay)
        {
            ParameterFieldDefinitions crParameterFieldDefinitions;
            ParameterValues crParameterValues;

            ParameterFieldDefinition crParameterField;
            ParameterDiscreteValue crParameterDiscreteValue;

            try
            {
                crParameterFieldDefinitions = pRptDisplay.DataDefinition.ParameterFields;
                crParameterField = crParameterFieldDefinitions[pramName];

                crParameterValues = crParameterField.CurrentValues;

                crParameterDiscreteValue = new ParameterDiscreteValue();
                crParameterDiscreteValue.Value = pValue;
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterField.ApplyCurrentValues(crParameterValues);
            }
            catch (CrystalReportsException rex)
            {
                throw rex;
            }
        }

        private string getAnnexureInfo()
        {
            StringBuilder sb = new StringBuilder();

            int i = 1;
            sb.Append("\" \"");
            foreach (ReportOption itm in lstReportOptions.Items)
            {
                if (itm.isMarked)
                {

                    sb.Append("& chr(13) &");
                    sb.Append("\"");
                    sb.Append("Annexure ").Append(i.ToString()).Append(" : ").Append(itm.OptionName);
                    sb.Append("\"");

                    i++;
                }
            }
            return sb.ToString();
        }

        private string getAnnexureInfo(string pOptionType)
        {
            StringBuilder sb = new StringBuilder();

            int i = 1;
            foreach (ReportOption itm in lstReportOptions.Items)
            {
                if (itm.isMarked)
                {
                    if (itm.OptionName == pOptionType)
                    {
                        return string.Format("'{0} {1}: {2}'", "Annexure ", i.ToString(), itm.OptionName);
                    }
                    i++;
                }
            }

            return "' '";
        }

        private string ConditionList = string.Empty;

        private string getConditionList(string pRegretNos)
        {
            string[] RegNos = pRegretNos.Split(',');
            string[] RegretReasons = new string[6];

            RegretReasons[0] = "Specified Products by you are not in our present range of Products.";
            RegretReasons[1] = "Technical Specifications of your Enquiry are not Complete/Clear. Kindly provide the proper details to submit our offer.";
            RegretReasons[2] = "Products specified by you are not our make (Proprietary items  for others).";
            RegretReasons[3] = "Specified products are not Standard and uneconomical to develop.";
            RegretReasons[4] = "Required product quantity(s) are too small to submit our offer.";
            RegretReasons[5] = "Due to present load at our factory, we are not in position to complies your delivery schedule & submit our offer.";

            StringBuilder sb = new StringBuilder();
            sb.Append("\" \"");

            int i = 1;
            int j = 0;

            foreach (string itm in RegNos)
            {
                if (itm != "0")
                {
                    sb.Append("& chr(13) &");
                    sb.Append("\"");
                    sb.Append(string.Format("{0}. {1}", i.ToString(), RegretReasons[j]));
                    sb.Append("\"");
                    i++;
                }
                j++;
            }

            return sb.ToString();
        }

        #endregion

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Instance.Cursor = Cursors.Wait;
            ShowReport(false);
        }

        private void btnSend_Click(object sender, RoutedEventArgs e)
        {
            if (txtSubject.Text.Trim().Length == 0)
            {
                MessageBox.Show("Please Enter Subject.", "ChecknTrack", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            bool _isRecipeintSelected = false;
            foreach (cntRecipient itm in lstRecipient.Items)
            {
                if (itm.isMarked)
                {
                    _isRecipeintSelected = true;
                    break;
                }
            }
            if (_isRecipeintSelected == false)
            {
                MessageBox.Show("Please select recipient(s).", "ChecknTrack", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (lstAttchment.Items.Count == 0)
            {
                MessageBox.Show("Please add attachment(s).", "ChecknTrack", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            try
            {
                using (ErrorLoggingDLL.OutlookMail oMail = new ErrorLoggingDLL.OutlookMail(string.Empty, string.Empty))
                {
                    string _recipients = string.Empty;
                    string _ccs = string.Empty;
                    string _files = string.Empty;

                    foreach (cntRecipient itm in lstRecipient.Items)
                    {
                        if (itm.isMarked) _recipients += itm.eMail + ";";
                    }
                    _recipients.Trim(';');
                    foreach (cntRecipient itm in lstCC.Items)
                    {
                        if (itm.isMarked) _ccs += itm.eMail + ";";
                    }
                    _ccs.Trim(';');

                    Console.WriteLine("OutlookMail instantiated");
                    foreach (cntFile itm in lstAttchment.Items)
                    {
                        _files += itm.FilePath + ";";
                    }
                    _files.Trim(';');

                    oMail.addToOutBox(_recipients, _ccs, ConfigurationManager.AppSettings["BCC"].ToString(), txtSubject.Text, geteMailBody(), _files);
                    Console.WriteLine("Email added to outbox");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
            return;

            clsEMail _eMail = new clsEMail(ConfigurationManager.AppSettings["SMTPServer"].ToString());
            try
            {
                int _portno = 0, _timeOut = 0;
                int.TryParse(ConfigurationManager.AppSettings["SMTPPort"].ToString(), out _portno);
                int.TryParse(ConfigurationManager.AppSettings["Timeout"].ToString(), out _timeOut);

                _eMail.mailCredentials = ConfigurationManager.AppSettings["SMTPUId"].ToString() + "," + ConfigurationManager.AppSettings["SMTPPwd"].ToString();
                _eMail.mailSubject = txtSubject.Text;
                _eMail.mailBody = geteMailBody();
                _eMail.mailPort = _portno;
                _eMail.mailTimeout = _timeOut;

                _eMail.AddeMailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString(), "From");
                foreach (cntRecipient itm in lstRecipient.Items)
                {
                    if (itm.isMarked) _eMail.AddeMailAddress(itm.eMail, "To");
                }
                foreach (cntRecipient itm in lstCC.Items)
                {
                    if (itm.isMarked) _eMail.AddeMailAddress(itm.eMail, "CC");
                }
                _eMail.AddeMailAddress(ConfigurationManager.AppSettings["BCC"].ToString(), "BCC");
                foreach (cntFile itm in lstAttchment.Items)
                {
                    _eMail.AddAttachment(itm.FilePath);
                }
                MainWindow.Instance.sendMail(_eMail);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }


        }

        private void btnSend_Click2()
        {
            if (txtSubject.Text.Trim().Length == 0)
            {
                MessageBox.Show("Please Enter Subject.", "ChecknTrack", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            bool _isRecipeintSelected = false;
            foreach (cntRecipient itm in lstRecipient.Items)
            {
                if (itm.isMarked)
                {
                    _isRecipeintSelected = true;
                    break;
                }
            }
            if (_isRecipeintSelected == false)
            {
                MessageBox.Show("Please select recipient(s).", "ChecknTrack", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (lstAttchment.Items.Count == 0)
            {
                MessageBox.Show("Please add attachment(s).", "ChecknTrack", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            clsEMail _eMail = new clsEMail(ConfigurationManager.AppSettings["SMTPServer"].ToString());
            try
            {
                int _portno = 0, _timeOut = 0;
                int.TryParse(ConfigurationManager.AppSettings["SMTPPort"].ToString(), out _portno);
                int.TryParse(ConfigurationManager.AppSettings["Timeout"].ToString(), out _timeOut);

                _eMail.mailCredentials = ConfigurationManager.AppSettings["SMTPUId"].ToString() + "," + ConfigurationManager.AppSettings["SMTPPwd"].ToString();
                _eMail.mailSubject = txtSubject.Text;
                _eMail.mailBody = geteMailBody();
                _eMail.mailPort = _portno;
                _eMail.mailTimeout = _timeOut;

                _eMail.AddeMailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString(), "From");
                foreach (cntRecipient itm in lstRecipient.Items)
                {
                    if (itm.isMarked) _eMail.AddeMailAddress(itm.eMail, "To");
                }
                foreach (cntRecipient itm in lstCC.Items)
                {
                    if (itm.isMarked) _eMail.AddeMailAddress(itm.eMail, "CC");
                }
                _eMail.AddeMailAddress(ConfigurationManager.AppSettings["BCC"].ToString(), "BCC");
                foreach (cntFile itm in lstAttchment.Items)
                {
                    _eMail.AddAttachment(itm.FilePath);
                }
                //_eMail.sendMail();
                //cntCommon.sendeMail(_eMail);
                MainWindow.Instance.sendMail(_eMail);
                //this.Close();
                //MessageBox.Show("Sent!");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }


            //try
            //{
            //    MailMessage mail = new MailMessage();
            //    SmtpClient SmtpServer = new SmtpClient(ConfigurationManager.AppSettings["SMTPServer"].ToString());
            //    mail.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());
            //    mail.Bcc.Add(new MailAddress(ConfigurationManager.AppSettings["BCC"].ToString()));

            //    foreach (cntRecipient itm in lstRecipient.Items)
            //    {
            //        if (itm.isMarked) mail.To.Add(itm.eMail);
            //    }

            //    foreach (cntRecipient itm in lstCC.Items)
            //    {
            //        if (itm.isMarked) mail.CC.Add(itm.eMail);
            //    }

            //    mail.Subject = txtSubject.Text;
            //    mail.Body = geteMailBody();

            //    foreach (cntFile itm in lstAttchment.Items)
            //    {
            //        mail.Attachments.Add(new System.Net.Mail.Attachment(itm.FilePath));
            //    }

            //    int _portno = 0;
            //    int.TryParse(ConfigurationManager.AppSettings["SMTPPort"].ToString(), out _portno);

            //    SmtpServer.Port = _portno;
            //    SmtpServer.UseDefaultCredentials = false;
            //    SmtpServer.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["SMTPUId"].ToString(), ConfigurationManager.AppSettings["SMTPPwd"].ToString());
            //    SmtpServer.EnableSsl = false;
            //    SmtpServer.Timeout = int.Parse(ConfigurationManager.AppSettings["Timeout"].ToString());

            //    SmtpServer.Send(mail);
            //    MessageBox.Show("eMail Sent", "ChecknTrack", MessageBoxButton.OK, MessageBoxImage.Information);
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.ToString() + " \n eMail Sending Failure.", "ChecknTrack", MessageBoxButton.OK, MessageBoxImage.Stop);
            //}
            //finally
            //{
            //    this.Cursor = null;
            //}
        }

        private string geteMailBody()
        {

            DataTable dtEnquiry = cntDB.Instance.getEnquiryInfoOnId(docEnquiryId);

            StringBuilder sbrBody = new StringBuilder();
            sbrBody.AppendLine("To,");
            sbrBody.AppendLine();

            if (dtEnquiry.Rows.Count > 0) sbrBody.AppendLine("Kind Attn:" + dtEnquiry.Rows[0]["cntM_ContactPerson"].ToString());
            sbrBody.AppendLine();
            sbrBody.AppendLine("Dear Sir,");
            sbrBody.AppendLine();
            sbrBody.AppendLine();

            sbrBody.AppendLine("With reference to your enquiry. Please find copy of our response attached here, for your reference/consideration.");
            sbrBody.AppendLine();
            sbrBody.AppendLine();

            sbrBody.AppendLine("Regards,");
            sbrBody.AppendLine();
            sbrBody.AppendLine("For FCG POWER INDUSTRIES P. Ltd.");
            sbrBody.AppendLine();
            sbrBody.AppendLine();
            if (dtEnquiry.Rows.Count > 0)
            {
                sbrBody.AppendLine(dtEnquiry.Rows[0]["stfM_Name"].ToString());
                sbrBody.AppendLine(dtEnquiry.Rows[0]["stfM_eMail"].ToString());
            }
            sbrBody.AppendLine();
            sbrBody.AppendLine("REGD. OFFICE: A1/61, SHAH & NAHAR IND. ESTATE, SITARAM JADHAV MARG, LOWER PAREL(W), MUMBAI- 400 013. INDIA.");
            sbrBody.AppendLine("PHONE: 2496 4962/ 2492 6355/ 2492 5269 FAX: 91(22) 2496 4965 @EMAIL: info@fcgpower.com");
            sbrBody.AppendLine("http://www.fcgpower.com");

            return sbrBody.ToString();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            bool _hasFile = false;
            try
            {
                _hasFile = openDialog.ShowDialog().Value;
                if (_hasFile)
                {
                    cntFile _file = new cntFile();
                    _file.FilePath = openDialog.FileName;
                    _FileList.Add(_file);
                }
                lstAttchment.ItemsSource = null;
                lstAttchment.ItemsSource = _FileList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
        }

        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            if (null == lstAttchment.SelectedItem) return;
            _FileList.Remove(lstAttchment.SelectedItem as cntFile);
            lstAttchment.ItemsSource = null;
            lstAttchment.ItemsSource = _FileList;
        }
    }

    class ReportOption
    {
        public int OptionValue { get; set; }

        public string OptionName { get; set; }

        public bool isMarked { get; set; }
    }

    class cntFile
    {
        public string FilePath { get; set; }

        public string FileName
        {
            get
            {
                int _startIdx = this.FilePath.LastIndexOf(@"\") + 1;
                return this.FilePath.Substring(_startIdx, (this.FilePath.Length - _startIdx));
            }
        }

        public bool isMarked { get; set; }
    }

    class cntRecipient
    {
        public string eMail { get; set; }
        public bool isMarked { get; set; }

    }
}

//1.

//CrystalDecisions.CrystalReports.Engine.ReportDocument crReportDocument = new CrystalDecisions.CrystalReports.Engine.ReportDocument();
//crReportDocument.Load("CrystalReport1.rpt");
//crReportDocument.SetDatabaseLogon("sa", "sa"); 
//CrystalReportsViewer1.ViewerCore.ReportSource = crReportDocument;

//2.
//DataTable dt = cntDB.Instance.getClientInfo();

//CrystalReport1 objMasterLog = new CrystalReport1();
//objMasterLog.SetDataSource(dt);
//objMasterLog.SetDatabaseLogon("sa", "sa"); 
//CrystalReportsViewer1.ViewerCore.ReportSource = objMasterLog;





