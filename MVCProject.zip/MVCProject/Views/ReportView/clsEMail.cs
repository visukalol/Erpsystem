﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;

namespace ChecknTrack.View.ReportView
{
    public class clsEMail
    {
        MailMessage fcgMail;
        SmtpClient fcgSMTPClient;
        private string _mailSubject = string.Empty;
        private string _mailBody = string.Empty;
        private int _mailPort = 0;
        private string _mailCredentials = string.Empty;
        private int _mailTimeout = 0;


        public clsEMail() { }

        public clsEMail(string pSMTPServer)
        {
            fcgMail = new MailMessage();
            fcgSMTPClient = new SmtpClient(pSMTPServer);
            fcgSMTPClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            //fcgSMTPClient.SendCompleted += new SendCompletedEventHandler(fcgSMTPClient_SendCompleted);
        }

        void fcgSMTPClient_SendCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public string mailSubject
        {
            get { return _mailSubject; }
            set
            {
                _mailSubject = value;
                fcgMail.Subject = _mailSubject;
            }
        }
        public string mailBody
        {
            get { return _mailBody; }
            set
            {
                _mailBody = value;
                fcgMail.Body = _mailBody;
            }
        }
        public int mailPort
        {
            get { return _mailPort; }
            set
            {
                _mailPort = value;
                fcgSMTPClient.Port = _mailPort;
            }
        }
        public string mailCredentials
        {
            get { return _mailCredentials; }
            set
            {
                _mailCredentials = value;
                fcgSMTPClient.UseDefaultCredentials = false;
                fcgSMTPClient.Credentials = new System.Net.NetworkCredential(_mailCredentials.Split(',')[0], _mailCredentials.Split(',')[1]);
                fcgSMTPClient.EnableSsl = false;
            }
        }
        public int mailTimeout
        {
            get { return _mailTimeout; }
            set
            {
                _mailTimeout = value;
                fcgSMTPClient.Timeout = _mailTimeout;
            }
        }

        public void AddeMailAddress(string pEMail, string pType)
        {

            switch (pType.ToLower())
            {
                case "from":
                    fcgMail.From = new MailAddress(pEMail);
                    break;
                case "to":
                    fcgMail.To.Add(new MailAddress(pEMail));
                    break;
                case "cc":
                    fcgMail.CC.Add(new MailAddress(pEMail));
                    break;
                case "bcc":
                    fcgMail.Bcc.Add(new MailAddress(pEMail));
                    break;
            }
        }

        public void AddAttachment(string pPath)
        {
            fcgMail.Attachments.Add(new System.Net.Mail.Attachment(pPath));
        }

        public void sendMail()
        {
            try
            {
                fcgSMTPClient.Send(fcgMail);
                MainWindow.Instance.someProperty = string.Format("eMail sent successfully.");
            }
            catch (Exception ex)
            {
                MainWindow.Instance.someProperty = "Email sending Error: \n" + ex.Message;
                throw (ex);
            }
            finally
            {
                //fcgMail.Dispose();
                //fcgSMTPClient.Dispose();
            }
        }
    }
}
