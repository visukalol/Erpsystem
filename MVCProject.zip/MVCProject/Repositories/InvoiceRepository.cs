﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;
using System.Data.SqlClient;

namespace MVCProject.Repositories
{
    public class InvoiceRepository : IInvoiceRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;

        //Initiliaze DB connection 
        public InvoiceRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //-----------------//
        //INVOICE INFO
        //-----------------//

        //DB - Insert Record
        public bool InsertInvoiceInfo(InvoiceInfoReq invoiceInfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_InvoiceInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},
                {15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26},{27},
                {28},{29},{30},{31},{32},{33}",
                invoiceInfoReq.invM_No,
                invoiceInfoReq.invM_Date,
                invoiceInfoReq.invM_GrossAmount,
                invoiceInfoReq.invM_Amount,
                invoiceInfoReq.invM_WOMId,
                invoiceInfoReq.invM_ClMId,
                invoiceInfoReq.invM_LcMId,
                invoiceInfoReq.invM_ConsigneeId,
                invoiceInfoReq.invM_ConsigneeLcMId,
                invoiceInfoReq.invM_CurrencyName,
                invoiceInfoReq.invM_ChallanNo,
                invoiceInfoReq.invM_OrderNo,
                invoiceInfoReq.invM_WONo,
                invoiceInfoReq.invM_RemovalDate,
                invoiceInfoReq.invM_DespatchMode,
                invoiceInfoReq.invM_VehicleNo,
                invoiceInfoReq.invM_ExcisableCommodity,
                invoiceInfoReq.invM_TariffNo,
                invoiceInfoReq.invM_ChallanDate,
                invoiceInfoReq.invM_WorkOrderDate,
                invoiceInfoReq.invM_OrderDate,
                invoiceInfoReq.invM_stfMId,
                invoiceInfoReq.invM_yrMId,
                invoiceInfoReq.invM_AdvanceAmount,
                invoiceInfoReq.invM_Remarks,
                invoiceInfoReq.invM_DespatchDetail,
                invoiceInfoReq.invM_DespatchDate,
                invoiceInfoReq.invM_PaymentMode,
                invoiceInfoReq.invM_FinalAmount,
                invoiceInfoReq.invM_lcnMId,
                invoiceInfoReq.invM_Rchrg,
                invoiceInfoReq.invM_invTyp,
                invoiceInfoReq.invM_bnkMId,
                invoiceInfoReq.invM_placeofsupply
                );
            return true;
        }

        //DB - Update Record
        public bool UpdateInvoiceInfo(InvoiceInfoResp invoiceInfoResp, int p1)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpUpdate_InvoiceInfo] {0},{1},{2},{3},{4},{5},{6},
                {7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},
                {20},{21},{22},{23},{24},{25},{26},{27},{28},{29},{30},{31},{32}",
                invoiceInfoResp.InvM_Id,
                invoiceInfoResp.invM_No,
                invoiceInfoResp.invM_Date,
                invoiceInfoResp.invM_GrossAmount,
                invoiceInfoResp.invM_Amount,
                invoiceInfoResp.invM_WOMId,
                invoiceInfoResp.invM_ClMId,
                invoiceInfoResp.invM_LcMId,
                invoiceInfoResp.invM_ConsigneeId,
                invoiceInfoResp.invM_ConsigneeLcMId,
                invoiceInfoResp.invM_CurrencyName,
                invoiceInfoResp.invM_ChallanNo,
                invoiceInfoResp.invM_OrderNo,
                invoiceInfoResp.invM_WONo,
                invoiceInfoResp.invM_RemovalDate,
                invoiceInfoResp.invM_DespatchMode,
                invoiceInfoResp.invM_VehicleNo,
                invoiceInfoResp.invM_ExcisableCommodity,
                invoiceInfoResp.invM_TariffNo,
                invoiceInfoResp.invM_ChallanDate,
                invoiceInfoResp.invM_WorkOrderDate,
                invoiceInfoResp.invM_OrderDate,
                invoiceInfoResp.invM_stfMId,
                invoiceInfoResp.invM_AdvanceAmount,
                invoiceInfoResp.invM_Remarks,
                invoiceInfoResp.invM_DespatchDetail,
                invoiceInfoResp.invM_DespatchDate,
                invoiceInfoResp.invM_PaymentMode,
                invoiceInfoResp.invM_FinalAmount,
                //invoiceInfoResp.invM_Rchrg,
                invoiceInfoResp.invM_invTyp,
                invoiceInfoResp.invM_bnkMId,
                invoiceInfoResp.invM_placeofsupply);
            return true;
        }

        //DB - Delete Record
        public bool DeleteInvoiceInfo(InvoiceInfoResp invoiceInfoResp, int p1)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpDelete_InvoiceInfo] {0}",
                "InvM_Id = " + invoiceInfoResp.InvM_Id);
            return true;
        }

        //DB - Viewlist Record
        public List<InvoiceInfoResp> InvoiceInfoResp(int p1)
        {
            var response = _dbContent.Database.SqlQuery<InvoiceInfoResp>
                (@"Exec [dbo].[spGet_InvoiceInfo] {0}", p1).ToList();
            return response;
        }

        //-----------------//
        //INVOICEDETAIL INFO
        //-----------------//

        //DB - Insert Record
        public bool InsertInvoiceDetailInfo(InvoiceDetailInfoReq invoiceDetailInfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_InvoiceDetailInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},
                {15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26},{27},
                {28},{29},{30},{31},{32}",
                invoiceDetailInfoReq.invD_invMId,
                invoiceDetailInfoReq.invD_itMId,
                invoiceDetailInfoReq.invD_DetailDescription,
                invoiceDetailInfoReq.invD_Quantity,
                invoiceDetailInfoReq.invD_Rate,
                invoiceDetailInfoReq.invD_Amount,
                invoiceDetailInfoReq.invD_ItemDescriptionInvoice,
                invoiceDetailInfoReq.invD_ItemRank,
                invoiceDetailInfoReq.invD_PackingAndForwarding,
                invoiceDetailInfoReq.invD_Excise,
                invoiceDetailInfoReq.invD_ADSPExcise,
                invoiceDetailInfoReq.invD_HADSPExcise,
                invoiceDetailInfoReq.invD_Pkgs,
                invoiceDetailInfoReq.invD_AvgContent,
                invoiceDetailInfoReq.invD_PackingAndForwardingAmount,
                invoiceDetailInfoReq.invD_ExciseAmount,
                invoiceDetailInfoReq.invD_ADSPExciseAmount,
                invoiceDetailInfoReq.invD_HADSPExciseAmount,
                invoiceDetailInfoReq.invD_HSNSACId,
                invoiceDetailInfoReq.invD_IGSTId,
                invoiceDetailInfoReq.invD_Freight,
                invoiceDetailInfoReq.invD_IGSTRate,
                invoiceDetailInfoReq.invD_IGSTAmount,
                invoiceDetailInfoReq.invD_CGSTId,
                invoiceDetailInfoReq.invD_CGSTRate,
                invoiceDetailInfoReq.invD_CGSTAmount,
                invoiceDetailInfoReq.invD_SGSTId,
                invoiceDetailInfoReq.invD_SGSTRate,
                invoiceDetailInfoReq.invD_SGSTAmount,
                invoiceDetailInfoReq.invD_NettAmount,
                invoiceDetailInfoReq.invD_wodId,
                invoiceDetailInfoReq.invD_woMId
                );
            return true;
        }

        //DB - Update Record
        public bool UpdateInvoiceDetailInfo(InvoiceDetailInfoResp invoiceDetailInfoResp, int p1)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_InvoiceDetailInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},
                {15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26},{27},
                {28},{29},{30},{31},{32}",
                "invD_Id = " + invoiceDetailInfoResp.invD_Id,
                invoiceDetailInfoResp.invD_invMId,
                invoiceDetailInfoResp.invD_itMId,
                invoiceDetailInfoResp.invD_DetailDescription,
                invoiceDetailInfoResp.invD_Quantity,
                invoiceDetailInfoResp.invD_Rate,
                invoiceDetailInfoResp.invD_Amount,
                invoiceDetailInfoResp.invD_ItemDescriptionInvoice,
                invoiceDetailInfoResp.invD_ItemRank,
                invoiceDetailInfoResp.invD_PackingAndForwarding,
                invoiceDetailInfoResp.invD_Excise,
                invoiceDetailInfoResp.invD_ADSPExcise,
                invoiceDetailInfoResp.invD_HADSPExcise,
                invoiceDetailInfoResp.invD_Pkgs,
                invoiceDetailInfoResp.invD_AvgContent,
                invoiceDetailInfoResp.invD_PackingAndForwardingAmount,
                invoiceDetailInfoResp.invD_ExciseAmount,
                invoiceDetailInfoResp.invD_ADSPExciseAmount,
                invoiceDetailInfoResp.invD_HADSPExciseAmount,
                invoiceDetailInfoResp.invD_HSNSACId,
                invoiceDetailInfoResp.invD_IGSTId,
                invoiceDetailInfoResp.invD_Freight,
                invoiceDetailInfoResp.invD_IGSTRate,
                invoiceDetailInfoResp.invD_IGSTAmount,
                invoiceDetailInfoResp.invD_CGSTId,
                invoiceDetailInfoResp.invD_CGSTRate,
                invoiceDetailInfoResp.invD_CGSTAmount,
                invoiceDetailInfoResp.invD_SGSTId,
                invoiceDetailInfoResp.invD_SGSTRate,
                invoiceDetailInfoResp.invD_SGSTAmount,
                invoiceDetailInfoResp.invD_NettAmount,
                invoiceDetailInfoResp.invD_wodId,
                invoiceDetailInfoResp.invD_woMId
                );
            return true;
        }

        //DB - Delete Record
        public bool DeleteInvoiceDetailInfo(InvoiceDetailInfoResp invoiceDetailInfoResp, int p1)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpDelete_InvoiceDetailInfo] {0}",
                "InvD_Id = " + invoiceDetailInfoResp.invD_Id);
            return true;
        }

        //DB - Viewlist Record
        public List<InvoiceDetailInfoResp> InvoiceDetailInfoResp(int p1)
        {
            var response = _dbContent.Database.SqlQuery<InvoiceDetailInfoResp>
                (@"Exec [dbo].[spGet_InvoiceItemAllItemsInfo] {0}", p1).ToList();
            return response;
        }

        //-----------------//
        //INVOICEDETAILTAX INFO
        //-----------------//

        //DB - Insert Record
        public bool InsertInvoiceDetailTaxInfo(InvoiceDetailTaxInfoReq invoiceDetailTaxInfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_InvoiceDetailTaxInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}",
                invoiceDetailTaxInfoReq.invtxD_invDId,
                invoiceDetailTaxInfoReq.invtxD_invMId,
                invoiceDetailTaxInfoReq.invtxD_txMId,
                invoiceDetailTaxInfoReq.invtxD_Percentage,
                invoiceDetailTaxInfoReq.invtxD_Amount,
                invoiceDetailTaxInfoReq.invtxD_CGSTId,
                invoiceDetailTaxInfoReq.invtxD_CGSTRate,
                invoiceDetailTaxInfoReq.invtxD_CGSTAmount,
                invoiceDetailTaxInfoReq.invtxD_SGSTId,
                invoiceDetailTaxInfoReq.invtxD_SGSTRate,
                invoiceDetailTaxInfoReq.invtxD_SGSTAmount,
                invoiceDetailTaxInfoReq.invtxD_IGSTId,
                invoiceDetailTaxInfoReq.invtxD_IGSTRate,
                invoiceDetailTaxInfoReq.invtxD_IGSTAmount
                        );
            return true;
        }

        //DB - Update Record
        public bool UpdateInvoiceDetailTaxInfo(InvoiceDetailTaxInfoResp invoiceDetailTaxInfoResp, int p1)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpUpdate_InvoiceDetailInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14}",
                invoiceDetailTaxInfoResp.invtxD_Id,
                invoiceDetailTaxInfoResp.invtxD_invDId,
                invoiceDetailTaxInfoResp.invtxD_invMId,
                invoiceDetailTaxInfoResp.invtxD_txMId,
                invoiceDetailTaxInfoResp.invtxD_Percentage,
                invoiceDetailTaxInfoResp.invtxD_Amount,
                invoiceDetailTaxInfoResp.invtxD_CGSTId,
                invoiceDetailTaxInfoResp.invtxD_CGSTRate,
                invoiceDetailTaxInfoResp.invtxD_CGSTAmount,
                invoiceDetailTaxInfoResp.invtxD_SGSTId,
                invoiceDetailTaxInfoResp.invtxD_SGSTRate,
                invoiceDetailTaxInfoResp.invtxD_SGSTAmount,
                invoiceDetailTaxInfoResp.invtxD_IGSTId,
                invoiceDetailTaxInfoResp.invtxD_IGSTRate,
                invoiceDetailTaxInfoResp.invtxD_IGSTAmount
                );
            return true;
        }

        //DB - Delete Record
        public bool DeleteInvoiceDetailTaxInfo(InvoiceDetailTaxInfoResp invoiceDetailTaxInfoResp, int p1)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpDelete_InvoiceDetailTaxInfo] {0}",
                "invtxD_Id = " + invoiceDetailTaxInfoResp.invtxD_Id);
            return true;
        }

        //DB - Viewlist Record
        public List<InvoiceDetailTaxInfoResp> InvoiceDetailTaxInfoResp(int p1)
        {
            var response = _dbContent.Database.SqlQuery<InvoiceDetailTaxInfoResp>
                (@"Exec [dbo].[spGet_InvoiceDetailItemAllTaxInfo] {0}", p1).ToList();
            return response;
        }

        //DB - Viewlist Record
        public List<InvoiceInfoResp> GetInvoiceRegister(int? p1, DateTime? d1, DateTime? d2, int? p2)
        {
            //var p1 = 20;
            //var d1 = Convert.ToDateTime("1900-01-01");
            //var d2 = Convert.ToDateTime("2021-01-21");
            //var p2 = 1;

            var response = _dbContent.Database.SqlQuery<InvoiceInfoResp>
                (@"Exec [dbo].[spGet_InvoiceRegister] 
                @StaffId,
                @InvoiceDt1,
                @InvoiceDt2,
                @invM_lcnMId",
                new SqlParameter("@StaffId", p1),
                new SqlParameter("@InvoiceDt1", d1),
                new SqlParameter("@InvoiceDt2", d2),
                new SqlParameter("@invM_lcnMId", p2)
                ).ToList();
            return response;
        }
    }
}