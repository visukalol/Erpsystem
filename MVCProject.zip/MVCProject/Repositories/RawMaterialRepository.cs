﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;

namespace MVCProject.Repositories
{
    public class RawMaterialRepository : IRawMaterialRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;

        //Initiliaze DB connection 
        public RawMaterialRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //DB - Insert Record
        public bool InsertRawMaterial(RawMaterialReq rawMaterialReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_RawMaterialInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8}",
                rawMaterialReq.rawM_Name.Trim(),
                rawMaterialReq.rawM_Code.Trim(),
                rawMaterialReq.rawM_Description.Trim(),
                rawMaterialReq.rawM_catMId,
                rawMaterialReq.rawM_Make.Trim(),
                rawMaterialReq.rawM_Unit.Trim(),
                rawMaterialReq.rawM_PricingMethod.Trim(),
                rawMaterialReq.rawM_ReorderLevel,
                rawMaterialReq.rawM_OpQty);
            return true;
        }

        //DB - Update Record
        public bool UpdateRawMaterial(RawMaterialReq rawMaterialResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_RawMaterialInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9}",
                rawMaterialResp.rawM_Id,
                rawMaterialResp.rawM_Name.Trim(),
                rawMaterialResp.rawM_Code.Trim(),
                rawMaterialResp.rawM_Description.Trim(),
                rawMaterialResp.rawM_catMId,
                rawMaterialResp.rawM_Make.Trim(),
                rawMaterialResp.rawM_Unit.Trim(),
                rawMaterialResp.rawM_PricingMethod.Trim(),
                rawMaterialResp.rawM_ReorderLevel,
                rawMaterialResp.rawM_OpQty);
            return true;
        }

        //DB - Delete Record
        public bool DeleteRawMaterial(RawMaterialReq rawMaterialResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpDelete_RawMaterialInfo] {0}",
                rawMaterialResp.rawM_Id);
            return true;
        }

        //DB - Viewlist Record
        public List<GetRawMaterialResp> GetAllRawMaterial()
        {
            var response = _dbContent.Database.SqlQuery<GetRawMaterialResp>
                (@"Exec [dbo].[spGet_RawMaterialInfo] {0}","0").ToList();
            return response;
        }
            
        //DB - Viewlist Record
        public List<GetRawCategoryInfoResp> GetRawCategoryInfo()
        {
            var response = _dbContent.Database.SqlQuery<GetRawCategoryInfoResp>
                (@"Exec [dbo].[spGet_RawMaterialInfo] {0}", "1").ToList();
            return response;
        }

        //DB - Insert RawMaterialCategoryMaster Record
        public bool InsertRawMaterialCategory(RawMaterialCategoryReq rawMaterialCategoryReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_RawCategoryType]
                {0},{1},{2},{3}",

                rawMaterialCategoryReq.raw_Cat1.Trim(),
                rawMaterialCategoryReq.raw_Cat2.Trim(),
                rawMaterialCategoryReq.raw_Cat3.Trim(),
                rawMaterialCategoryReq.raw_Cat4.Trim());
            return true;
        }

        //DB - Get RawMaterialCategoryMaster Record
        public List<GetRawCategoryResp> GetRawCategory()
        {
            var response = _dbContent.Database.SqlQuery<GetRawCategoryResp>
                (@"Exec [dbo].[spGet_RawCategoryType] ").ToList();
            return response;
        }

    }
}