﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;

namespace MVCProject.Repositories
{
    public class TnCRepository : ITnCRepository
    {
        //Variable declaration of DB Connection
        private ChecnTrack_MainDB _ChecnTrack_MainDB;

        //Initiliaze DB connection 
        public TnCRepository(ChecnTrack_MainDB ChecnTrack_MainDB)
        {
            _ChecnTrack_MainDB = ChecnTrack_MainDB;
        }

        //DB - Insert Record
        public bool InsertTnCMaster(TnCMasterReq TnCMasterReq)
        {
            var response = _ChecnTrack_MainDB.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_TnCInfo] {0},{1}",
                TnCMasterReq.tncM_Text,
                TnCMasterReq.tncM_isDefault);
            return true;
        }

        //DB - Update Record
        public bool UpdateTnCMaster(TnCMasterReq TnCMasterResp)
        {
            var response = _ChecnTrack_MainDB.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_TnCInfo] {0},{1},{2}",
                TnCMasterResp.tncM_Id,
                TnCMasterResp.tncM_Text,
                TnCMasterResp.tncM_isDefault);
            return true;
        }

        //DB - Delete Record
        public bool DeleteTnCMaster(TnCMasterReq TnCMasterResp)
        {
            var response = _ChecnTrack_MainDB.Database.SqlQuery<object>
                (
                @"Exec [dbo].[SpDelete_TnCInfo] {0}",
                "tncM_Id = " + TnCMasterResp.tncM_Id);
            return true;
        }

        //DB - Viewlist Record
        public List<TnCMasterResp> GetAllTnCMaster()
        {
            var response = _ChecnTrack_MainDB.Database.SqlQuery<TnCMasterResp>
                (@"Exec [dbo].[spGet_TnCMasterInfo]").ToList();
            return response;
        }

        //DB - Insert Record
        public bool InsertTnCDescriptionInfo(TnCDescriptionInfoReq TnCDescriptionInfoReq)
        {
            var response = _ChecnTrack_MainDB.Database.SqlQuery<object>
                (
                @"Exec [dbo].[SpInsert_TnCDescriptionInfo] {0},{1},{2}",
                TnCDescriptionInfoReq.tncD_tncMId,
                TnCDescriptionInfoReq.tncD_Description,
                TnCDescriptionInfoReq.tncD_isDefault);
            return true;
        }

        //DB - Update Record
        public bool UpdateTnCDescriptionInfo(TnCDescriptionInfoResp TnCDescriptionInfoResp)
        {
            var response = _ChecnTrack_MainDB.Database.SqlQuery<object>
                (@"Exec [dbo].[SpUpdate_TnCDescriptionInfo] {0},{1}",
                "tncD_Id = " + TnCDescriptionInfoResp.tncD_Id,
                TnCDescriptionInfoResp.tncD_tncMId,
                TnCDescriptionInfoResp.tncD_Description,
                TnCDescriptionInfoResp.tncD_isDefault);
            return true;
        }

        //DB - Delete Record
        public bool DeleteTnCDescriptionInfo(TnCDescriptionInfoResp TnCDescriptionInfoResp)
        {
            var response = _ChecnTrack_MainDB.Database.SqlQuery<object>
                (
                @"Exec [dbo].[SpDelete_TnCDescriptionInfo] {0}",
                "tncD_Id = " + TnCDescriptionInfoResp.tncD_Id);
            return true;
        }

        //DB - Viewlist Record
        // No Get SP       

        //DB - Viewlist Record
        public List<TnCDescriptionInfoResp> GetTnCDescriptionInfo(int? p1)
        {
            var response = _ChecnTrack_MainDB.Database.SqlQuery<TnCDescriptionInfoResp>
                (
                @"Exec [dbo].[spGet_TnCInfo] {0}", p1
                ).ToList();
            return response;
        }
    }
}