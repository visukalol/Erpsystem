﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;

namespace MVCProject.Repositories
{
    public class ItemRepository : IItemRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;        

        //Initiliaze DB connection         
        public ItemRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //DB - Insert Record
        public bool InsertItem(ItemReq itemReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_ItemInfo] {0},{1},{2},{3},{4},{5},{6},
                {7},{8},{9}",
                itemReq.itM_ItemName.Trim(),
                itemReq.itM_ItemDescriptionEnquiry.Trim(),
                itemReq.itM_ItemDescriptionWorkOrder.Trim(),
                itemReq.itM_ItemDescriptionInvoice.Trim(),
                itemReq.itM_Code.Trim(),
                itemReq.@itM_crtDId,
                itemReq.@itM_itgMId,
                itemReq.@itM_CatMId,
                itemReq.@itM_giMId,
                itemReq.@itm_HSNCode);
            return true;
        }

        //DB - Update Record
        public bool UpdateItem(ItemReq itemResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_ItemInfo] {0},{1},{2},{3},{4},{5},{6},
                {7},{8},{9},{10}",
                itemResp.itM_Id,
                itemResp.itM_ItemName.Trim(),
                itemResp.itM_ItemDescriptionEnquiry.Trim(),
                itemResp.itM_ItemDescriptionWorkOrder.Trim(),
                itemResp.itM_ItemDescriptionInvoice.Trim(),
                itemResp.itM_Code.Trim(),
                itemResp.@itM_crtDId,
                itemResp.@itM_itgMId,
                itemResp.@itM_CatMId,
                itemResp.@itM_giMId,
                itemResp.@itm_HSNCode);
            return true;
        }

        //DB - Delete Record
        public bool DeleteItem(ItemReq itemResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpDelete_ItemInfo] {0}",
                itemResp.itM_Id
                );
            return true;
        }

        //List for Item
        public List<GetItemResp> GetAllItem()
        {
            var response = _dbContent.Database.SqlQuery<GetItemResp>
                (@"Exec [dbo].[spGet_ItemInfo]").ToList();
            return response;
        }

        //List for Item
        public List<GetItemResp> GetAllItemCatGrp(int? p1, int? p2)
        {
            var response = _dbContent.Database.SqlQuery<GetItemResp>
                (@"Exec [dbo].[spGet_FilterItemInfo] {0}, {1}", p1, p2).ToList();
            return response;
        }

        //List for ItemGroup
        public List<GetItemGroupResp> GetItemGroupItem()
        {
            var response = _dbContent.Database.SqlQuery<GetItemGroupResp>
                (@"Exec [dbo].[spGet_ItemGroupInfo]").ToList();
            return response;
        }
    }
}