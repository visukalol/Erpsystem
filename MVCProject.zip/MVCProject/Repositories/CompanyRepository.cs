﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;

namespace MVCProject.Repositories
{
    public class CompanyRepository : ICompanyRepository
    {
        //Variable declaration of DB Connection
        private ChecnTrack_MainDB _checnTrack_MainDB;
        private DBContent _dbContent;

        //Initiliaze DB connection 
        public CompanyRepository(ChecnTrack_MainDB checnTrack_MainDB, DBContent dbcontent)
        {
            _dbContent = dbcontent;
            _checnTrack_MainDB = checnTrack_MainDB;
        }

        //DB - Insert Record
        public bool InsertCompany(CompanyReq companyReq)
        {
            var response = _checnTrack_MainDB.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_CompanyInfo1] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},
                {11},{12},{13},{14},{15},{16},{17}",
                //{18},{19},{20},{21}",
                companyReq.cmpM_CompanyName.Trim(),
                companyReq.cmpM_ContactPerson.Trim(),
                companyReq.cmpM_Address.Trim(),
                companyReq.cmpM_MobileNo.Trim(),
                companyReq.cmpM_ContactNumber1.Trim(),
                companyReq.cmpM_ContactNumber2.Trim(),
                companyReq.cmpM_Email.Trim(),
                companyReq.cmpM_Acronym.Trim(),
                companyReq.cmpM_Fax.Trim(),
                companyReq.cmpM_PAN.Trim(),
                companyReq.cmpM_CST.Trim(),
                companyReq.cmpM_VAT.Trim(),
                companyReq.cmpM_GST.Trim(),
                //companyReq.cmpM_picLeft,
                //companyReq.cmpM_picCenter,
                //companyReq.cmpM_picRight,
                companyReq.cmpM_ReportHeading.Trim(),
                companyReq.cmpM_ReportSubHeading.Trim(),
                //companyReq.yrM_DateFrom,
                //companyReq.yrM_DateTo,
                //companyReq.yrM_Name
                //new column addition
                companyReq.cmpM_CIN,
                companyReq.cmpM_TAN,
                companyReq.cmpM_TEC
                //new column addition
                );
            return true;
        }

        //DB - Update Record
        public bool UpdateCompany(CompanyReq companyResp)
        {
            var response = _checnTrack_MainDB.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_CompanyInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},
                {11},{12},{13},{14},{15},{16},{17}",
                companyResp.cmpM_CompanyName.Trim(),
                companyResp.cmpM_ContactPerson.Trim(),
                companyResp.cmpM_Address.Trim(),
                companyResp.cmpM_MobileNo.Trim(),
                companyResp.cmpM_ContactNumber1.Trim(),
                companyResp.cmpM_ContactNumber2.Trim(),
                companyResp.cmpM_Email.Trim(),
                companyResp.cmpM_Fax.Trim(),
                companyResp.cmpM_PAN.Trim(),
                companyResp.cmpM_CST.Trim(),
                companyResp.cmpM_VAT.Trim(),
                companyResp.cmpM_GST.Trim(),
                companyResp.cmpM_Id,
                //companyResp.cmpM_picLeft,
                //companyResp.cmpM_picCenter,
                //companyResp.cmpM_picRight,
                companyResp.cmpM_ReportHeading.Trim(),
                companyResp.cmpM_ReportSubHeading.Trim(),
                companyResp.cmpM_TAN,
                companyResp.cmpM_CIN,
                companyResp.cmpM_TEC);
                //new column addition
            //new column addition
            return true;
        }

        //DB - Delete Record
        //No SP for Company

        //DB - Viewlist Record
        public List<GetCompanyResp> GetAllCompany()
        {
            var response = _checnTrack_MainDB.Database.SqlQuery<GetCompanyResp>
                (@"Exec [dbo].[spGet_CompanyInfo]").ToList();
            return response;
        }

        //DB - Viewlist Record
        public List<GetClientLocationResp> GetCompanyLocation(int? p1, string p2)
        {
            var response = _dbContent.Database.SqlQuery<GetClientLocationResp>
                (@"Exec [dbo].[spGet_ClientLocationInfo] {0}, {1}", p1, p2).ToList();
            return response;
        }

        //DB - Viewlist Record
        public List<ClientBankMasterReq> CompanyBankMaster(int? p1, string p2)
        {
            var response = _dbContent.Database.SqlQuery<ClientBankMasterReq>
                (@"Exec [dbo].[spGet_ClientBankInfo] {0}, {1}", p1, p2).ToList();
            return response;
        }

    }
}