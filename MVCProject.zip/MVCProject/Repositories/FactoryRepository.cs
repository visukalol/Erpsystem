﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Models.ResponseModel.Location;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;

namespace MVCProject.Repositories
{
    public class FactoryRepository : IFactoryRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;

        //Initiliaze DB connection 
        public FactoryRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //**************
        //Table - Factory
        //**************

        //DB - Insert Record
        public bool InsertFactory(FactoryReq factoryReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_GodownFactoryInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},
                {11},{12},{13},{14},{15},{16},{17}",
                factoryReq.gfM_Code.Trim(),
                factoryReq.gfM_Location.Trim(),
                factoryReq.gfM_Address.Trim(),
                factoryReq.gfM_Type.Trim(),
            //"F",
                factoryReq.gfM_ContactPerson.Trim(),
                factoryReq.gfM_ContactNumber1.Trim(),
                factoryReq.gfM_ContactNumber2.Trim(),
                factoryReq.gfM_eMail.Trim(),
                factoryReq.gfM_MobileNo.Trim(),
                factoryReq.gfM_FAX.Trim(),
                factoryReq.gfM_TAN.Trim(),
                factoryReq.gfM_VAT.Trim(),
                factoryReq.gfM_GST.Trim(),
                factoryReq.gfM_CIN.Trim(),
                factoryReq.gfM_City.Trim(),
                factoryReq.gfM_State.Trim(),
                factoryReq.gfM_Region.Trim(),
                factoryReq.gfM_Pincode.Trim());
                return true;
        }

        //DB - Update Record
        public bool UpdateFactory(FactoryReq factoryResp)
        {
            //var response = _dbContent.Database.ExecuteSqlCommand
            //    (
                //@"Exec [dbo].[SpUpdate_GodownFactoryInfo] 
                //{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},
                //{10},{11},{12},{13},{14},{15},{16},{17}",
                //factoryResp.gfM_Id,
                //factoryResp.gfM_Code.Trim(),
                //factoryResp.gfM_Location.Trim(),
                //factoryResp.gfM_Address.Trim(),
                // //"F",
                //factoryResp.gfM_ContactPerson.Trim(),
                //factoryResp.gfM_ContactNumber1.Trim(),
                //factoryResp.gfM_ContactNumber2.Trim(),
                //factoryResp.gfM_eMail.Trim(),
                //factoryResp.gfM_MobileNo.Trim(),
                //factoryResp.gfM_FAX.Trim(),
                //factoryResp.gfM_TAN.Trim(),
                //factoryResp.gfM_VAT.Trim(),
                //factoryResp.gfM_GST.Trim(),
                //factoryResp.gfM_CIN.Trim(),
                //factoryResp.gfM_City.Trim(),
                //factoryResp.gfM_State.Trim(),
                //factoryResp.gfM_Region.Trim(),
                //factoryResp.gfM_Pincode.Trim()
                //);
            return true;
        }

        //DB - Delete Record
        //No SP for Factory

        //DB - Viewlist Record
        public List<GetFactoryResp> GetAllFactory()
        {
            var response = _dbContent.Database.SqlQuery<GetFactoryResp>
                (
                @"Exec [dbo].[spGet_GodownFactoryInfo] {0}", "F").ToList();
            return response;
        }

        //**************
        //Table - Godown
        //**************

        //DB - Insert Record
        public bool InsertGodown(GodownReq godownReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_GodownFactoryInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},
                {11},{12},{13},{14},{15},{16},{17}",
                godownReq.gfM_Code.Trim(),
                godownReq.gfM_Location.Trim(),
                godownReq.gfM_Address.Trim(),
            "G",
            godownReq.gfM_ContactPerson.Trim(),
            godownReq.gfM_ContactNumber1.Trim(),
            godownReq.gfM_ContactNumber2.Trim(),
            godownReq.gfM_eMail.Trim(),
            godownReq.gfM_MobileNo.Trim(),
            godownReq.gfM_FAX.Trim(),
            godownReq.gfM_TAN.Trim(),
            godownReq.gfM_VAT.Trim(),
            godownReq.gfM_GST.Trim(),
            godownReq.gfM_CIN.Trim(),
            godownReq.gfM_City.Trim(),
            godownReq.gfM_State.Trim(),
            godownReq.gfM_Region.Trim(),
            godownReq.gfM_Pincode.Trim());
            return true;
        }

        //DB - Update Record
        public bool UpdateGodown(GodownReq godownResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpUpdate_GodownFactoryInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},
                {10},{11},{12},{13},{14},{15},{16},{17}",
                godownResp.gfM_Id,
                godownResp.gfM_Code.Trim(),
                godownResp.gfM_Location.Trim(),
                godownResp.gfM_Address.Trim(),
                //"G",
                godownResp.gfM_ContactPerson.Trim(),
                godownResp.gfM_ContactNumber1.Trim(),
                godownResp.gfM_ContactNumber2.Trim(),
                godownResp.gfM_eMail.Trim(),
                godownResp.gfM_MobileNo.Trim(),
                godownResp.gfM_FAX.Trim(),
                godownResp.gfM_TAN.Trim(),
                godownResp.gfM_VAT.Trim(),
                godownResp.gfM_GST.Trim(),
                godownResp.gfM_CIN.Trim(),
                godownResp.gfM_City.Trim(),
                godownResp.gfM_State.Trim(),
                godownResp.gfM_Region.Trim(),
                godownResp.gfM_Pincode.Trim());
            return true;
        }

        //DB - Delete Record
        //No SP for Factory

        //DB - Viewlist Record
        public List<GetGodownResp> GetAllGodown()
        {
            var response = _dbContent.Database.SqlQuery<GetGodownResp>
                (
                @"Exec [dbo].[spGet_GodownFactoryInfo] {0}", "G").ToList();
            return response;
        }

        //Table - Certificate
        //DB - Insert Record
        public bool InsertCertificate(CertificateReq certificateReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_CertificateInfo] 
                {0},{1},{2},{3},{4}",
                certificateReq.crtD_itgMId,
                certificateReq.crtD_No.Trim(),
                certificateReq.crtD_Description.Trim(),
                certificateReq.crtD_CCENo.Trim(),
                certificateReq.crtD_DGMSNo.Trim()
                );
            return true;
        }
        //DB - Update Record
        public bool UpdateCertificate(CertificateResp certificateResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpUpdate_CertificateInfo] 
                {0},{1},{2},{3},{4}",
                "crtD_Id = " + certificateResp.crtD_Id,
                certificateResp.crtD_itgMId,
                certificateResp.crtD_No.Trim(),
                certificateResp.crtD_Description.Trim(),
                certificateResp.crtD_CCENo.Trim(),
                certificateResp.crtD_DGMSNo.Trim());
            return true;
        }

        

        public bool InsertBankMaster(ClientBankMasterResp bankMasterReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_ClientBankMasterInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8}",
                bankMasterReq.clM_Id,
                bankMasterReq.bnkM_Id,
                //12,
                bankMasterReq.bnkM_Name,
                bankMasterReq.bnkM_Branch,
                bankMasterReq.bnkM_IFSC,
                bankMasterReq.bnkM_AcNo,
                bankMasterReq.bnkM_AcName,
                bankMasterReq.bnkM_MICR,
                bankMasterReq.bnkM_Flag
               );
            return true;
        }

        public bool InsertContactMaster(LocationContactsResp locationContactReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_VendorLocationContactsInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7}",               
                locationContactReq.vcntM_ContactPerson,
                locationContactReq.vcntM_Mobile,
                locationContactReq.vcntM_Resi,
                locationContactReq.vcntM_eMail,
                locationContactReq.vcntM_Phone1,
                locationContactReq.vcntM_Phone2,
                locationContactReq.vcntM_FAX,
                locationContactReq.vcntM_vLcMId
                //locationContactReq.vcntM_Flag
               );
            return true;
        }

        //DB - Viewlist Record
        public List<ClientBankMasterReq> GodownBankMaster(int? p1, string p2)
        {
            var response = _dbContent.Database.SqlQuery<ClientBankMasterReq>
                (
                @"Exec [dbo].[spGet_ClientBankInfo] {0}, {1}", p1, p2
                ).ToList();
            return response;
        }

        //DB - Viewlist Record
        public List<ClientBankMasterReq> FactoryBankMaster(int? p1, string p2)
        {
            var response = _dbContent.Database.SqlQuery<ClientBankMasterReq>
                (
                @"Exec [dbo].[spGet_ClientBankInfo] {0}, {1}", p1, p2).ToList();
            return response;
        }

        //DB - Viewlist Record
        public List<LocationContactsResp> LocationContactMaster(int? p1, string p2)
        {
            var response = _dbContent.Database.SqlQuery<LocationContactsResp>
                (
                @"Exec [dbo].[spGet_VendorLocationContactInfo] {0}, {1}", p1, p2
                ).ToList();
            return response;
        }

        //Table - Designation
        //DB - Insert Record
        public bool InsertDesignation(DesignationReq designationReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_GeneralItemInfo] 
                {0},{1},{2}",
                designationReq.giM_Name,
                designationReq.giM_Type,
                designationReq.giM_itgMId
                );
            return true;
        }
        //DB - Insert Record
        public bool UpdateDesignation(DesignationResp designationResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpUpdate_GeneralItemInfo] 
                {0}",
                designationResp.giM_Name
                );
            return true;
        }

        public List<GetDesignationResp>getalldesignation()
        {
            var response = _dbContent.Database.SqlQuery<GetDesignationResp>
                (
                @"Exec [dbo].[SpGet_DesignationInfo]").ToList();
            return response;
        }
    }
}