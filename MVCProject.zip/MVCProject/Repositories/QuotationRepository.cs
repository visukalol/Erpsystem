﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;

namespace MVCProject.Repositories
{
    public class QuotationRepository : IQuotationRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;

        //Initiliaze DB connection 
        public QuotationRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //DB - Insert Record
        public bool InsertQuotationHdr(QTHeaderReq quotationHdrReq)
        {
            //DateTime str = Convert.ToDateTime(quotationHdrReq.enqM_ClosingDate.ToString());
            ////DateTime dt;
            ////var date1 = DateTime.TryParse(str, out dt);

            //DateTime str1 = Convert.ToDateTime(quotationHdrReq.enqM_ClosingDate.ToString());
            ////DateTime dt1;
            ////var date2 = DateTime.TryParse(str1, out dt1);

            //DateTime str2 = Convert.ToDateTime(quotationHdrReq.enqM_TenderDate.ToString());
            ////DateTime dt2;
            ////var date3 = DateTime.TryParse(str2, out dt2);

            var response = _dbContent.Database.SqlQuery<object>
                (@"Exec [dbo].[SpInsert_QuotationInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},
                {13},{14},{15},{16},{17},{18}",
                quotationHdrReq.qtM_No,
                quotationHdrReq.qtM_enqMId,
                quotationHdrReq.qtM_RevNo,
                quotationHdrReq.qtM_Date,
                quotationHdrReq.qtM_Amount,
                quotationHdrReq.qtM_stfMId,
                quotationHdrReq.status,
                quotationHdrReq.qtM_Type,
                quotationHdrReq.qtM_CurrencyName,
                quotationHdrReq.qtM_StandardDeviation,
                quotationHdrReq.qtM_yrMId,
                quotationHdrReq.ccD_clMId1,
                quotationHdrReq.ccD_lcMId1,
                quotationHdrReq.ccD_cntMId1,
                quotationHdrReq.ccD_dsgMId1,
                quotationHdrReq.ccD_clMId2,
                quotationHdrReq.ccD_lcMId2,
                quotationHdrReq.ccD_cntMId2,
                quotationHdrReq.ccD_dsgMId2
                );
            return true;
        }

        //DB - Update Record
        public bool UpdateQuotationHdr(QTHeaderResp quotationHdrResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_QuotationInfo] {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18}", "qtM_Id = " + quotationHdrResp.qtM_Id,
                quotationHdrResp.qtM_No,
                quotationHdrResp.qtM_enqMId,
                quotationHdrResp.qtM_RevNo,
                quotationHdrResp.qtM_Date,
                quotationHdrResp.qtM_Amount,
                quotationHdrResp.qtM_stfMId,
                quotationHdrResp.status,
                quotationHdrResp.qtM_Type,
                quotationHdrResp.qtM_CurrencyName,
                quotationHdrResp.qtM_StandardDeviation,
                quotationHdrResp.qtM_yrMId,
                quotationHdrResp.ccD_clMId1,
                quotationHdrResp.ccD_lcMId1,
                quotationHdrResp.ccD_cntMId1,
                quotationHdrResp.ccD_dsgMId1,
                quotationHdrResp.ccD_clMId2,
                quotationHdrResp.ccD_lcMId2,
                quotationHdrResp.ccD_cntMId2,
                quotationHdrResp.ccD_dsgMId2);
            return true;
        }

        //DB - Delete Record
        public bool DeleteQuotationHdr(QTHeaderResp quotationHdrResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_QuotationInfo] {0}", " qtM_Id = " + quotationHdrResp.qtM_Id);
            return true;
        }

        ////get enquiry
        public List<ListEnquiryResp> ListEnquiry()
        {
            var response = _dbContent.Database.SqlQuery<ListEnquiryResp>
                (@"Exec [dbo].[spGet_EnquiryInfo]").ToList();
            return response;
        }

        //DB - Viewlist Record
        //public List<GetQuotationResp> GetAllQuotation()
        //{
        //    var response = _dbContent.Database.SqlQuery<GetQuotationResp>
        //        (@"Exec [dbo].[spGet_QuotationInfo]").ToList();
        //    return response;
        //}



        //DB - Insert Record


        public bool InsertQTDetailReq(QTDetailReq QTDetailReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_QuotationDetailInfo] {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}",
                QTDetailReq.qtD_qtMId,
                QTDetailReq.qtD_itMId,
                QTDetailReq.qtgC_ItgMId,
                QTDetailReq.qtgC_crtDId,
                QTDetailReq.qtD_DetailDescription,
                QTDetailReq.qtD_ItemDescriptionEnquiry,
                QTDetailReq.qtgC_CertificateDescription,
                QTDetailReq.qtD_Quantity,
                QTDetailReq.qtD_Rate,
                QTDetailReq.qtD_Amount,
                QTDetailReq.qtD_ItemRank
                );

            return true;
        }

        //DB - Update Record
        public bool UpdateQTDetailResp(QTDetailResp QTDetailResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_QuotationDetailInfo] {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}", "qtD_Id = " + QTDetailResp.qtD_Id,
                QTDetailResp.qtD_Id,
                QTDetailResp.qtD_qtMId,
                QTDetailResp.qtD_itMId,
                QTDetailResp.qtgC_ItgMId,
                QTDetailResp.qtgC_crtDId,
                QTDetailResp.qtD_DetailDescription,
                QTDetailResp.qtD_ItemDescriptionEnquiry,
                QTDetailResp.qtgC_CertificateDescription,
                QTDetailResp.qtD_Quantity,
                QTDetailResp.qtD_Rate,
                QTDetailResp.qtD_Amount,
                QTDetailResp.qtD_ItemRank
                );
            return true;
        }

        //DB - Delete Record
        public bool DeleteQTDetailResp(QTDetailResp QTDetailResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_QuotationDetailInfo] {0}", " qtD_Id = " + QTDetailResp.qtD_Id);
            return true;
        }
        //DB - Insert Record


        public bool InsertQTActivityReq(QTActivityReq QTActivityReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_QuotationActivityInfo] {0},{1},{2},{3},{4},{5},{6}",
                QTActivityReq.qAct_qtMId,
                QTActivityReq.enquiryId,
                QTActivityReq.qAct_StfMId,
                QTActivityReq.qAct_StaffMIdAssign,
                QTActivityReq.qStatus,
                QTActivityReq.qAct_Remarks,
                QTActivityReq.qAct_yrMId
                );

            return true;
        }

        //DB - Update Record
        public bool UpdateQTActivityResp(QTActivityResp QTActivityResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_QuotationActivityInfo] {0},{1},{2},{3},{4},{5},{6}", "QAct_qtMId = " + QTActivityResp.qAct_qtMId,
                QTActivityResp.qAct_qtMId,
                QTActivityResp.enquiryId,
                QTActivityResp.qAct_StfMId,
                QTActivityResp.qAct_StaffMIdAssign,
                QTActivityResp.qStatus,
                QTActivityResp.qAct_Remarks,
                QTActivityResp.qAct_yrMId
                );
            return true;
        }

        //DB - Delete Record
        public bool DeleteQTActivityResp(QTActivityResp QTActivityResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_QuotationActivityInfo] {0}", "QAct_qtMId = " + QTActivityResp.qAct_qtMId);
            return true;
        }
        //DB - Insert Record


        public bool InsertQTGroupCertificateReq(QTGroupCertificateReq QTGroupCertificateReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_QuotationGroupCertificateInfo] {0},{1},{2},{3}",
                QTGroupCertificateReq.qtgC_qtGId,
                QTGroupCertificateReq.qtgC_ItgMId,
                QTGroupCertificateReq.qtgC_crtDId,
                QTGroupCertificateReq.qtgC_Amount
                    );

            return true;
        }

        //DB - Update Record
        public bool UpdateQTGroupCertificateResp(QTGroupCertificateResp QTGroupCertificateResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_QuotationGroupCertificateInfo] {0},{1},{2},{3}", "qtgC_qtGId = " + QTGroupCertificateResp.qtgC_qtGId,
                QTGroupCertificateResp.qtgC_qtGId,
                QTGroupCertificateResp.qtgC_ItgMId,
                QTGroupCertificateResp.qtgC_crtDId,
                QTGroupCertificateResp.qtgC_Amount
                );
            return true;
        }

        //DB - Delete Record
        public bool DeleteQTGroupCertificateResp(QTGroupCertificateResp QTGroupCertificateResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_QuotationGroupCertificateInfo] {0}", "qtgC_qtGId = " + QTGroupCertificateResp.qtgC_qtGId);
            return true;
        }
        //DB - Insert Record


        public bool InsertQTGroupDetailReq(QTGroupDetailReq QTGroupDetailReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_QuotationGroupDetailInfo] {0},{1},{2},{3},{4},{5},{6},{7}",
                QTGroupDetailReq.qtgD_qtgCId,
                QTGroupDetailReq.qtgD_qtgId,
                QTGroupDetailReq.qtgD_itMId,
                QTGroupDetailReq.qtgD_DetailDescription,
                QTGroupDetailReq.qtgD_DetailParticulars,
                QTGroupDetailReq.qtgD_Quantity,
                QTGroupDetailReq.qtgD_Rate,
                QTGroupDetailReq.qtgD_Amount
                    );

            return true;
        }

        //DB - Update Record
        public bool UpdateQTGroupDetailResp(QTGroupDetailResp QTGroupDetailResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_QuotationGroupDetailInfo] {0},{1},{2},{3},{4},{5},{6},{7}", "qtgD_qtgCId = " + QTGroupDetailResp.qtgD_qtgCId,
                QTGroupDetailResp.qtgD_qtgCId,
                QTGroupDetailResp.qtgD_qtgId,
                QTGroupDetailResp.qtgD_itMId,
                QTGroupDetailResp.qtgD_DetailDescription,
                QTGroupDetailResp.qtgD_DetailParticulars,
                QTGroupDetailResp.qtgD_Quantity,
                QTGroupDetailResp.qtgD_Rate,
                QTGroupDetailResp.qtgD_Amount
                    );
            return true;
        }

        //DB - Delete Record
        public bool DeleteQTGroupDetailResp(QTGroupDetailResp QTGroupDetailResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_QuotationGroupDetailInfo] {0}", "qtgD_qtgCId = " + QTGroupDetailResp.qtgD_qtgCId);
            return true;
        }
        //DB - Insert Record


        public bool InsertQTGroupItemParameterReq(QTGroupItemParameterReq QTGroupItemParameterReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_QuotationGroupItemParameterInfo] {0},{1},{2},{3}",
                QTGroupItemParameterReq.qtgP_qtgDId,
                QTGroupItemParameterReq.qtgP_Description,
                QTGroupItemParameterReq.qtgP_qtGId,
                QTGroupItemParameterReq.qtgP_itDId
                    );

            return true;
        }

        //DB - Update Record
        public bool UpdateQTGroupItemParameterResp(QTGroupItemParameterResp QTGroupItemParameterResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_QuotationGroupItemParameterInfo] {0},{1},{2},{3}", "qtgP_qtgDId = " + QTGroupItemParameterResp.qtgP_qtgDId,
                QTGroupItemParameterResp.qtgP_qtgDId,
                QTGroupItemParameterResp.qtgP_Description,
                QTGroupItemParameterResp.qtgP_qtGId,
                QTGroupItemParameterResp.qtgP_itDId
                    );
            return true;
        }

        //DB - Delete Record
        public bool DeleteQTGroupItemParameterResp(QTGroupItemParameterResp QTGroupItemParameterResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_QuotationGroupItemParameterInfo] {0}", "qtgP_qtgDId = " + QTGroupItemParameterResp.qtgP_qtgDId);
            return true;
        }
        //DB - Insert Record


        public bool InsertQTGroupParameterDetailReq(QTGroupParameterDetailReq QTGroupParameterDetailReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_QuotationGroupParameterDetailInfo] {0},{1},{2},{3},{4},{5}",
                QTGroupParameterDetailReq.qtgPd_qtgPId,
                QTGroupParameterDetailReq.qtgPd_qtgDId,
                QTGroupParameterDetailReq.qtgPd_Description,
                QTGroupParameterDetailReq.qtgPd_Make,
                QTGroupParameterDetailReq.qtgPd_No,
                QTGroupParameterDetailReq.qtgPd_qtMId
                    );

            return true;
        }

        //DB - Update Record
        public bool UpdateQTGroupParameterDetailResp(QTGroupParameterDetailResp QTGroupParameterDetailResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_QuotationGroupParameterDetailInfo] {0},{1},{2},{3},{4},{5}", "qtgPd_qtgPId = " + QTGroupParameterDetailResp.qtgPd_qtgPId,
                QTGroupParameterDetailResp.qtgPd_qtgPId,
                QTGroupParameterDetailResp.qtgPd_qtgDId,
                QTGroupParameterDetailResp.qtgPd_Description,
                QTGroupParameterDetailResp.qtgPd_Make,
                QTGroupParameterDetailResp.qtgPd_No,
                QTGroupParameterDetailResp.qtgPd_qtMId
                    );

            return true;
        }

        //DB - Delete Record
        public bool DeleteQTGroupParameterDetailResp(QTGroupParameterDetailResp QTGroupParameterDetailResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_QuotationGroupParameterDetailInfo] {0}", "qtgPd_qtgPId = " + QTGroupParameterDetailResp.qtgPd_qtgPId);
            return true;
        }
        //DB - Insert Record


        public bool InsertQTParameterReq(QTParameterReq QTParameterReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_QuotationParameterInfo] {0},{1},{2},{3},{4},{5},{6}",
                QTParameterReq.qtP_QtDId,
                QTParameterReq.qtP_QtMId,
                QTParameterReq.qtP_DetailName,
                QTParameterReq.qtP_Description,
                QTParameterReq.qtP_qtPId,
                QTParameterReq.qtP_Rank,
                QTParameterReq.qtP_ParentQtPId
                    );

            return true;
        }

        //DB - Update Record
        public bool UpdateQTParameterResp(QTParameterResp QTParameterResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_QuotationParameterInfo] {0},{1},{2},{3},{4},{5},{6}", "qtP_QtDId = " + QTParameterResp.qtP_QtDId,
                QTParameterResp.qtP_QtDId,
                QTParameterResp.qtP_QtMId,
                QTParameterResp.qtP_DetailName,
                QTParameterResp.qtP_Description,
                QTParameterResp.qtP_qtPId,
                QTParameterResp.qtP_Rank,
                QTParameterResp.qtP_ParentQtPId
                    );

            return true;
        }

        //DB - Delete Record
        public bool DeleteQTParameterResp(QTParameterResp QTParameterResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_QuotationParameterInfo] {0}", "qtP_QtDId = " + QTParameterResp.qtP_QtDId);
            return true;
        }
        //DB - Insert Record


        public bool InsertQTTnCReq(QTTnCReq QTTnCReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_QuotationTnCInfo] {0},{1},{2},{3},{4}",
                QTTnCReq.tncQ_QtMId,
                QTTnCReq.tncQ_TncMId,
                QTTnCReq.tncQ_TncDId,
                QTTnCReq.tnCQ_Type,
                QTTnCReq.tnCQ_Description
                    );

            return true;
        }

        //DB - Update Record
        public bool UpdateQTTnCResp(QTTnCResp QTTnCResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_QuotationTnCInfo] {0},{1},{2},{3},{4}", "tncQ_QtMId = " + QTTnCResp.tncQ_QtMId,
                QTTnCResp.tncQ_QtMId,
                QTTnCResp.tncQ_TncMId,
                QTTnCResp.tncQ_TncDId,
                QTTnCResp.tnCQ_Type,
                QTTnCResp.tnCQ_Description
                );
            return true;
        }

        //DB - Delete Record
        public bool DeleteQTTnCResp(QTTnCResp QTTnCResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_QuotationTnCInfo] {0}", "tncQ_QtMId = " + QTTnCResp.tncQ_QtMId);
            return true;
        }
    }
}