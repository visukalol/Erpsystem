﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace MVCProject.Repositories
{
    public class EnquiryRepository : IEnquiryRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;

        //Initiliaze DB connection 
        public EnquiryRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //DB - Insert Record
        public bool InsertEnquiry(EnquiryReq enquiryReq)
        {
            //DateTime str = Convert.ToDateTime(enquiryReq.enqM_ClosingDate.ToString());
            ////DateTime dt;
            ////var date1 = DateTime.TryParse(str, out dt);

            //DateTime str1 = Convert.ToDateTime(enquiryReq.enqM_ClosingDate.ToString());
            ////DateTime dt1;
            ////var date2 = DateTime.TryParse(str1, out dt1);

            //DateTime str2 = Convert.ToDateTime(enquiryReq.enqM_TenderDate.ToString());
            ////DateTime dt2;
            ////var date3 = DateTime.TryParse(str2, out dt2);

            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_EnquiryInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},
                {11},{12},{13},{14},{15}",
                enquiryReq.enqM_clMId,
                enquiryReq.enqM_RegDate,
                //str,
                enquiryReq.enqM_TenderNo,
                enquiryReq.enqM_TenderDate,
                //str2,
                enquiryReq.enqM_ClosingDate,
                //str1,
                enquiryReq.enqM_lcMId,
                enquiryReq.enqM_cntMId,
                enquiryReq.enqM_dsgMId,
                enquiryReq.enqM_stfMId,
                enquiryReq.enqM_Detail,
                enquiryReq.enqM_MOR,
                enquiryReq.enqM_stsMId,
                enquiryReq.enqM_Value,
                enquiryReq.enqM_ProjectName,
                enquiryReq.enqM_YrMId,
                enquiryReq.enqM_RegNo
                );
            return true;
        }


        //DB - Insert Record in Enquiry AssignTo
        public bool InsertEnquiryAssign(EnquiryAssignInfoReq enquiryassigninfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_EnquiryAssignInfo]
                {0},{1},{2},{3},{4}",
                enquiryassigninfoReq.enqA_RegNo,
                enquiryassigninfoReq.enqA_DepartmentName,
                enquiryassigninfoReq.enqA_StaffName,
                enquiryassigninfoReq.enqA_Address,
                enquiryassigninfoReq.enqA_Instructions
                );
            return true;
        }


        //DB - Insert Record in Enquiry DivertTo
        public bool InsertEnquiryDivert(EnquiryDivertInfoReq EnquirydivertinfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_EnquiryDivertInfo]
                {0},{1},{2}",
                EnquirydivertinfoReq.enqD_RegNo,
                EnquirydivertinfoReq.enqD_Distributor,
                EnquirydivertinfoReq.enqD_Comments
                );
            return true;
        }


        //DB - Insert Record in Enquiry RegretTo
        public bool InsertEnquiryRegret(EnquiryRegretInfoReq EnquiryRegretinfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_EnquiryRegretInfo]
                {0},{1},{2}",
                EnquiryRegretinfoReq.enqR_RegNo,
                EnquiryRegretinfoReq.enqR_Remarks,
                EnquiryRegretinfoReq.enqR_Reason
                );
            return true;
        }

        //DB - Update Record
        public bool UpdateEnquiry(EnquiryReq enquiryResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_EnquiryInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},
                {11},{12},{13},{14}",        
                enquiryResp.enqM_Id,
                enquiryResp.enqM_clMId,
                enquiryResp.enqM_RegNo,
                enquiryResp.enqM_RegDate,
                enquiryResp.enqM_TenderNo,
                enquiryResp.enqM_TenderDate,
                enquiryResp.enqM_ClosingDate,
                enquiryResp.enqM_lcMId,
                enquiryResp.enqM_cntMId,
                enquiryResp.enqM_dsgMId,
                enquiryResp.enqM_stfMId,
                enquiryResp.enqM_Detail,
                enquiryResp.enqM_MOR,
                //enquiryResp.enqM_stsMId,
                enquiryResp.enqM_Value,
                enquiryResp.enqM_ProjectName
                //enquiryResp.enqM_RegNo
                );
            return true;
        }

        //DB - Delete Record
        public bool DeleteEnquiry(EnquiryReq enquiryResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpDelete_EnquiryInfo] {0}",
                enquiryResp.enqM_Id
                );
            return true;
        }

        public List<GetEnquiryResp> GetEnquiryOnId(int? p1)
        {
            var response = _dbContent.Database.SqlQuery<GetEnquiryResp>
                (
                @"Exec [dbo].[spGet_EnquiryInfoOnID] 
                {0}",
                @p1).ToList();
            return response;
        }

        //DB - Viewlist Record
        //public List<GetEnquiryResp> GetAllEnquiry(int? p1, bool p2=false, DateTime? p3, DateTime? p4)
        public List<GetEnquiryResp> GetAllEnquiry(int? p1, DateTime? p3, DateTime? p4)

        {
            //p3 = Convert.ToDateTime(DateTime.Now);
            //// Create the command and set its properties.
            //SqlCommand command = new SqlCommand();            

            //command.CommandType = CommandType.StoredProcedure;

            //// Add the input parameters and set the properties.
            //SqlParameter parameter1 = new SqlParameter();
            //parameter1.ParameterName = "@StaffId";
            //parameter1.SqlDbType = SqlDbType.Int;
            //parameter1.Direction = ParameterDirection.Input;
            //parameter1.Value = p1;

            //SqlParameter parameter2 = new SqlParameter();
            //parameter2.ParameterName = "@AssignType";
            //parameter2.SqlDbType = SqlDbType.Bit;
            //parameter2.Direction = ParameterDirection.Input;
            //parameter2.Value = p2;

            //SqlParameter parameter3 = new SqlParameter();
            //parameter3.ParameterName = "@EnquiryDt1";
            //parameter3.SqlDbType = SqlDbType.Date;
            //parameter3.Direction = ParameterDirection.Input;
            //parameter3.Value = p3;

            //SqlParameter parameter4 = new SqlParameter();
            //parameter4.ParameterName = "@EnquiryDt2";
            //parameter4.SqlDbType = SqlDbType.Date;
            //parameter4.Direction = ParameterDirection.Input;
            //parameter4.Value = p4;

            //var p1 = Convert.ToInt32("20");
            //var p2 = true;
            //var p3 = Convert.ToDateTime("1900-01-01");
            //var p4 = Convert.ToDateTime("2021-01-21");            

            //var response = _dbContent.Database.SqlQuery<GetEnquiryResp>
            //    (
            //    @"Exec [dbo].[spGet_EnquiryInfo] 
            //    @StaffId, 
            //    @AssignType,
            //    @EnquiryDt1, 
            //    @EnquiryDt2",
            //    new SqlParameter("@StaffId", p1),
            //    new SqlParameter("@AssignType", p2),
            //    new SqlParameter("@EnquiryDt1", p3),
            //    new SqlParameter("@EnquiryDt2", p4)
            //    ).ToList();        

            //var assignType = Convert.ToDouble(p2);            

            var response = _dbContent.Database.SqlQuery<GetEnquiryResp>
                (
                @"Exec [dbo].[spGet_EnquiryInfo] 
                {0}, {1}, {2}",
                '0', @p3, @p4 ).ToList();
            return response;
        }

        //DB - Viewlist Record
        //Enquiry Assign Data
        public List<EnquiryAssignInfoResp> GetAllAssignEnquiry()
        {
            var response = _dbContent.Database.SqlQuery<EnquiryAssignInfoResp>
                (@"Exec [dbo].[spGet_EnquiryAssignInfo]").ToList();
            return response;
        }


        //DB - Viewlist Record
        //Enquiry Divert Data
        public List<EnquiryDivertInfoResp> GetAllDivertEnquiry()
        {
            var response = _dbContent.Database.SqlQuery<EnquiryDivertInfoResp>
                (@"Exec [dbo].[spGet_EnquiryDivertInfo]").ToList();
            return response;
        }


        //DB - Viewlist Record
        //Enquiry Regret Data
        public List<EnquiryRegretInfoResp> GetAllRegretEnquiry()
        {
            var response = _dbContent.Database.SqlQuery<EnquiryRegretInfoResp>
                (@"Exec [dbo].[spGet_EnquiryRegretInfo]").ToList();
            return response;
        }

        //-----------------------------------------------------------
        // 
        //-----------------------------------------------------------
        //DB - Insert Record
        public bool InsertEnquiryActivity(EnquiryActivityInfoReq EnquiryActivityInfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_EnquiryActivityInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8}",
                EnquiryActivityInfoReq.Act_enqMId,
                EnquiryActivityInfoReq.Act_StfMId,
                EnquiryActivityInfoReq.Act_StaffMIdAssign,
                EnquiryActivityInfoReq.Act_dstMIdDivert,
                EnquiryActivityInfoReq.Status,
                EnquiryActivityInfoReq.Act_Remarks,
                EnquiryActivityInfoReq.Act_RegretNos,
                EnquiryActivityInfoReq.Act_RegretRemark,
                EnquiryActivityInfoReq.Act_yrMId                
                );
            return true;
        }

        //DB - Update Record
        //No SP

        public List<EnquiryInfoOnStatusResp> EnquiryInfoOnStatus(string p1, int? p2, DateTime? d1, DateTime? d2)
        {
            var response = _dbContent.Database.SqlQuery<EnquiryInfoOnStatusResp>
                (
                @"Exec [dbo].[spGet_EnquiryInfoOnStatus] 
                {0}, {1}, {2}, {3}",
                @p1, @p2, @d1, @d2).ToList();
            return response;
        }


       
        
        //public bool InsertDesignation(DesignationsReq designationsReq)
        //{
        //    var response = _dbContent.Database.ExecuteSqlCommand
        //        (@"INSERT INTO tblDesignations (desM_Name) VALUES ('" +designationsReq.desM_Name.Trim()+ "')");
        //    return true;
        //}

        //public bool UpdateDesignation(DesignationsReq designationsResp)
        //{
        //    var response = _dbContent.Database.ExecuteSqlCommand
        //        (@"INSERT INTO tblDesignations (desM_Name) VALUES ('" + designationsResp.desM_Name.Trim() + "')");
        //    return true;
        //}
    }
}