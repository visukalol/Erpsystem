﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;

namespace MVCProject.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;

        //Initiliaze DB connection 
        public CategoryRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //DB - Insert Record
        public bool InsertCategory(CategoryReq categoryReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_CategoryInfo] {0},{1},{2}", 
                categoryReq.catM_Name.Trim(), 
                categoryReq.catM_Description.Trim(), 
                categoryReq.catM_Code.Trim());
                //var response1 = _dbContent.Database.ExecuteSqlCommand("insert into tblCategoryMaster(catM_Name,catM_Description,catM_Code) values('xyz','xyz','xyz')");
            return true;           
        }

        //DB - Update Record
        public bool UpdateCategory(CategoryReq categoryResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_CategoryInfo] {0},{1},{2},{3}",
                categoryResp.catM_Id,
                categoryResp.catM_Name.Trim(),
                categoryResp.catM_Description.Trim(),
                categoryResp.catM_Code.Trim());
            return true;
        }

        //DB - Delete Record
        public bool DeleteCategory(CategoryReq categoryResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand(@"Exec [dbo].[SpDelete_CategoryInfo] {0}",
                categoryResp.catM_Id);
            return true;
        }

        //DB - Viewlist Record
        public List<GetCategoryResp> GetAllCategory()
        {
            var response = _dbContent.Database.SqlQuery<GetCategoryResp>
                (@"Exec [dbo].[spGet_CategoryInfo]").ToList();
            return response;
        }

        public bool Insertprj(QTHeaderReq QtheaderReq)
        {

            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_PrcodeInfo] {0},{1}",
                QtheaderReq.prcode.Trim(),
                QtheaderReq.qty.Trim()
               );
            return true;
        }
        
        public List<QTHeaderReq> GetAllProductcodelist()
        {
            var response = _dbContent.Database.SqlQuery<QTHeaderReq>
                (@"Exec [dbo].[spGet_PrcodeInfo]").ToList();
            return response;
        }

        //List Enquiry
        public List<ListEnquiryResp> ListEnquiry()
        {
            var response = _dbContent.Database.SqlQuery<ListEnquiryResp>
            (@"Exec [dbo].[spGet_EnquiryInfoId] {0}", 0).ToList();
            return response;
        }

        public List<ListQuotationResp> ListEnquirylist(string enqM_RegNo)
        {
            var response = _dbContent.Database.SqlQuery<ListQuotationResp>
            (@"Exec [dbo].[spGet_QuotationList] {0}", enqM_RegNo).ToList();
            return response;
        }

        public List<ListCompanyCodeResp> ListCompanyCode()
        {
            var response = _dbContent.Database.SqlQuery<ListCompanyCodeResp>
                (@"Exec [dbo].[spGet_ListCompanyCode]").ToList();
            return response;
        }

        public List<ListContactResp> ListContact()
        {
            var response = _dbContent.Database.SqlQuery<ListContactResp>
                (@"Exec [dbo].[spGet_ListContacts]").ToList();
            return response;
        }

        public List<ListQuotatiionResp> Listquotation()
        {
            var response = _dbContent.Database.SqlQuery<ListQuotatiionResp>
                (@"Exec [dbo].[spGet_QuotationMovement]").ToList();
            return response;
        }

        public List<ListDesignationResp> Listdesignation()
        {
            var response = _dbContent.Database.SqlQuery<ListDesignationResp>
                (@"Exec [dbo].[SpGet_DesignationInfo]").ToList();
            return response;
        }

    }
}