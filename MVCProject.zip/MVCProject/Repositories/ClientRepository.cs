﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;

namespace MVCProject.Repositories
{
    public class ClientRepository : IClientRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;
        //Initiliaze DB connection 
        public ClientRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //Insert Method using calling SP from Database
        //SP Name : [dbo].[SpInsert_ClientInfo]    
        public bool InsertClient(ClientReq clientReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_ClientInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8}",
                clientReq.clM_CompanyName.Trim(),
                clientReq.clM_ContactPerson.Trim(),
                clientReq.clM_Email.Trim(),
                clientReq.clM_Code.Trim(),
                clientReq.clM_PAN.Trim(),
                clientReq.clM_CreditLimit.Trim(),
                clientReq.clM_Active.Trim(),
                clientReq.clM_CIN,
                clientReq.clM_TAN);
            return true;
        }

        //DB - Update Record
        public bool UpdateClient(ClientReq clientResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_ClientInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9}",
                clientResp.clM_CompanyName.Trim(),
                clientResp.clM_ContactPerson.Trim(),
                clientResp.clM_PAN.Trim(),                  
                clientResp.clM_Email.Trim(),
                clientResp.clM_Code.Trim(),
                clientResp.clM_CreditLimit.Trim(),
                clientResp.clM_Id,
                clientResp.clM_Active,
                clientResp.clM_TAN,
                clientResp.clM_CIN); 
            return true;
        }

        //DB - Delete Record
        public bool DeleteClient(ClientReq clientResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpDelete_ClientInfo] {0}",
                clientResp.clM_Id);
            return true;
        }

        //List method using calling SP from database
        public List<GetClientResp> GetAllClient()
        {
            var response = _dbContent.Database.SqlQuery<GetClientResp>
                (@"Exec [dbo].[spGet_ClientInfo]").ToList();
            return response;
        }

        //List for Client's Contact based on Location
        public List<GetClientContactsResp> GetClientContacts(int? p1)
        {
            if (p1 != null)
            {
                var response = _dbContent.Database.SqlQuery<GetClientContactsResp>
                               (
                               @"Exec [dbo].[spGet_ContactListOnClientId] {0}", p1
                               ).ToList();
                return response;
            }
            else
            {
                var response = _dbContent.Database.SqlQuery<GetClientContactsResp>
                                (
                                @"Exec [dbo].[spGet_ContactListOnClientId] {0}", 0
                                ).ToList();
                return response;
            }

        }

        //DB - Viewlist Record
        public List<GetClientLocationResp> GetAllClientLocations(int? p1, string flag)
        {
            var response = _dbContent.Database.SqlQuery<GetClientLocationResp>
                (
                @"Exec [dbo].[spGet_ClientLocationInfo] {0}", p1, flag
                ).ToList();
            return response;
        }

        //DB - Viewlist Record
        public List<ClientBankMasterReq> ClientBankMaster(int? p1, string p2)
        {
            var response = _dbContent.Database.SqlQuery<ClientBankMasterReq>
                (
                @"Exec [dbo].[spGet_ClientBankInfo] {0}, {1}", p1, p2
                ).ToList();
            return response;
        }
    }
}