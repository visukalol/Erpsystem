﻿using MVCProject.IRepositories;
using MVCProject.Models;
using MVCProject.Models.DBModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Repositories
{
    public class LoginRepository : ILoginRepository
    {
        private ChecnTrack_MainDB _dbContent;

        public LoginRepository(ChecnTrack_MainDB dbContent)
        {
            _dbContent = dbContent;
        }

        public LoginResp CheckLogin(string userid,string password,int Id)
        {
            var response = _dbContent.Database.SqlQuery<LoginResp>(@"Exec [dbo].[spGet_StaffActiveInfoId] {0},{1},{2}",userid,password,Id).SingleOrDefault();
            return response;
        }

        public List<Login> forlogin()
        {
            var response = _dbContent.Database.SqlQuery<Login>
                (@"Exec [dbo].[spGet_LoginInfo]").ToList();
            return response;
        }


    }
}