﻿using MVCProject.IRepositories;
using MVCProject.Models.DBModel;
using MVCProject.Models.ResponseModel.Location;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Repositories
{
    public class LocationRepository 
    {
        private DBContent _dbContent;

        public LocationRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        public bool Insertlocation(LocationResp locationReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_LocationInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}",
                locationReq.LcM_clMId,
                locationReq.LcM_Code.Trim(),
                locationReq.LcM_Address.Trim(),
                locationReq.LcM_City.Trim(),
                locationReq.LcM_Country.Trim(),
                locationReq.LcM_Zip.Trim(),
                locationReq.LcM_State.Trim(),
                locationReq.LcM_ECC.Trim(),
                locationReq.LcM_ER,
                locationReq.LcM_CST, 
                locationReq.LcM_VAT, 
                locationReq.LcM_GSTiN, 
                locationReq.LCM_Flag);
            return true;
        }
    }
}