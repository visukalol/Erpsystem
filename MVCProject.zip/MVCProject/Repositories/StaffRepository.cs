﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;

namespace MVCProject.Repositories
{
    public class StaffRepository : IStaffRepository
    {
        //Variable declaration of DB Connection
        private ChecnTrack_MainDB _checkntrack_maindb;
        //private DBContent _dbContent;

        //Initiliaze DB connection 
        public StaffRepository(ChecnTrack_MainDB checkntrack_maindb)
        {
            _checkntrack_maindb = checkntrack_maindb;
        }

        //DB - Insert Record
        public bool InsertStaff(StaffReq staffReq)

        {
            var response = _checkntrack_maindb.Database.ExecuteSqlCommand
                (@"INSERT INTO tblStaffMaster (stfM_Name, stfM_Gender, stfM_DOB, stfM_Address, stfM_ContactNumber1, stfM_ContactNumber2, stfM_Email, stfM_DepartmentName, stfM_Initials, stfM_IsActive, stfM_password, stfM_Location)
VALUES ('" + staffReq.stfM_Name.Trim()+ "',"+staffReq.stfM_Gender+", '02/12/2010','"+staffReq.stfM_Address+ "','"+staffReq.stfM_ContactNumber1+ "','"+staffReq.stfM_ContactNumber2+ "', '"+staffReq.stfM_Email+ "', '"+staffReq.stfM_DepartmentName+ "','"+staffReq.stfM_Initials+ "', "+staffReq.stfM_IsActive+", '"+staffReq.stfM_password+ "', '" + staffReq.stfM_Location + "') ");
               // staffReq.stfM_Name.Trim(), 
               // staffReq.stfM_Gender, 
               //"1/12/2012",
               // staffReq.stfM_Address,
               // staffReq.stfM_ContactNumber1,
               // staffReq.stfM_ContactNumber2,
               // staffReq.stfM_Email,

               // staffReq.stfM_DepartmentName,
               // staffReq.stfM_Initials,
               // staffReq.stfM_IsActive );
            return true;
        }

        //DB - Update Record
        public bool UpdateStaff(StaffReq staffResp)
        {            
            var response = _checkntrack_maindb.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_StaffInfo]
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}",
                staffResp.stfM_Id,
                staffResp.stfM_Name.Trim(),
                staffResp.stfM_Gender,
                "12-06-1958 00:00:00.000",
                staffResp.stfM_Address,
                staffResp.stfM_password,
                staffResp.stfM_ContactNumber1,
                staffResp.stfM_ContactNumber2,
                staffResp.stfM_Email,
                staffResp.stfM_userId,
                staffResp.stfM_DepartmentName,
                staffResp.stfM_Initials,
                staffResp.stfM_IsActive,
                staffResp.stfM_Location);
            return true;
        }

        //DB - Delete Record
        public bool DeleteStaff(StaffReq staffResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _checkntrack_maindb.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpDelete_StaffInfo] {0}", 
                staffResp.stfM_Id);
            return true;
        }

        //DB - Viewlist Record
        public List<GetStaffResp> GetAllStaff()
        {
            var response = _checkntrack_maindb.Database.SqlQuery<GetStaffResp>
                (@"Exec [dbo].[spGet_StaffInfo]").ToList();
            return response;
        }

        //public List<ListLocationResp> ListLocation()
        //{
        //    var response = _dbContent.Database.SqlQuery<ListLocationResp>
        //        (@"Exec [dbo].[spGet_LocationInfo]").ToList();
        //    return response;
        //}

        //DB - Viewlist Record
        //public List<GetRolesResp> GetAllRoles()
        //{
        //    var response = _checkntrack_maindb.Database.SqlQuery<GetRolesResp>
        //        (@"Exec [dbo].[spGet_RolesInfo]").ToList();
        //    return response;
        //}
    }
}