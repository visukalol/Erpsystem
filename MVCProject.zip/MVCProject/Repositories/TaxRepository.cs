﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;

namespace MVCProject.Repositories
{
    public class TaxRepository : ITaxRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;

        //Initiliaze DB connection 
        public TaxRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //DB - Insert Record
        public bool InsertTax(GetTaxEntryResp taxentryReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_TaxMasterInfo] 
                    {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}",
                    taxentryReq.txM_Code,
                    taxentryReq.txM_TaxName,
                    taxentryReq.txM_Group,
                    taxentryReq.txM_TaxDescription,
                    taxentryReq.txM_isPercentage,
                    taxentryReq.txM_Active,
                    taxentryReq.txM_Amount,
                    taxentryReq.txM_Parameters,
                    taxentryReq.txM_FormName,
                    taxentryReq.txM_TaxFormula,
                    taxentryReq.txM_isAgainst,
                    taxentryReq.txM_isUnder);
            return true;
        }

        //DB - Update Record
        public bool UpdateTax(GetTaxEntryResp taxentryResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_TaxMasterInfo] 
                    {0},{1},{2},{3},{4},{5},{6},{7},{8},{9}",/*,{10},{11},{12}",*/
                    taxentryResp.txM_Id,
                    taxentryResp.txM_Code,
                    taxentryResp.txM_TaxName,
                    taxentryResp.txM_Group,
                    taxentryResp.txM_TaxDescription,
                    taxentryResp.txM_isPercentage,
                    //taxentryResp.txM_Active,
                    //taxentryResp.txM_Amount,
                    //taxentryResp.txM_Parameters,
                    taxentryResp.txM_FormName,
                    taxentryResp.txM_TaxFormula,
                    taxentryResp.txM_isAgainst,
                    taxentryResp.txM_isUnder);
            return true;
        }

        //internal void UpdateTax(GetTaxEntryResp gettaxentryResp)
        //{
        //    throw new NotImplementedException();
        //}

        //internal void InsertTax(GetTaxEntryResp gettaxentryResp)
        //{
        //    throw new NotImplementedException();
        //}

        //DB - Delete Record
        public bool DeleteTax(GetTaxEntryResp taxentryResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpDelete_TaxMasterInfo] 
                {0}", 
                taxentryResp.txM_Id);
            return true;
        }

        //List - TaxMaster
        public List<GetTaxEntryResp> GetAllTax()
        {
            var response = _dbContent.Database.SqlQuery<GetTaxEntryResp>
                (@"Exec [dbo].[spGet_TaxInfo]").ToList();
            return response;
        }

        //List - Formname
        public List<FormnameResp> ListFormname()
        {
            var response = _dbContent.Database.SqlQuery<FormnameResp>
                (@"Exec [dbo].[SpGet_GeneralItemsInfo] {0},{1}","5","0").ToList();
            return response;
        }

        //List - Formname Originol
        public List<GetTaxDetailResp> Listtaxdetail()
        {
            var response = _dbContent.Database.SqlQuery<GetTaxDetailResp>
                (@"Exec  [dbo].[SpGet_TaxDetailInfo]").ToList();
            return response;
        }
    }
}