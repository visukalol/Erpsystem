﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;
using System.Data.SqlClient;

namespace MVCProject.Repositories
{
    public class WorkOrderRepository : IWorkOrderRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;        

        //Initiliaze DB connection 
        public WorkOrderRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //DB - Insert Record
        public bool InsertWorkOrder(WorkOrderInfoReq workOrderInfoReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_WorkOrderInfo] {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26}",
                workOrderInfoReq.woM_No,
                workOrderInfoReq.woM_Date,
                workOrderInfoReq.woM_PONo,
                workOrderInfoReq.woM_PODate,
                workOrderInfoReq.woM_RevNo,
                workOrderInfoReq.woM_QtnNo,
                workOrderInfoReq.woM_QtnDate,
                workOrderInfoReq.woM_Amount,
                workOrderInfoReq.woM_DeliveryDate,
                workOrderInfoReq.woM_ClMId,
                workOrderInfoReq.woM_LcMId,
                workOrderInfoReq.woM_ConsigneeId,
                workOrderInfoReq.woM_ConsigneelcMId,
                workOrderInfoReq.woM_CurrencyName,
                workOrderInfoReq.woM_woActId,
                workOrderInfoReq.woM_DespatchMode,
                workOrderInfoReq.woM_AgentName,
                workOrderInfoReq.woM_AgentPercentage,
                workOrderInfoReq.woM_stsMId,
                workOrderInfoReq.woM_Remarks,
                workOrderInfoReq.woM_stfMId,
                workOrderInfoReq.woM_AccountOf,
                workOrderInfoReq.woM_TransportName,
                workOrderInfoReq.woM_unitMId,
                workOrderInfoReq.woM_WeekNo,
                workOrderInfoReq.woM_yrMId,
                workOrderInfoReq.woM_qtMId);
            return true;
        }

        //DB - Update Record
        public bool UpdateWorkOrder(WorkOrderInfoResp workOrderInfoResp)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_WorkOrderInfo] 
                {0},{1},{2}",
                "@woM_Id = " + workOrderInfoResp.@woM_Id,
                workOrderInfoResp.woM_No,
                workOrderInfoResp.woM_Date,
                workOrderInfoResp.woM_PONo,
                workOrderInfoResp.woM_PODate,
                workOrderInfoResp.woM_RevNo,
                //workOrderInfoResp.woM_QtnNo,
                //workOrderInfoResp.woM_QtnDate,
                workOrderInfoResp.woM_Amount,
                workOrderInfoResp.woM_DeliveryDate,
                workOrderInfoResp.woM_ClMId,
                workOrderInfoResp.woM_LcMId,
                workOrderInfoResp.woM_ConsigneeId,
                workOrderInfoResp.woM_ConsigneelcMId,
                workOrderInfoResp.woM_CurrencyName,
                workOrderInfoResp.woM_woActId,
                workOrderInfoResp.woM_DespatchMode,
                workOrderInfoResp.woM_AgentName,
                workOrderInfoResp.woM_AgentPercentage,
                workOrderInfoResp.woM_stsMId,
                workOrderInfoResp.woM_Remarks,
                workOrderInfoResp.woM_stfMId,
                workOrderInfoResp.woM_AccountOf,
                workOrderInfoResp.woM_TransportName,
                workOrderInfoResp.woM_unitMId,
                workOrderInfoResp.woM_weekNo,
                workOrderInfoResp.woM_stfMId);
            return true;
        }

        //DB - Viewlist Record
        //No SP for deletion

        //DB - Viewlist Record
        public List<WorkOrderInfoResp> GetAllWorkOrder(int? p1, DateTime? d1, DateTime? d2, int? p2)
        {
            //var p1 = 1;
            //var p2 = Convert.ToDateTime("1900-01-01");
            //var p3 = Convert.ToDateTime("2021-01-21");
            //var p4 = 1;

            //var response = _dbContent.Database.SqlQuery<WorkOrderInfoResp>
            //    (@"Exec [dbo].[spGet_WorkOrderRegister] 
            //    {0},{1},{2},{3}",
            //    @p1, @p2, @p3, @p4).ToList();

            var response = _dbContent.Database.SqlQuery<WorkOrderInfoResp>
                (@"Exec [dbo].[spGet_WorkOrderRegister] 
                @StaffId,
                @WorkOrderDt1,
                @WorkOrderDt2,
                @UnitId",
                new SqlParameter("@StaffId", p1),
                new SqlParameter("@WorkOrderDt1", d1),
                new SqlParameter("@WorkOrderDt2", d2),
                new SqlParameter("@UnitId", p2)).ToList();
                //@p1, @p2, @p3, @p4).ToList();
            return response;
        }

        //DB - Viewlist Record
        public List<WorkOrderInfoResp> GetWorkOrderMaster(int? p1)
        {
            var response = _dbContent.Database.SqlQuery<WorkOrderInfoResp>
                (@"Exec [dbo].[spGet_WorkOrderMaster] 
                @woM_Id",
                new SqlParameter("@woM_Id", p1)).ToList();
            return response;
        }

        //-------------//

        //DB - Insert Record
        public bool InsertWorkOrderDetailInfo(WorkOrderDetailInfoReq workOrderDetailTaxInfoReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_WorkOrderDetailInfo] {0},{1},{2},{3},{4},{5},{6},{7}",
                workOrderDetailTaxInfoReq.woD_woMId,
                workOrderDetailTaxInfoReq.woD_itMId,
                workOrderDetailTaxInfoReq.woD_Quantity,
                workOrderDetailTaxInfoReq.woD_Rate,
                workOrderDetailTaxInfoReq.woD_Amount,
                workOrderDetailTaxInfoReq.woD_ItemDescriptionWorkOrder,
                workOrderDetailTaxInfoReq.woD_ItemRank
                );
            return true;
        }

        //DB - Update Record
        public bool UpdateWorkOrderDetailInfo(WorkOrderDetailInfoResp workOrderDetailInfoResp)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_WorkOrderInfo] {0},{1},{2},{3},{4},{5},{6}",
                "@woD_Id = " + workOrderDetailInfoResp.woD_Id,
                workOrderDetailInfoResp.woD_itMId,
                workOrderDetailInfoResp.woD_Quantity,
                workOrderDetailInfoResp.woD_Rate,
                workOrderDetailInfoResp.woD_Amount,
                workOrderDetailInfoResp.woD_ItemDescriptionWorkOrder,
                workOrderDetailInfoResp.woD_ItemRank);
            return true;
        }

        //DB - Viewlist Record
        //DB - Delete Record
        public bool DeleteWorkOrderDetailInfo(WorkOrderDetailInfoResp workOrderDetailInfoResp)
        {
            //var obj = _dbContent.aspnet_Users.Add(obj);
            //_dbContent.SaveChanges();
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_WorkOrderDetailIds] {0}", "@woDIds = " + workOrderDetailInfoResp.woDIds + " and @woDwoMId = " + workOrderDetailInfoResp.woDwoMId);
            return true;
        }

        //DB - Viewlist Record
        public List<WorkOrderDetailInfoResp> GetWorkOrderDetailInfo()
        {
            var response = _dbContent.Database.SqlQuery<WorkOrderDetailInfoResp>
                (@"Exec [dbo].[spGet_WorkOrderItemAllItemsInfo1] ").ToList();
            return response;
        }

        //-------------//

        //DB - Insert Record
        public bool InsertWorkOrderDetailTaxInfo(WorkOrderDetailTaxInfoReq workOrderDetailTaxInfoReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_WorkOrderDetailTaxInfo] {0},{1},{2},{3},{4}",
                workOrderDetailTaxInfoReq.wotxD_woDId,
                workOrderDetailTaxInfoReq.wotxD_woMId,
                workOrderDetailTaxInfoReq.wotxD_txMId,
                workOrderDetailTaxInfoReq.wotxD_Percentage,
                workOrderDetailTaxInfoReq.wotxD_Amount
                );
            return true;
        }

        //DB - Update Record
        public bool UpdateWorkOrderDetailTaxInfo(WorkOrderDetailTaxInfoResp workOrderDetailTaxInfoResp)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_WorkOrderDetailTaxInfo] {0},{1},{2},{3},{4},{5},{6}",
                "@wotxD_Id = " + workOrderDetailTaxInfoResp.wotxD_Id,
                workOrderDetailTaxInfoResp.wotxD_woDId,
                workOrderDetailTaxInfoResp.wotxD_woMId,
                workOrderDetailTaxInfoResp.wotxD_txMId,
                workOrderDetailTaxInfoResp.wotxD_Percentage,
                workOrderDetailTaxInfoResp.wotxD_Amount);
            return true;
        }

        //DB - Viewlist Record
        //DB - Delete Record
        public bool DeleteWorkOrderDetailTaxInfo(WorkOrderDetailTaxInfoResp workOrderDetailTaxInfoResp)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_WorkOrderDetailTaxInfo] {0}", "wotxD_Id = " + workOrderDetailTaxInfoResp.wotxD_Id + " and @wotxD_woDId = " + workOrderDetailTaxInfoResp.wotxD_woDId);
            return true;
        }

        //DB - Viewlist Record
        public List<WorkOrderDetailTaxInfoResp> GetWorkOrderDetailTaxInfo(int? p1)
        {
            var response = _dbContent.Database.SqlQuery<WorkOrderDetailTaxInfoResp>
                (@"Exec [dbo].[spGet_WorkOrderDetailItemTaxInfo] {0}", p1).ToList();
            return response;
        }

        //-------------//

        //DB - Insert Record
        public bool InsertworkOrderTnCInfo(workOrderTnCInfoReq workOrderTnCInfoReq)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpInsert_workOrderTnCInfo] {0},{1},{2}",
                workOrderTnCInfoReq.TncWO_WOMId,
                workOrderTnCInfoReq.TncWO_TncMId,
                workOrderTnCInfoReq.TncWO_Description
                );
            return true;
        }

        //DB - Update Record
        public bool UpdateworkOrderTnCInfo(workOrderTnCInfoResp workOrderTnCInfoResp)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpUpdate_workOrderTnCInfo] {0},{1}",
                "@TncWO_Id = " + workOrderTnCInfoResp.TncWO_Id,
                workOrderTnCInfoResp.TncWO_TncMId,
                workOrderTnCInfoResp.TncWO_Description
                );
            return true;
        }

        //DB - Viewlist Record
        //DB - Delete Record
        public bool DeleteworkOrderTnCInfo(workOrderTnCInfoResp workOrderTnCInfoResp)
        {
            var response = _dbContent.Database.SqlQuery<object>(@"Exec [dbo].[SpDelete_workOrderTnCInfo] {0}", "TncWO_Id = " + workOrderTnCInfoResp.TncWO_Id + " and TncWO_WOMId = " + workOrderTnCInfoResp.TncWO_WOMId);
            return true;
        }

        //DB - Viewlist Record
        public List<workOrderTnCInfoResp> GetTnCInfoOnWorkOrderId(int? p1)
        {
            var response = _dbContent.Database.SqlQuery<workOrderTnCInfoResp>
                (@"Exec [dbo].[spGet_TnCInfoOnWorkOrderId] {0}", p1).ToList();
            return response;
        }

        //-------------//
        
        //List for Buyer
        public List<ListBuyerConsigneeResp> ListBuyer()
        {
            var response = _dbContent.Database.SqlQuery<ListBuyerConsigneeResp>
                (@"Exec [dbo].[spGet_ListBuyerConsignee]").ToList();
            return response;
        }

        //List for Location
        public List<ListBuyerConsigneeLocationResp> ListBuyerLocation()
        {
            var response = _dbContent.Database.SqlQuery<ListBuyerConsigneeLocationResp>
                (@"Exec [dbo].[spGet_ListBuyerConsigneeLocation]").ToList();
            return response;
        }

        //List for Consignee
        public List<ListBuyerConsigneeResp> ListConsignee()
        {
            var response = _dbContent.Database.SqlQuery<ListBuyerConsigneeResp>
                (@"Exec [dbo].[spGet_ListBuyerConsignee]").ToList();
            return response;
        }

        //List for Consignee Location
        public List<ListBuyerConsigneeLocationResp> ListConsigneeLocation()
        {
            var response = _dbContent.Database.SqlQuery<ListBuyerConsigneeLocationResp>
                (@"Exec [dbo].[spGet_ListBuyerConsigneeLocation]").ToList();
            return response;
        }

        //List for Units
        public List<ListUnitsResp> ListUnits()
        {
            var response = _dbContent.Database.SqlQuery<ListUnitsResp>
                (@"Exec [dbo].[spGet_UnitInfo]").ToList();
            return response;
        }

        //List for Dispatch Mode
        //public List<ListDispatchModeResp> ListDispatchMode()
        //{
        //    var response = _dbContent.Database.SqlQuery<ListDispatchModeResp>
        //        (@"Exec [dbo].[SpGet_ListDispatchModeInfo]").ToList();
        //    return response;
        //}

        //List for Designation
        //public List<ListDesigationResp> ListDesignation()
        //{
        //    var response = _dbContent.Database.SqlQuery<ListDesigationResp>
        //        (@"Exec [dbo].[SpGet_GeneralItemsInfo] {0}, {1}",1,0).ToList();
        //    return response;
        //}

        //List for Status
        //public List<ListStatusResp> ListStatus()
        //{
        //    var response = _checknTrack_MainDB.Database.SqlQuery<ListStatusResp>
        //        (@"Exec [dbo].[spGet_StatusInfo] {0}", "MOR").ToList();
        //    return response;
        //}

        //List for Contact
        //public List<ListContactsResp> ListCotact(int? p1)
        //{
        //    var response = _dbContent.Database.SqlQuery<ListContactsResp>
        //        (@"Exec [dbo].[spGet_LocationContactInfo] {0}", p1).ToList();
        //    return response;
        //}
    }
}