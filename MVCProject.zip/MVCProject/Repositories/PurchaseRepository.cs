﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;
using System.Data.SqlClient;

namespace MVCProject.Repositories
{
    public class PurchaseRepository : IPurchaseRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;

        //Initiliaze DB connection 
        public PurchaseRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }
        
        //PURCHASE INFO//
        //--------------//

        //DB - Insert Record
        public bool InsertPurchaseInfo(PurchaseInfoReq purchaseInfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_PurchaseOrderInfo] 
                {0},{1},{2},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14}",
                purchaseInfoReq.poM_EstMId,
                purchaseInfoReq.poM_RFQId,
                purchaseInfoReq.poM_VendorId,
                purchaseInfoReq.poM_Remarks,
                purchaseInfoReq.poM_Date,
                purchaseInfoReq.poM_ChallanDate,
                purchaseInfoReq.poM_DeliveryDate,
                purchaseInfoReq.poM_Amount,
                purchaseInfoReq.poM_FinalAmount,
                purchaseInfoReq.poM_stfMId,
                purchaseInfoReq.poM_stsMId,
                purchaseInfoReq.poM_yrMId,
                purchaseInfoReq.poM_ChallanNo,
                purchaseInfoReq.poM_lcnMId,
                purchaseInfoReq.poM_vLcMId
                );
            return true;
        }

        //DB - Update Record
        public bool UpdatePurchaseInfo(PurchaseInfoResp purchaseInfoResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_PurchaseOrderInfo] 
                {0},{1},{2},{4},{5},{6},{7},{8},{9},{10},{11},{12}",
                purchaseInfoResp.poM_Id,
                purchaseInfoResp.poM_EstMId,
                purchaseInfoResp.poM_RFQId,
                purchaseInfoResp.poM_ChallanNo,
                purchaseInfoResp.poM_VendorId,
                purchaseInfoResp.poM_Remarks,
                purchaseInfoResp.poM_Date,
                purchaseInfoResp.poM_ChallanDate,
                purchaseInfoResp.poM_DeliveryDate,
                purchaseInfoResp.poM_Amount,
                purchaseInfoResp.poM_FinalAmount,
                purchaseInfoResp.poM_Approvedby,
                purchaseInfoResp.poM_stsMId,                
                purchaseInfoResp.poM_vLcMId
                );
            return true;
        }

        //DB - Delete Record
        //No Delete SP

        //DB - Viewlist Record
        public List<PurchaseInfoResp> PurchaseInfo(int p1)
        {
            var response = _dbContent.Database.SqlQuery<PurchaseInfoResp>
                (@"Exec [dbo].[spGet_PurchaseOrderInfo] {0}," , p1).ToList();
            return response;
        }

        //PURCHASE DETAIL INFO//
        //--------------//

        //DB - Insert Record
        public bool InsertPurchaseDetailInfo(PurchaseDetailInfoReq purchaseDetailInfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_PurchaseOrderDetailInfo] 
                {0},{1},{2},{4},{5},{6}",
                purchaseDetailInfoReq.pod_poMId,
                purchaseDetailInfoReq.poD_rawMId,
                purchaseDetailInfoReq.poD_Quantity,
                purchaseDetailInfoReq.poD_Rate,
                purchaseDetailInfoReq.poD_Amount,
                purchaseDetailInfoReq.poD_DetailDescription,
                purchaseDetailInfoReq.poD_ItemRank
                );
            return true;
        }

        //DB - Update Record
        public bool UpdatePurchaseDetailInfo(PurchaseDetailInfoResp purchaseDetailInfoResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_PurchaseOrderDetailInfo] 
                {0},{1},{2},{4},{5},{6}",
                purchaseDetailInfoResp.poD_Id,
                purchaseDetailInfoResp.pod_poMId,
                purchaseDetailInfoResp.poD_rawMId,
                purchaseDetailInfoResp.poD_Quantity,
                purchaseDetailInfoResp.poD_Rate,
                purchaseDetailInfoResp.poD_Amount,
                purchaseDetailInfoResp.poD_DetailDescription,
                purchaseDetailInfoResp.poD_ItemRank
                );
            return true;
        }

        //DB - Delete Record
        public bool DeletePurchaseDetailInfo(PurchaseDetailInfoResp purchaseDetailInfoResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpDelete_PurchaseOrderDetailIds] {0},{1}",
                purchaseDetailInfoResp.poD_Id,
                purchaseDetailInfoResp.pod_poMId
                );
            return true;
        }

        //DB - Viewlist Record
        public List<PurchaseDetailInfoResp> PurchaseDetailInfo(int p1)
        {
            var response = _dbContent.Database.SqlQuery<PurchaseDetailInfoResp>
                (@"Exec [dbo].[spGet_POItemAllItemsInfo] {0}", p1).ToList();
            return response;
        }


        //PURCHASE DETAIL TAX INFO//
        //--------------//

        //DB - Insert Record
        public bool InsertPurchaseTaxDetailInfo(PurchaseTaxDetailInfoReq purchaseTaxDetailInfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_PODetailTaxDetailInfo] 
                {0},{1},{2},{3},{4},{5}",
                purchaseTaxDetailInfoReq.txD_PODId,
                purchaseTaxDetailInfoReq.txD_POMId,
                purchaseTaxDetailInfoReq.txD_txMId,
                purchaseTaxDetailInfoReq.txD_Percentage,
                purchaseTaxDetailInfoReq.txD_Amount,
                purchaseTaxDetailInfoReq.txD_FormName
                );
            return true;
        }

        //DB - Update Record
        public bool UpdatePurchaseTaxDetailInfo(PurchaseTaxDetailInfoResp purchaseTaxDetailInfoResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_PODetailTaxDetailInfo] 
                {0},{1},{2},{3},{4}",
                purchaseTaxDetailInfoResp.txD_Id,
                purchaseTaxDetailInfoResp.txD_txMId,
                purchaseTaxDetailInfoResp.txD_Percentage,
                purchaseTaxDetailInfoResp.txD_Amount,
                purchaseTaxDetailInfoResp.txD_FormName
                );
            return true;
        }

        //DB - Delete Record
        public bool DeletePurchaseTaxDetailInfo(PurchaseTaxDetailInfoResp purchaseTaxDetailInfoResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpDelete_PODetailTaxDetailInfo] {0}, {1}",
                purchaseTaxDetailInfoResp.txD_Id ,
                purchaseTaxDetailInfoResp.txD_PODId
                );
            return true;
        }

        //DB - Viewlist Record
        public List<PurchaseTaxDetailInfoResp> PurchaseTaxDetailInfo(int p1)
        {
            var response = _dbContent.Database.SqlQuery<PurchaseTaxDetailInfoResp>
                (@"Exec [dbo].[spGet_PODetailItemTaxInfo] {0}," , p1).ToList();
            return response;
        }

        //PURCHASE DETAIL TnC INFO//
        //--------------//

        //DB - Insert Record
        public bool InsertPurchaseTnCInfo(PurchaseTnCInfoReq purchaseTnCInfoReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_PurchaseOrderTnCInfo] 
                {0},{1},{2}",
                purchaseTnCInfoReq.tncPO_POMId,
                purchaseTnCInfoReq.tncPO_TncMId,
                purchaseTnCInfoReq.tncPO_Description
                );
            return true;
        }

        //DB - Update Record
        public bool UpdatePurchaseTnCInfo(PurchaseTnCInfoResp purchaseTnCInfoResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_PurchaseOrderTnCInfo] 
                {0},{1},{2},{3}",
                purchaseTnCInfoResp.TncPO_Id,
                purchaseTnCInfoResp.tncPO_POMId,
                purchaseTnCInfoResp.tncPO_TncMId,
                purchaseTnCInfoResp.tncPO_Description
                );
            return true;
        }

        //DB - Delete Record
        public bool DeletePurchaseTnCInfo(PurchaseTnCInfoResp purchaseTnCInfoResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpDelete_PurchaseOrderTnCInfo] {0}, {1}",
                purchaseTnCInfoResp.TncPO_Id ,
                purchaseTnCInfoResp.tncPO_POMId
                );
            return true;
        }

        //DB - Viewlist Record
        public List<PurchaseTnCInfoResp> PurchaseTnCInfo(int p1)
        {
            var response = _dbContent.Database.SqlQuery<PurchaseTnCInfoResp>
                (@"Exec [dbo].[spGet_POTnCInfo] {0}," , p1).ToList();
            return response;
        }

        //DB - Viewlist Record
        public List<PurchaseInfoResp> GetPurchaseRegister(int? p1, DateTime? d1, DateTime? d2)
        {
            //var p1 = 20;
            //var d1 = Convert.ToDateTime("1900-01-01");
            //var d2 = Convert.ToDateTime("2021-01-21");

            var response = _dbContent.Database.SqlQuery<PurchaseInfoResp>
                (@"Exec [dbo].[spGet_PORegister] 
                @StaffId,
                @InvoiceDt1,
                @InvoiceDt2",
                new SqlParameter("@StaffId", p1),
                new SqlParameter("@InvoiceDt1", d1),
                new SqlParameter("@InvoiceDt2", d2)
                ).ToList();
            return response;
        }

        public List<ListVendorResp> ListVendor()
        {
            var response = _dbContent.Database.SqlQuery<ListVendorResp>
                (@"Exec [dbo].[spGet_VendorInfo] ").ToList();
            return response;
        }
    }
}