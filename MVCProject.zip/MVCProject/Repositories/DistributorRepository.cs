﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using MVCProject.IRepositories;
using System;
using System.Web;

namespace MVCProject.Repositories
{
    public class DistributorRepository 
    {
        //DB Connection
        private DBContent _dbContent;
        public DistributorRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //Insert Method using calling SP from Database
        public bool InsertDistributor(DistributorReq distributorReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpInsert_DistributorInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},
                {10},{11},{12},{13},{14},{15},{16},{17}", 
                distributorReq.dstM_CompanyName.Trim(), 
                distributorReq.dstM_ContactPerson.Trim(), 
                distributorReq.dstM_Address.Trim(), 
                distributorReq.dstM_MobileNo.Trim(), 
                distributorReq.dstM_ContactNumber1.Trim(), 
                distributorReq.dstM_ContactNumber2.Trim(), 
                distributorReq.dstM_Email.Trim(), 
                distributorReq.dstM_Fax.Trim(), 
                distributorReq.dstM_PAN.Trim(), 
                distributorReq.dstM_CST.Trim(), 
                distributorReq.dstM_VAT.Trim(),
                //distributorReq.dstM_Type,
                distributorReq.dstM_GSTiN.Trim(),
                distributorReq.dstM_TAN.Trim(),
                distributorReq.dstM_CIN.Trim(),
                distributorReq.dstM_City.Trim(),
                distributorReq.dstM_State.Trim(),
                distributorReq.dstM_Region.Trim(),
                distributorReq.dstM_Pincode.Trim()
                );
            return true;
        }

        //Update Method using calling SP from Database
        //SP Name : [dbo].[SpInsert_DistributorInfo]    
        public bool UpdateDistributor(DistributorReq distributorResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpUpdate_DistributorInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},
                {10},{11},{12},{13},{14},{15},{16},{17}",
                distributorResp.dstM_CompanyName.Trim(),
                distributorResp.dstM_ContactPerson.Trim(),
                distributorResp.dstM_Address.Trim(),
                distributorResp.dstM_MobileNo.Trim(),
                distributorResp.dstM_ContactNumber1.Trim(),
                distributorResp.dstM_ContactNumber2.Trim(),
                distributorResp.dstM_Email.Trim(),
                distributorResp.dstM_Fax.Trim(),
                distributorResp.dstM_PAN.Trim(),
                distributorResp.dstM_CST.Trim(),
                distributorResp.dstM_VAT.Trim(),
                distributorResp.dstM_Id,
                distributorResp.dstM_TAN.Trim(),
                distributorResp.dstM_CIN.Trim(),
                distributorResp.dstM_City.Trim(),
                distributorResp.dstM_State.Trim(),
                distributorResp.dstM_Region.Trim(),
                distributorResp.dstM_Pincode.Trim());
            return true;
        }

        //DB - Delete Record
        public bool DeleteDistributor(DistributorReq distributorResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (
                @"Exec [dbo].[SpDelete_DistributorInfo] {0}", 
                distributorResp.dstM_Id
                );
            return true;
        }

        //List method using calling SP from database
        public List<GetDistributorResp> GetAllDistributor()
        {            
            var response = _dbContent.Database.SqlQuery<GetDistributorResp>
                (
                @"Exec [dbo].[spGet_DistributorInfo] {0}","0"
                ).ToList();
            return response;
        }

        //DB - Viewlist Record
        public List<ClientBankMasterReq> DistributorBankMaster(int? p1, string p2)
        {
            var response = _dbContent.Database.SqlQuery<ClientBankMasterReq>
                (
                @"Exec [dbo].[spGet_ClientBankInfo] {0}, {1}", p1,p2
                ).ToList();
            return response;
        }
    }
}