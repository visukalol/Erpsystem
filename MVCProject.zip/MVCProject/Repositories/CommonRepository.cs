﻿using MVCProject.Models.DBModel;
using MVCProject.IRepositories;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;
using System.Data.SqlClient;

namespace MVCProject.Repositories
{
    public class CommonRepository : ICommonRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;
        private ChecnTrack_MainDB _checknTrack_MainDB;

        //Initiliaze DB connection 
        public CommonRepository(DBContent dbContent, ChecnTrack_MainDB checknTrack_MainDB)
        {
            _dbContent = dbContent;
            _checknTrack_MainDB = checknTrack_MainDB;
        }

        //-------------//

        //List for Buyer
        public List<ListBuyerConsigneeResp> ListBuyer()
        {
            var response = _dbContent.Database.SqlQuery<ListBuyerConsigneeResp>
                (@"Exec [dbo].[spGet_ListBuyerConsignee]").ToList();
            return response;
        }

        //List for Location
        public List<ListBuyerConsigneeLocationResp> ListBuyerLocation()
        {
            var response = _dbContent.Database.SqlQuery<ListBuyerConsigneeLocationResp>
                (@"Exec [dbo].[spGet_ListBuyerConsigneeLocation]").ToList();

          
            return response;
        }

        //List for Consignee
        public List<ListBuyerConsigneeResp> ListConsignee()
        {
            var response = _dbContent.Database.SqlQuery<ListBuyerConsigneeResp>
                (@"Exec [dbo].[spGet_ListBuyerConsignee]").ToList();
            return response;
        }

        //List for Consignee Location
        public List<ListBuyerConsigneeLocationResp> ListConsigneeLocation()
        {
            var response = _dbContent.Database.SqlQuery<ListBuyerConsigneeLocationResp>
                (@"Exec [dbo].[spGet_ListBuyerConsigneeLocation]").ToList();
            return response;
        }

        //List For Product Group
        public List<ListProductGroupResp> ListProductgroup()
        {
            var response = _dbContent.Database.SqlQuery<ListProductGroupResp>
                (@"Exec [dbo].[SpGet_ItemGroupInfo]").ToList();
            return response;
        }

        //List for Units
        public List<ListUnitsResp> ListUnits()
        {
            var response = _dbContent.Database.SqlQuery<ListUnitsResp>
                (@"Exec [dbo].[spGet_UnitInfo]").ToList();
            return response;
        }

        //List for Dispatch Mode
        public List<ListDispatchModeResp> ListDispatchMode()
        {
            var response = _dbContent.Database.SqlQuery<ListDispatchModeResp>
                (@"Exec [dbo].[SpGet_ListDispatchModeInfo]").ToList();
            return response;
        }

        //List for Designation
        public List<ListDesigationResp> ListDesignation()
        {
            var response = _dbContent.Database.SqlQuery<ListDesigationResp>
                (@"Exec [dbo].[SpGet_DesignationInfo] ").ToList();
            return response;
        }

        //List for Status
        public List<ListStatusResp> ListStatus()
        {
            var response = _checknTrack_MainDB.Database.SqlQuery<ListStatusResp>
                (@"Exec [dbo].[spGet_ListStatusInfo]").ToList();
            return response;
        }

        //List for Contact
        public List<ListContactsResp> ListContacts(int? p1)
        {
            var response = _dbContent.Database.SqlQuery<ListContactsResp>
                (@"Exec [dbo].[spGet_LocationContactInfo] {0}", p1).ToList();
            return response;
        }


        // List For Project Name
        public List<ListProjectResp> ListProject()
        {
            var response = _dbContent.Database.SqlQuery<ListProjectResp>
                (@"Exec [dbo].[spGet_ProjectInfo] ").ToList();
            return response;
        }

        //List for Department
        public List<ListDepartmentResp> ListDepartment()
        {
            var response = _dbContent.Database.SqlQuery<ListDepartmentResp>
                (@"Exec [dbo].[spGet_DepartmentInfo]").ToList();
            return response;
        }

        //List for Staff
        public List<ListStaffResp> ListStaff()
        {
            var response = _checknTrack_MainDB.Database.SqlQuery<ListStaffResp>
                (@"Exec [dbo].[spGet_StaffInfo]").ToList();
            return response;
        }

        //list for Department wise Staff
        public List<ListDepartmentStaffResp> ListDepartmentStaff(string stfM_Name)
        {
            var response = _dbContent.Database.SqlQuery<ListDepartmentStaffResp>
                (@"Exec [dbo].[spGet_DepartmentInfo1] {0}", stfM_Name).ToList();
            return response;
        }

        //List For Registration No
        public List<ListRegNoResp> ListRegNo()
        {
            var response = _dbContent.Database.SqlQuery<ListRegNoResp>
                (@"Exec [dbo].[spGet_RegNoInfo]").ToList();
            return response;
        }

        //List For Distributor
        public List<ListDistributorResp> ListDistributor()
        {
            var response = _dbContent.Database.SqlQuery<ListDistributorResp>
                (@"Exec [dbo].[spGet_DistributorList]").ToList();
            return response;
        }

        //List for Category
        public List<ListCategoryResp> ListCategory()
        {
            var response = _dbContent.Database.SqlQuery<ListCategoryResp>
                (@"Exec [dbo].[spGet_CategoryInfo]").ToList();
            return response;
        }

        //List for Product Group
        public List<ListProductGroupResp> ListProductGroup()
        {
            var response = _dbContent.Database.SqlQuery<ListProductGroupResp>
                (@"Exec [dbo].[SpGet_ItemGroupInfo]").ToList();
            return response;
        }

        //List for Material
        public List<ListMaterialResp> ListMaterial()
        {
            var response = _dbContent.Database.SqlQuery<ListMaterialResp>
                (@"Exec [dbo].[spGet_ListMaterial]").ToList();
            return response;
        }

        //List for Certificate
        public List<ListCertificateResp> ListCertificate()
        {
            var response = _dbContent.Database.SqlQuery<ListCertificateResp>
                (@"Exec [dbo].[SpGet_ListCertificate]").ToList();
            return response;
        }

        //List for FinanceYear
        public List<ListFinanceYearResp> ListFinanceYear()
        {
            var response = _checknTrack_MainDB.Database.SqlQuery<ListFinanceYearResp>
                (@"Exec [dbo].[spGet_ListFinancialYear]").ToList();
            return response;
        }

        //List for Company
        public List<ListCompanyResp> ListCompany()
        {
            var response = _checknTrack_MainDB.Database.SqlQuery<ListCompanyResp>
                (@"Exec [dbo].[spGet_CompanyInfo]").ToList();
            return response;
        }

        //List for Roles
        public List<ListRolesResp> ListAllRoles()
        {
            var response = _checknTrack_MainDB.Database.SqlQuery<ListRolesResp>
                (@"Exec [dbo].[spGet_RolesInfo]").ToList();
            return response;
        }

        //List for Cat1
        public List<ListCat1Resp> ListCat1()
        {
            var response = _dbContent.Database.SqlQuery<ListCat1Resp>
                (@"Exec [dbo].[spGet_RawCategoryInfo] {0}", 1).ToList();
            return response;
        }
        //List for Cat2
        public List<ListCat1Resp> ListCat2()
        {
            var response = _dbContent.Database.SqlQuery<ListCat1Resp>
                (@"Exec [dbo].[spGet_RawCategoryInfo] {0}", 2).ToList();
            return response;
        }
        //List for Cat3
        public List<ListCat1Resp> ListCat3()
        {
            var response = _dbContent.Database.SqlQuery<ListCat1Resp>
                (@"Exec [dbo].[spGet_RawCategoryInfo] {0}", 3).ToList();
            return response;
        }
        //List for Cat4
        public List<ListCat1Resp> ListCat4()
        {
            var response = _dbContent.Database.SqlQuery<ListCat1Resp>
                (@"Exec [dbo].[spGet_RawCategoryInfo] {0}", 4).ToList();
            return response;
        }
        //List for Cat5
        public List<ListCat1Resp> ListCat5()
        {
            var response = _dbContent.Database.SqlQuery<ListCat1Resp>
                (@"Exec [dbo].[spGet_RawCategoryInfo] {0}", 5).ToList();
            return response;
        }

        //list for location
        public List<ListLocationResp> ListLocation()
        {
            var response = _dbContent.Database.SqlQuery<ListLocationResp>
                (@"Exec [dbo].[spGet_LocationInfo]").ToList();
            return response;
        }


    }
}