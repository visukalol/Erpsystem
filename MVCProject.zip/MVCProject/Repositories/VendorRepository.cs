﻿using MVCProject.Models.DBModel;
using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Repositories
{
    public class VendorRepository
    {
        //Variable declaration of DB Connection
        private DBContent _dbContent;

        //Initiliaze DB connection 
        public VendorRepository(DBContent dbContent)
        {
            _dbContent = dbContent;
        }

        //DB - Insert Record
        public bool InsertVendor(VendorReq vendorReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_VendorInfo] 
                {0},{1},{2},{3},{4}",
                vendorReq.vndM_CompanyName.Trim(),
                vendorReq.vndM_ContactPerson.Trim(),
                vendorReq.vndM_Email.Trim(),
                vendorReq.vndM_PAN.Trim(),
                vendorReq.vndM_Code.Trim());
              // vendorReq.vndM_TAN.Trim(),
               // vendorReq.vndM_CIN.Trim());
            return true;
        }

        //DB - Update Record
        public bool UpdateVendor(VendorReq vendorResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_VendorInfo] 
                {0},{1},{2},{3},{4},{5}",
                vendorResp.vndM_Id,
                vendorResp.vndM_CompanyName.Trim(),
                vendorResp.vndM_ContactPerson.Trim(),
                vendorResp.vndM_Email.Trim(),
                vendorResp.vndM_PAN.Trim(),
                vendorResp.vndM_Code.Trim());
                //vendorResp.vndM_TAN.Trim(),
                //vendorResp.vndM_CIN.Trim());
            return true;
        }

        //DB - Delete Record
        public bool DeleteVendor(VendorReq vendorResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpDelete_VendorInfo] {0}", 
                vendorResp.vndM_Id);
            return true;
        }

        //DB - Viewlist Record
        public List<GetVendorResp> GetAllVendor()
        {
            var response = _dbContent.Database.SqlQuery<GetVendorResp>
                (@"Exec [dbo].[spGet_VendorInfo]").ToList();
            return response;
        }

        //Table - Vendor Location
        //DB - Insert Record
        public bool InsertVendorLocation(VendorLocationReq vendorlocationReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpInsert_VendorLocationInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},
                {10},{11}",
                    vendorlocationReq.vLcM_vndMId,
                    vendorlocationReq.vLcM_Code,
                    vendorlocationReq.vLcM_Address,
                    vendorlocationReq.vLcM_City,
                    vendorlocationReq.vLcM_State,
                    vendorlocationReq.vLcM_Country,
                    vendorlocationReq.vLcM_Zip,
                    vendorlocationReq.vLcM_ECC,
                    vendorlocationReq.vLcM_ER,
                    vendorlocationReq.vLcM_CST,
                    vendorlocationReq.vLcM_VAT,
                    vendorlocationReq.vLcM_GSTiN);
            return true;
        }

        //DB - Update Record
        public bool UpdateVendorLocation(GetVendorLocationResp vendorlocationResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand
                (@"Exec [dbo].[SpUpdate_VendorLocationInfo] 
                {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},
                {10},{11}", 
                    vendorlocationResp.vLcM_Id,
                    vendorlocationResp.vLcM_vndMId,
                    vendorlocationResp.vLcM_Code,
                    vendorlocationResp.vLcM_Address,
                    vendorlocationResp.vLcM_City,
                    vendorlocationResp.vLcM_State,
                    vendorlocationResp.vLcM_Country,
                    vendorlocationResp.vLcM_Zip,
                    vendorlocationResp.vLcM_ECC,
                    vendorlocationResp.vLcM_ER,
                    vendorlocationResp.vLcM_CST,
                    vendorlocationResp.vLcM_VAT,
                    vendorlocationResp.vLcM_GSTiN);
            return true;
        }

        //DB - Delete Record
        //Delete Vendor location when Vendor delete method is being executed

        //Datatable - 
        //View All VendorLocation based on Vendor
        public List<GetClientLocationResp> GetAllVendorLocation(int? p1, string flag)
        {
            var response = _dbContent.Database.SqlQuery<GetClientLocationResp>
                (@"Exec [dbo].[spGet_VendorLocationInfo] {0}, {1}", p1 , flag).ToList();
            return response;
        }

        //DataTable
        //View All Vendor RawMaterial based on Vendor
        public List<GetVendorRawMaterialResp> GetAllVendorRawMaterial(int? p1)
        {
            var response = _dbContent.Database.SqlQuery<GetVendorRawMaterialResp>
                (@"Exec [dbo].[spGet_RawMaterialInfoOnVendorId] {0}", p1).ToList();
            return response;
        }

        //DataTable
        //View All Vendor RawMaterial based on Vendor
        public List<ClientBankMasterResp> VendorBankMaster(int? p1, string p2)
        {
            var response = _dbContent.Database.SqlQuery<ClientBankMasterResp>
                (@"Exec [dbo].[spGet_ClientBankInfo] {0}, {1}", p1, p2).ToList();
            return response;
        }

        //Datatable - 
        //View All Vendor Location Contacts based on Vendor Location Datatable row selection
        public List<GetVendorLocationContactResp> GetAllVendorLocationContact(int? p1)
        {
            var response = _dbContent.Database.SqlQuery<GetVendorLocationContactResp>
                (@"Exec [dbo].[spGet_VendorLocationContactInfo] {0}", p1).ToList();
            return response;
        }

        //Table - Vendor Location Contacts
        //DB - Insert Record
        public bool InsertVendorLocationContact(VendorLocationContactReq vendorlocationcontactReq)
        {
            var response = _dbContent.Database.ExecuteSqlCommand(@"Exec [dbo].[SpInsert_VendorLocationContactInfo] {0},{1},{2},{3},{4},{5},{6},{7},{8}",
                    vendorlocationcontactReq.vcntM_ContactPerson,
                    vendorlocationcontactReq.vcntM_Mobile,
                    vendorlocationcontactReq.vcntM_Resi,
                    vendorlocationcontactReq.vcntM_eMail,
                    vendorlocationcontactReq.vcntM_Phone1,
                    vendorlocationcontactReq.vcntM_Phone2,
                    vendorlocationcontactReq.vcntM_FAX,
                    vendorlocationcontactReq.vcntM_vLcMId);
            return true;
        }

        //DB - Update Record
        public bool UpdateVendorLocationContact(GetVendorLocationContactResp vendorlocationcontactResp)
        {
            var response = _dbContent.Database.ExecuteSqlCommand(@"Exec [dbo].[SpUpdate_VendorLocationContactInfo] {0},{1},{2},{3},{4},{5},{6}", "vcntM_Id = " + vendorlocationcontactResp.vcntM_Id,
                    vendorlocationcontactResp.vcntM_ContactPerson,
                    vendorlocationcontactResp.vcntM_Mobile,
                    vendorlocationcontactResp.vcntM_Resi,
                    vendorlocationcontactResp.vcntM_eMail,
                    vendorlocationcontactResp.vcntM_Phone1,
                    vendorlocationcontactResp.vcntM_Phone2,
                    vendorlocationcontactResp.vcntM_FAX);
            return true;
        }

        //DB - Delete Record
        //Delete Vendor location contact when Vendor delete method is being executed        

    }
}