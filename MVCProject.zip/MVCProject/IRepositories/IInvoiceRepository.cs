﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IInvoiceRepository
    {
        //INVOICE INFO//
        //--------------    
        //Insert   
        bool InsertInvoiceInfo(InvoiceInfoReq InvoiceInfoReq);
        //Update
        bool UpdateInvoiceInfo(InvoiceInfoResp InvoiceInfoResp, int p1);

        //Delete
        bool DeleteInvoiceInfo(InvoiceInfoResp InvoiceInfoResp, int p1);

        List<InvoiceInfoResp> InvoiceInfoResp(int p1);

        //INVOICE DETAIL INFO//
        //--------------------
        //Insert   
        bool InsertInvoiceDetailInfo(InvoiceDetailInfoReq InvoiceDetailInfoReq);
        //Update
        bool UpdateInvoiceDetailInfo(InvoiceDetailInfoResp InvoicDetailInfoResp, int p1);

        //Delete
        bool DeleteInvoiceDetailInfo(InvoiceDetailInfoResp InvoiceDetailInfoResp, int p1);

        List<InvoiceDetailInfoResp> InvoiceDetailInfoResp(int p1);

        //INVOICE DETAIL TAX INFO//
        //--------------------
        //Insert   
        bool InsertInvoiceDetailTaxInfo(InvoiceDetailTaxInfoReq InvoiceDetailTaxInfoReq);
        //Update
        bool UpdateInvoiceDetailTaxInfo(InvoiceDetailTaxInfoResp InvoicDetailTaxInfoResp, int p1);

        //Delete
        bool DeleteInvoiceDetailTaxInfo(InvoiceDetailTaxInfoResp InvoiceDetailTaxInfoResp, int p1);

        List<InvoiceDetailTaxInfoResp> InvoiceDetailTaxInfoResp(int p1);
    }
}