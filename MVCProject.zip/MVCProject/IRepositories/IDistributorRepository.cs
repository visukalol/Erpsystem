﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IDistributorRepository
    {
        //INSERT
        bool InsertDistributor(DistributorReq DistributorReq);
        //UPDATE
        bool UpdateDistributor(DistributorReq DistributorResp);
        //DELETE
        bool DeleteDistributor(DistributorReq DistributorResp);
        //List
        List<GetDistributorResp> GetAllDistributor();
    }
}