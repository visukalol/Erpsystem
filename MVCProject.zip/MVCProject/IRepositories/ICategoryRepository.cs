﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface ICategoryRepository
    {
        //Insert   
        bool InsertCategory(CategoryReq CategoryReq);
        //Update
        bool UpdateCategory(CategoryReq CategoryResp);
        //Delete
        bool DeleteCategory(CategoryReq CategoryResp);
        bool Insertprj(QTHeaderReq QtheaderReq);

        List<GetCategoryResp> GetAllCategory();
        List<ListEnquiryResp> ListEnquiry();
        List<ListQuotationResp> ListEnquirylist(string enqM_RegNo);
        List<ListCompanyCodeResp> ListCompanyCode();
        List<ListContactResp> ListContact();
        List<ListQuotatiionResp> Listquotation();
        List<ListDesignationResp> Listdesignation();
        List<QTHeaderReq> GetAllProductcodelist();
    }
}