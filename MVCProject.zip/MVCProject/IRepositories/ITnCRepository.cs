﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface ITnCRepository
    {
        //INSERT   
        bool InsertTnCMaster(TnCMasterReq TnCMasterReq);
        //UPDATE
        bool UpdateTnCMaster(TnCMasterReq TnCMasterResp);
        //DELETE
        bool DeleteTnCMaster(TnCMasterReq TnCMasterResp);

        List<TnCMasterResp> GetAllTnCMaster();

        //INSERT   
        bool InsertTnCDescriptionInfo(TnCDescriptionInfoReq TnCDescriptionInfoReq);
        //UPDATE
        bool UpdateTnCDescriptionInfo(TnCDescriptionInfoResp TnCDescriptionInfoResp);
        //DELETE
        bool DeleteTnCDescriptionInfo(TnCDescriptionInfoResp TnCDescriptionInfoResp);

    }
}