﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System.Collections.Generic;

namespace MVCProject.IRepositories
{
    public interface IRawMaterialRepository
    {
        //INSERT   
        bool InsertRawMaterial(RawMaterialReq RawMaterialReq);
        //UPDATE
        bool UpdateRawMaterial(RawMaterialReq RawMaterialResp);
        //DELETE
        bool DeleteRawMaterial(RawMaterialReq RawMaterialResp);
        //LIST
        List<GetRawMaterialResp> GetAllRawMaterial();
        //INSERT CATEGORY MATERIAL
        bool InsertRawMaterialCategory(RawMaterialCategoryReq rawMaterialCategoryReq);

        //Get data from RawMaterialCategoryMaster
        List<GetRawCategoryResp> GetRawCategory();
    }
}