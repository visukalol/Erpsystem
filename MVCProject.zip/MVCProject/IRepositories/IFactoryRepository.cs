﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IFactoryRepository
    {
        //INSERT
        bool InsertFactory(FactoryReq FactoryReq);
        //UPDATE
        bool UpdateFactory(FactoryReq FactoryResp);
        //DELETE
        //No Definition

        List<GetFactoryResp> GetAllFactory();
        
        //Insert Designation
        bool InsertDesignation(DesignationReq designationReq);

        //Delete Designation
        bool UpdateDesignation(DesignationResp designationResp);
        List<GetDesignationResp> getalldesignation();
    }
}