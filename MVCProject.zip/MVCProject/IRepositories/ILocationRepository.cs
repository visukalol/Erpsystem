﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Models.ResponseModel.Location;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface ILocationRepository
    {
        //Insert   
        bool InsertLocation(LocationResp locationReq);
        //Update
        //bool UpdateLocation(LocationReq locationReq);
        //Delete
        //bool DeleteLocation(LocationReq locationReq);

        //List<GetCategoryResp> GetAllCategory();
    }
}