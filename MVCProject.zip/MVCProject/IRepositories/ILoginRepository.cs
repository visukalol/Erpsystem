﻿using MVCProject.Models;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface ILoginRepository
    {
        LoginResp CheckLogin(string userid, string password, int Id);
        List<Login> forlogin();
    }
}