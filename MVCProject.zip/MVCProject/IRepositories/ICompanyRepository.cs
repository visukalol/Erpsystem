﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface ICompanyRepository
    {
        //Insert   
        bool InsertCompany(CompanyReq CompanyReq);
        //Update
        bool UpdateCompany(CompanyReq CompanyResp);

        List<GetCompanyResp> GetAllCompany();
        List<GetClientLocationResp> GetCompanyLocation(int? p1, string p2);
    }
}