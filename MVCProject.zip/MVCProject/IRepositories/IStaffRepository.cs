﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IStaffRepository
    {
        //INSERT    
        bool InsertStaff(StaffReq staffReq);
        //UPDATE    
        bool UpdateStaff(StaffReq staffResp);
        //DELETE    
        bool DeleteStaff(StaffReq staffResp);

        List<GetStaffResp> GetAllStaff();
        //List<GetRolesResp> GetAllRoles();
        //List<ListLocationResp> ListLocation();
    }
}