﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface ICommonRepository
    {
        List<ListBuyerConsigneeResp> ListBuyer();
        List<ListBuyerConsigneeLocationResp> ListBuyerLocation();
        List<ListBuyerConsigneeResp> ListConsignee();
        List<ListBuyerConsigneeLocationResp> ListConsigneeLocation();
        List<ListUnitsResp> ListUnits();
        List<ListContactsResp> ListContacts(int? p1);
        List<ListStatusResp> ListStatus();
        List<ListDesigationResp> ListDesignation();
        List<ListLocationResp> ListLocation();
        List<ListRegNoResp> ListRegNo();
        List<ListDepartmentResp> ListDepartment();
        List<ListCat1Resp> ListCat1();
        List<ListCat1Resp> ListCat2();
        List<ListCat1Resp> ListCat3();
        List<ListCat1Resp> ListCat4();
        List<ListStaffResp> ListStaff();
        List<ListDepartmentStaffResp> ListDepartmentStaff(string stfM_Name);
        List<ListDistributorResp> ListDistributor();
        List<ListProjectResp> ListProject();

    }
}