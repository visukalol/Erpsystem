﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IEnquiryRepository
    {
        //INSERT
        bool InsertEnquiry(EnquiryReq EnquiryReq);
        //UPDATE
        bool UpdateEnquiry(EnquiryReq EnquiryResp);
        //DELETE
        bool DeleteEnquiry(EnquiryReq EnquiryResp);

        //LIST
        //List<GetEnquiryResp> GetAllEnquiry(int? p1,bool? p2, DateTime? p3, DateTime? p4);
        List<GetEnquiryResp> GetAllEnquiry(int? p1, DateTime? p3, DateTime? p4);

        bool InsertEnquiryAssign(EnquiryAssignInfoReq enquiryassigninfoReq);
        bool InsertEnquiryDivert(EnquiryDivertInfoReq EnquirydivertinfoReq);
        bool InsertEnquiryRegret(EnquiryRegretInfoReq EnquiryRegretinfoReq);
        List<EnquiryAssignInfoResp> GetAllAssignEnquiry();
        List<EnquiryDivertInfoResp> GetAllDivertEnquiry();
        List<EnquiryRegretInfoResp> GetAllRegretEnquiry();



    }
}