﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using MVCProject.Models.ResponseModel.Location;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IClientRepository
    {
        //INSERT
        bool InsertClient(ClientReq ClientReq);
        //UPDATE
        bool UpdateClient(ClientReq ClientResp);
        //DELETE
        bool DeleteClient(ClientReq ClientResp);

        //LIST
        List<GetClientResp> GetAllClient();

        //LIST
        //List<LocationContactsResp> LocationContacts(int? p1, string p2);
    }
}