﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IItemRepository
    {
        //INSERT
        bool InsertItem(ItemReq ItemReq);
        //UPDATE
        bool UpdateItem(ItemReq ItemResp);
        //DELETE
        bool DeleteItem(ItemReq ItemResp);

        //LIST
        List<GetItemResp> GetAllItem();
    }
}