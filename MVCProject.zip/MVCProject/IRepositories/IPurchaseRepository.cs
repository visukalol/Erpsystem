﻿using MVCProject.Models.RequestModel;
using System.Collections.Generic;
using MVCProject.Models.ResponseModel;
using System;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IPurchaseRepository
    {
        //INSERT
        bool InsertPurchaseInfo(PurchaseInfoReq purchaseInfoReq);
        //UDPATE
        bool UpdatePurchaseInfo(PurchaseInfoResp purchaseInfoResp);
        //DELETE
        //No Delete SP

        //LIST
        List<PurchaseInfoResp> PurchaseInfo(int p1);

        //INSERT
        bool InsertPurchaseDetailInfo(PurchaseDetailInfoReq purchaseDetailInfoReq);
        //UDPATE
        bool UpdatePurchaseDetailInfo(PurchaseDetailInfoResp purchaseDetailInfoResp);
        //DELETE
        bool DeletePurchaseDetailInfo(PurchaseDetailInfoResp purchaseDetailInfoResp);

        //LIST
        List<PurchaseDetailInfoResp> PurchaseDetailInfo(int p1);

        //INSERT
        bool InsertPurchaseTaxDetailInfo(PurchaseTaxDetailInfoReq purchaseTaxDetailInfoReq);
        //UDPATE
        bool UpdatePurchaseTaxDetailInfo(PurchaseTaxDetailInfoResp purchaseTaxDetailInfoResp);
        //DELETE
        bool DeletePurchaseTaxDetailInfo(PurchaseTaxDetailInfoResp purchaseTaxDetailInfoResp);

        //LIST
        List<PurchaseTaxDetailInfoResp> PurchaseTaxDetailInfo(int p1);

        //INSERT
        bool InsertPurchaseTnCInfo(PurchaseTnCInfoReq purchaseTnCInfoReq);
        //UDPATE
        bool UpdatePurchaseTnCInfo(PurchaseTnCInfoResp purchaseTnCInfoResp);
        //DELETE
        bool DeletePurchaseTnCInfo(PurchaseTnCInfoResp purchaseTnCInfoResp);

        //LIST
        List<PurchaseTnCInfoResp> PurchaseTnCInfo(int p1);
    }
}