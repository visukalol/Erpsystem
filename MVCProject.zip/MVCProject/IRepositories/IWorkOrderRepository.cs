﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IWorkOrderRepository
    {
        
        //Insert   
        bool InsertWorkOrder(WorkOrderInfoReq WorkOrderInfoReq);
        //Update
        bool UpdateWorkOrder(WorkOrderInfoResp WorkOrderInfoResp);
        //Delete
        //bool DeleteWorkOrder(WorkOrderInfoResp WorkOrderInfoResp);

        List<WorkOrderInfoResp> GetAllWorkOrder(int? p1, DateTime? d1, DateTime? d2, int? p2);
        List<WorkOrderInfoResp> GetWorkOrderMaster(int? p1);

        //Insert   
        bool InsertWorkOrderDetailInfo(WorkOrderDetailInfoReq WorkOrderDetailInfoReq);
        //Update
        bool UpdateWorkOrderDetailInfo(WorkOrderDetailInfoResp WorkOrderDetailInfoResp);
        //Delete
        bool DeleteWorkOrderDetailInfo(WorkOrderDetailInfoResp WorkOrderDetailInfoResp);

        List<WorkOrderDetailInfoResp> GetWorkOrderDetailInfo();

        //Insert   
        bool InsertworkOrderTnCInfo(workOrderTnCInfoReq workOrderTnCInfoReq);
        //Update
        bool UpdateworkOrderTnCInfo(workOrderTnCInfoResp workOrderTnCInfoResp);
        //Delete
        bool DeleteworkOrderTnCInfo(workOrderTnCInfoResp workOrderTnCInfoResp);

        List<workOrderTnCInfoResp> GetTnCInfoOnWorkOrderId(int? p1);

        //Insert   
        bool InsertWorkOrderDetailTaxInfo(WorkOrderDetailTaxInfoReq WorkOrderDetailTaxInfoReq);
        //Update
        bool UpdateWorkOrderDetailTaxInfo(WorkOrderDetailTaxInfoResp WorkOrderDetailTaxInfoResp);
        //Delete
        bool DeleteWorkOrderDetailTaxInfo(WorkOrderDetailTaxInfoResp WorkOrderDetailTaxInfoResp);

        List<WorkOrderDetailTaxInfoResp> GetWorkOrderDetailTaxInfo(int? p1);
    }
}