﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IVendorRepository
    {
        //Insert   
        bool InsertVendor(VendorReq VendorReq);
        //Update
        bool UpdateVendor(GetVendorResp VendorResp);
        //Delete
        bool DeleteVendor(GetVendorResp VendorResp);

        //Insert   
        bool InsertVendorLocation(VendorLocationReq VendorLocationReq);
        //Update
        bool UpdateVendorLocation(GetVendorLocationResp VendorLocationResp);

        //Insert   
        bool InsertVendorLocationContact(VendorLocationContactReq VendorLocationContactReq);
        //Update
        bool UpdateVendorLocationContact(GetVendorLocationContactResp VendorLocationContactResp);

        List<GetVendorResp> GetAllVendor();
        List<GetVendorLocationResp> GetAllVendorLocation();
        List<GetVendorLocationContactResp> GetAllVendorLocationContact();
    }
}