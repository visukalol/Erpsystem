﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface IQuotationRepository
    {
        //Insert   
        bool InsertQuotationHdr(QTHeaderReq QTHeaderReq);
        //Update
        bool UpdateQuotationHdr(QTHeaderResp QTHeaderResp);
        //Delete
        bool DeleteQuotationHdr(QTHeaderResp QTHeaderResp);


        //Insert   
        bool InsertQTDetailReq(QTDetailReq QTDetailResp);
        //Update
        bool UpdateQTDetailResp(QTDetailResp QTDetailResp);
        //Delete
        bool DeleteQTDetailResp(QTDetailResp QTDetailResp);


        //Insert   
        bool InsertQTActivityReq(QTActivityReq QTActivityReq);
        //Update
        bool UpdateQTActivityResp(QTActivityResp QTActivityResp);
        //Delete
        bool DeleteQTActivityResp(QTActivityResp QTActivityResp);


        //Insert   
        bool InsertQTGroupCertificateReq(QTGroupCertificateReq QTGroupCertificateReq);
        //Update
        bool UpdateQTGroupCertificateResp(QTGroupCertificateResp QTGroupCertificateResp);
        //Delete
        bool DeleteQTGroupCertificateResp(QTGroupCertificateResp QTGroupCertificateResp);

        //Insert   
        bool InsertQTGroupDetailReq(QTGroupDetailReq QTGroupDetailReq);
        //Update
        bool UpdateQTGroupDetailResp(QTGroupDetailResp QTGroupDetailResp);
        //Delete
        bool DeleteQTGroupDetailResp(QTGroupDetailResp QTGroupDetailResp);

        //Insert   
        bool InsertQTGroupItemParameterReq(QTGroupItemParameterReq QTGroupItemParameterReq);
        //Update
        bool UpdateQTGroupItemParameterResp(QTGroupItemParameterResp QTGroupItemParameterResp);
        //Delete
        bool DeleteQTGroupItemParameterResp(QTGroupItemParameterResp QTGroupItemParameterResp);

        //Insert   
        bool InsertQTGroupParameterDetailReq(QTGroupParameterDetailReq QTGroupParameterDetailReq);
        //Update
        bool UpdateQTGroupParameterDetailResp(QTGroupParameterDetailResp QTGroupParameterDetailResp);
        //Delete
        bool DeleteQTGroupParameterDetailResp(QTGroupParameterDetailResp QTGroupParameterDetailResp);

        //Insert   
        bool InsertQTParameterReq(QTParameterReq QTParameterReq);
        //Update
        bool UpdateQTParameterResp(QTParameterResp QTParameterResp);
        //Delete
        bool DeleteQTParameterResp(QTParameterResp QTParameterResp);

        //Insert   
        bool InsertQTTnCReq(QTTnCReq QTTnCReq);
        //Update
        bool UpdateQTTnCResp(QTTnCResp QTTnCResp);
        //Delete
        bool DeleteQTTnCResp(QTTnCResp QTTnCResp);
    }
}