﻿using MVCProject.Models.RequestModel;
using MVCProject.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.IRepositories
{
    public interface ITaxRepository
    {
        //INSERT   
        bool InsertTax(GetTaxEntryResp TaxEntryReq);
        //UPDATE
        bool UpdateTax(GetTaxEntryResp TaxEntryResp);
        //DELETE
        bool DeleteTax(GetTaxEntryResp TaxEntryResp);

        List<GetTaxEntryResp> GetAllTax();
    }
}