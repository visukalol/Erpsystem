﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.RequestModel
{
    public class VendorReq
    {
        public int vndM_Id { get; set; }
        public string vndM_CompanyName { get; set; }
        public string vndM_ContactPerson { get; set; }
        public string vndM_Address { get; set; }
        public string vndM_MobileNo { get; set; }
        public string vndM_ContactNumber1 { get; set; }
        public string vndM_ContactNumber2 { get; set; }
        public string vndM_Email { get; set; }
        public string vndM_Fax { get; set; }
        public string vndM_PAN { get; set; }
        public string vndM_CST { get; set; }
        public string vndM_VAT { get; set; }
        public string vndM_ECC { get; set; }
        public Nullable<bool> vndM_Type { get; set; }
        public string vndM_Code { get; set; }
        public string vLcM_City { get; set; }
        public string vLcM_State { get; set; }
        public string VendorContactPerson { get; set; }
        public string vndM_TAN { get; set; }
        public string vndM_CIN { get; set; }
    }

    public class VendorLocationReq
    {
        public int vLcM_Id { get; set; }
        public Nullable<int> vLcM_vndMId { get; set; }
        public string vLcM_Code { get; set; }
        public string vLcM_Address { get; set; }
        public string vLcM_City { get; set; }
        public string vLcM_Country { get; set; }
        public string vLcM_Zip { get; set; }
        public string vLcM_State { get; set; }
        public string vLcM_ECC { get; set; }
        public string vLcM_ER { get; set; }
        public string vLcM_CST { get; set; }
        public string vLcM_VAT { get; set; }
        public string vLcM_GSTiN { get; set; }
    }

    public class VendorLocationContactReq
    {
        public int vcntM_Id { get; set; }
        public string vcntM_ContactPerson { get; set; }
        public string vcntM_Mobile { get; set; }
        public string vcntM_Resi { get; set; }
        public string vcntM_eMail { get; set; }
        public string vcntM_Phone1 { get; set; }
        public string vcntM_Phone2 { get; set; }
        public string vcntM_FAX { get; set; }
        public Nullable<int> vcntM_vLcMId { get; set; }
    }

    public class GetVendorRawMaterialReq
    {
        public int vndM_Id { get; set; }
        public string vndM_Code { get; set; }
        public int cat3id { get; set; }
        public int cat2id { get; set; }
        public int cat1id { get; set; }
        public string cat3 { get; set; }
        public string cat2 { get; set; }
        public string cat1 { get; set; }
    }

    public class VendorBankMasterReq
    {
        public int vndM_Id { get; set; }
        public string bnkM_Name { get; set; }
        public string bnkM_Branch { get; set; }
        public string bnkM_IFSC { get; set; }
        public string bnkM_AcNo { get; set; }
        public string bnkM_AcName { get; set; }
        public string bnkM_MICR { get; set; }
        public int bnkM_Id { get; set; }
    }
}