﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.RequestModel
{
    public class TaxEntryReq
    {
        public int txM_Id { get; set; }
        public string txM_Code { get; set; }
        public string txM_TaxName { get; set; }
        public string txM_TaxDescription { get; set; }
        public bool txM_isPercentage { get; set; }
        public decimal txM_Amount { get; set; }
        public string txM_Parameters { get; set; }
        public bool txM_Active { get; set; }
        public string txM_FormName { get; set; }
        public string txM_TaxFormula { get; set; }
        public bool txM_isUnder { get; set; }
        public bool txM_isAgainst { get; set; }
        public string txM_Group { get; set; }
        public double txM_GroupIndex { get; set; }
    }

    public class FormnameReq
    {
        public int giM_Id { get; set; }
        public string giM_Name { get; set; }
        public int giM_itgMId { get; set; }
        public int giM_Type { get; set; }
    }
}