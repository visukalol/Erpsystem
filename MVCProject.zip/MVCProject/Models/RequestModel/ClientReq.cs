﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNet.SignalR;

namespace MVCProject.Models.RequestModel
{    
    public class ClientReq : PersistentConnection
    {
        public int clM_Id { get; set; }
        public string clM_Code { get; set; }
        public string clM_ContactPerson { get; set; }
        public string clM_CompanyName { get; set; }
        public string clM_Address { get; set; }
        public string clM_ContactNumber1 { get; set; }
        public string clM_ContactNumber2 { get; set; }
        public string clM_Email { get; set; }
        public string clM_Fax { get; set; }
        public string clM_PAN { get; set; }
        public string clM_CST { get; set; }
        public string clM_VAT { get; set; }
        public string clM_CreditLimit { get; set; }
        public string clM_Active { get; set; }
        public string clM_TAN { get; set; }
        public string clM_CIN { get; set; }

        protected override Task OnConnected(IRequest request, string connectionId)
        {
            return Connection.Send(connectionId, "Welcome!");
        }

        protected override Task OnReceived(IRequest request, string connectionId, string data)
        {
            return Connection.Broadcast(data);
        }
    }

    public class ClientBankMasterReq
    {
        public int clM_Id { get; set; }
        public string bnkM_Name { get; set; }
        public string bnkM_Branch { get; set; }
        public string bnkM_IFSC { get; set; }
        public string bnkM_AcNo { get; set; }
        public string bnkM_AcName { get; set; }
        public string bnkM_MICR { get; set; }
        public int bnkM_Id { get; set; }
    }
}