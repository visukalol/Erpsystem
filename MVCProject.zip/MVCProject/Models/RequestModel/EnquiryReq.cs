﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.RequestModel
{
    public class EnquiryReq
    {
        public int enqM_Id { get; set; }
        public int enqM_clMId { get; set; }
        public string enqM_RegNo { get; set; }
        public DateTime enqM_RegDate { get; set; }
        public string enqM_TenderNo { get; set; }
        public DateTime enqM_TenderDate { get; set; }
        public DateTime enqM_ClosingDate { get; set; }
        public string enqM_Detail { get; set; }
        public Decimal enqM_MOR { get; set; }
        public Decimal enqM_stsMId { get; set; }
        public Decimal enqM_Value { get; set; }
        public Decimal enqM_lcMId { get; set; }
        public Decimal enqM_cntMId { get; set; }
        public Decimal enqM_dsgMId { get; set; }
        public Decimal enqM_ActId { get; set; }
        public Decimal enqM_stfMId { get; set; }
        public string enqM_ProjectName { get; set; }
        public int enqM_YrMId { get; set; }
    }

    public class EnquiryActivityInfoReq
    {
        public int Act_enqMId { get; set; }
        public int Act_StfMId { get; set; }
        public int Act_StaffMIdAssign { get; set; }
        public string Act_dstMIdDivert { get; set; }
        public string Status { get; set; }
        public string Act_Remarks { get; set; }
        public string Act_RegretNos { get; set; }
        public string Act_RegretRemark { get; set; }
        public int Act_yrMId { get; set; }
    }

    public class DesignationReq
    {
        public int giM_Id { get; set; }
        public string giM_Name { get; set; }
        public int giM_Type { get; set; }
        public int giM_itgMId { get; set; }
    }

    public class EnquiryAssignInfoReq
    {
        public int enqA_Id { get; set; }
        public string enqA_RegNo { get; set; }
        public string enqA_DepartmentName { get; set; }
        public string enqA_StaffName { get; set; }
        public string enqA_Address { get; set; }
        public string enqA_Instructions { get; set; }
        
    }

    public class EnquiryDivertInfoReq
    {
        public int enqD_Id { get; set; }
        public string enqD_RegNo { get; set; }
        public string enqD_Distributor { get; set; }
        public string enqD_Comments { get; set; }
    }

    public class EnquiryRegretInfoReq
    {
        public int enqR_Id { get; set; }
        public string enqR_RegNo { get; set; }
        public string enqR_Remarks { get; set; }
        public string enqR_Reason { get; set; }
    }
}
