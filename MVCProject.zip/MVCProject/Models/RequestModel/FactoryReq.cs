﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.RequestModel
{
    public class FactoryReq
    {
        public int gfM_Id { get; set; }
        public string gfM_Code { get; set; }
        public string gfM_Location { get; set; }
        public string gfM_Address { get; set; }
        public string gfM_Type { get; set; }
        public string gfM_ContactPerson { get; set; }
        public string gfM_ContactNumber1 { get; set; }
        public string gfM_ContactNumber2 { get; set; }
        public string gfM_eMail { get; set; }
        public string gfM_MobileNo { get; set; }
        public string gfM_FAX { get; set; }
        public int outMasterId { get; set; }
        public string gfM_TAN { get; set; }
        public string gfM_VAT { get; set; }
        public string gfM_GST { get; set; }
        public string gfM_CIN { get; set; }
        public string gfM_City { get; set; }
        public string gfM_State { get; set; }
        public string gfM_Region { get; set; }
        public string gfM_Pincode { get; set; }
    }

    public class GodownReq
    {
        public int gfM_Id { get; set; }
        public string gfM_Code { get; set; }
        public string gfM_Location { get; set; }
        public string gfM_Address { get; set; }
        public string gfM_Type { get; set; }
        public string gfM_ContactPerson { get; set; }
        public string gfM_ContactNumber1 { get; set; }
        public string gfM_ContactNumber2 { get; set; }
        public string gfM_eMail { get; set; }
        public string gfM_MobileNo { get; set; }
        public string gfM_FAX { get; set; }
        public int outMasterId { get; set; }
        public string gfM_TAN { get; set; }
        public string gfM_VAT { get; set; }
        public string gfM_GST { get; set; }
        public string gfM_CIN { get; set; }
        public string gfM_City { get; set; }
        public string gfM_State { get; set; }
        public string gfM_Region { get; set; }
        public string gfM_Pincode { get; set; }
    }

    public class CertificateReq
    {
        public int crtD_Id { get; set; }
        public int crtD_itgMId { get; set; }
        public string crtD_No { get; set; }
        public string crtD_Description { get; set; }
        public string crtD_CCENo { get; set; }
        public string crtD_DGMSNo { get; set; }
    }

    
}