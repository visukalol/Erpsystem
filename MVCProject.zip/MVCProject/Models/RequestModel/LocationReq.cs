﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.RequestModel
{
    public class LocationReq
    {
        public int LcM_Id { get; set; }
        public int LcM_clMId { get; set; }
        public string LcM_Code { get; set; }
        public string LcM_Address { get; set; }
        public string LcM_City { get; set; }
        public string LcM_Country { get; set; }
        public string LcM_Zip { get; set; }
        public string LcM_State { get; set; }
        public string LcM_ECC { get; set; }
        public string LcM_ER { get; set; }
        public string LcM_CST { get; set; }
        public string LcM_VAT { get; set; }
        public string LcM_GSTiN { get; set; }
        public string LCM_Flag { get; set; }
    }
}