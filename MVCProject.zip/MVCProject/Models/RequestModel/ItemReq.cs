﻿namespace MVCProject.Models.RequestModel
{
    public class ItemReq
    {
        public int itM_Id { get; set; }
        public string itM_ItemName { get; set; }
        public string itM_ItemDescriptionEnquiry { get; set; }
        public string itM_ItemDescriptionWorkOrder { get; set; }
        public string itM_ItemDescriptionInvoice { get; set; }
        public string itM_Code { get; set; }
        public int itM_crtDId { get; set; }
        public int itM_itgMId { get; set; }
        public int itM_CatMId { get; set; }
        public int itM_giMId { get; set; }
        public int itm_HSNCode { get; set; }
    }
}