﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.RequestModel
{
    public class CategoryReq
    {
        //public int CategoryId { get; set; }
        //public string CategoryCode { get; set; }
        //public string CategoryName { get; set; }
        //public string Description { get; set; }

        public int catM_Id { get; set; }
        public string catM_Name { get; set; }
        public string catM_Description { get; set; }
        public string catM_Code { get; set; }
    }


}