﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.RequestModel
{    
    public class DistributorReq : PersistentConnection
    {
        public int dstM_Id { get; set; }
        public string dstM_CompanyName { get; set; }
        public string dstM_ContactPerson { get; set; }        
        public string dstM_Address { get; set; }
        public string dstM_MobileNo { get; set; }
        public string dstM_ContactNumber1 { get; set; }
        public string dstM_ContactNumber2 { get; set; }
        public string dstM_Email { get; set; }
        public string dstM_Fax { get; set; }
        public string dstM_PAN { get; set; }
        public string dstM_CST { get; set; }
        public string dstM_VAT { get; set; }
        public Boolean dstM_Type { get; set; }
        public string dstM_GSTiN { get; set; }

        public string dstM_TAN { get; set; }
        public string dstM_CIN { get; set; }
        public string dstM_City { get; set; }
        public string dstM_State { get; set; }
        public string dstM_Region { get; set; }
        public string dstM_Pincode { get; set; }

        protected override Task OnConnected(IRequest request, string connectionId)
        {
            return Connection.Send(connectionId, "Welcome!");
        }

        protected override Task OnReceived(IRequest request, string connectionId, string data)
        {
            return Connection.Broadcast(data);
        }
    }
}