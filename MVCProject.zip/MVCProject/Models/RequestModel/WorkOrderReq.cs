﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.RequestModel
{
    public class WorkOrderInfoReq
    {
        public int woM_Id { get; set; }
        public string woM_No { get; set; }
        public DateTime woM_Date { get; set; }
        public string woM_PONo { get; set; }
        public DateTime woM_PODate { get; set; }
        public int woM_RevNo { get; set; }
        public string woM_QtnNo { get; set; }
        public DateTime woM_QtnDate { get; set; }
        public Decimal woM_Amount { get; set; }
        public DateTime woM_DeliveryDate { get; set; }
        public int woM_ClMId { get; set; }
        public int woM_LcMId { get; set; }
        public int woM_ConsigneeId { get; set; }
        public int woM_ConsigneelcMId { get; set; }
        public string woM_CurrencyName { get; set; }
        public int woM_woActId { get; set; }
        public string woM_DespatchMode { get; set; }
        public string woM_AgentName { get; set; }
        public Decimal woM_AgentPercentage { get; set; }
        public int woM_stsMId { get; set; }
        public string woM_Remarks { get; set; }
        public int woM_stfMId { get; set; }
        public string woM_AccountOf { get; set; }
        public string woM_TransportName { get; set; }
        public int woM_unitMId { get; set; }
        public int woM_WeekNo { get; set; }
        public int @woM_yrMId { get; set; }
        public int @woM_qtMId { get; set; }
    }

    public class WorkOrderDetailInfoReq
    {
        public int woD_woMId { get; set; }
        public int woD_itMId { get; set; }
        public decimal woD_Quantity { get; set; }
        public decimal woD_Rate { get; set; }
        public decimal woD_Amount { get; set; }
        public string woD_ItemDescriptionWorkOrder { get; set; }
        public int woD_ItemRank { get; set; }
    }

    public class WorkOrderDetailTaxInfoReq
    {
        public int wotxD_woDId { get; set; }
        public int wotxD_woMId { get; set; }
        public int wotxD_txMId { get; set; }
        public decimal wotxD_Percentage { get; set; }
        public decimal wotxD_Amount { get; set; }
    }

    public class workOrderTnCInfoReq
    {
        public int @TncWO_WOMId { get; set; }
        public int @TncWO_TncMId { get; set; }
        public string @TncWO_Description { get; set; }
    }
}