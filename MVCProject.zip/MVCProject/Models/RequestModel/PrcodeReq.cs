﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.RequestModel
{
    public class PrcodeReq
    {
        public int Id { get; set; }
        public string prcode { get; set; }
        public string qty { get; set; }
        public string qta_id { get; set; }
    }
}