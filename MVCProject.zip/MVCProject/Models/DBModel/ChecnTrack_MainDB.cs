﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MVCProject.Models.DBModel
{
    public class ChecnTrack_MainDB : DbContext
    {
        public ChecnTrack_MainDB() : base("ChecnTrack_MainDB") { }
    }
}