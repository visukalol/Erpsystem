﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MVCProject.Models.DBModel
{
    public class DBContent : DbContext
    {
        public DBContent() : base("DBContent") { }
        public DbSet<aspnet_Users> aspnet_Users { get; set; }
    }
}