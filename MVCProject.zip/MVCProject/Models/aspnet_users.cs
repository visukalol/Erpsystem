﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCProject.Models
{
    public class aspnet_Users
    {
        [Key]
        public Guid ApplicationId { get; set; }
        public string UserName { get; set; }
    }
}