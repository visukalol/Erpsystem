﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class InvoiceInfoResp
    {
        public int? InvM_Id { get; set; }
        public string invM_No { get; set; }
        public DateTime invM_Date { get; set; }
        public decimal invM_GrossAmount { get; set; }
        public decimal invM_Amount { get; set; }
        public int? invM_WOMId { get; set; }
        public int? invM_ClMId { get; set; }
        public int? invM_LcMId { get; set; }
        public int? invM_ConsigneeId { get; set; }
        public int? invM_ConsigneeLcMId { get; set; }
        public string invM_CurrencyName { get; set; }
        public string invM_ChallanNo { get; set; }
        public string invM_OrderNo { get; set; }
        public string invM_WONo { get; set; }
        public DateTime invM_RemovalDate { get; set; }
        public string invM_DespatchMode { get; set; }
        public string invM_VehicleNo { get; set; }
        public string invM_ExcisableCommodity { get; set; }
        public string invM_TariffNo { get; set; }
        public DateTime invM_ChallanDate { get; set; }
        public DateTime invM_WorkOrderDate { get; set; }
        public DateTime invM_OrderDate { get; set; }
        public int? invM_stfMId { get; set; }
        //public int invM_yrMId { get; set; }
        public decimal invM_AdvanceAmount { get; set; }
        public string invM_Remarks { get; set; }
        //[Column("invM_DespatchDetail")]
        public string invM_DespatchDetail { get; set; }
        //[Column("invM_DespatchDate")]
        public DateTime invM_DespatchDate { get; set; }
        public string invM_PaymentMode { get; set; }
        public decimal invM_FinalAmount { get; set; }
        public int invM_lcnMId { get; set; }
        //public bool invM_Rchrg { get; set; }
        public char invM_invTyp { get; set; }
        public int? invM_bnkMId { get; set; }
        public int? invM_placeofsupply { get; set; }
        public string clM_CompanyName { get; set; }
    }

    public class InvoiceDetailInfoResp
    {
        public int invD_Id { get; set; }
        public int invD_invMId { get; set; }
        public int invD_itMId { get; set; }
        public string invD_DetailDescription { get; set; }
        public decimal invD_Quantity { get; set; }
        public decimal invD_Rate { get; set; }
        public decimal invD_Amount { get; set; }
        public string invD_ItemDescriptionInvoice { get; set; }
        public string invD_ItemRank { get; set; }
        public decimal invD_PackingAndForwarding { get; set; }
        public decimal invD_Excise { get; set; }
        public decimal invD_ADSPExcise { get; set; }
        public decimal invD_HADSPExcise { get; set; }
        public int invD_Pkgs { get; set; }
        public int invD_AvgContent { get; set; }
        public decimal invD_PackingAndForwardingAmount { get; set; }
        public decimal invD_ExciseAmount { get; set; }
        public decimal invD_ADSPExciseAmount { get; set; }
        public decimal invD_HADSPExciseAmount { get; set; }
        public int invD_HSNSACId { get; set; }
        public int invD_IGSTId { get; set; }
        public decimal invD_Freight { get; set; }
        public decimal invD_IGSTRate { get; set; }
        public decimal invD_IGSTAmount { get; set; }
        public int invD_CGSTId { get; set; }
        public decimal invD_CGSTRate { get; set; }
        public decimal invD_CGSTAmount { get; set; }
        public int invD_SGSTId { get; set; }
        public decimal invD_SGSTRate { get; set; }
        public decimal invD_SGSTAmount { get; set; }
        public decimal invD_NettAmount { get; set; }
        public int invD_wodId { get; set; }
        public int invD_woMId { get; set; }
    }

    public class InvoiceDetailTaxInfoResp
    {
        public int invtxD_Id { get; set; }
        public int invtxD_invDId { get; set; }
        public int invtxD_invMId { get; set; }
        public int invtxD_txMId { get; set; }
        public decimal invtxD_Percentage { get; set; }
        public decimal invtxD_Amount { get; set; }
        public int invtxD_CGSTId { get; set; }
        public decimal invtxD_CGSTRate { get; set; }
        public decimal invtxD_CGSTAmount { get; set; }
        public int invtxD_SGSTId { get; set; }
        public int invtxD_SGSTRate { get; set; }
        public int invtxD_SGSTAmount { get; set; }
        public int invtxD_IGSTId { get; set; }
        public decimal invtxD_IGSTRate { get; set; }
        public decimal invtxD_IGSTAmount { get; set; }
    }
}