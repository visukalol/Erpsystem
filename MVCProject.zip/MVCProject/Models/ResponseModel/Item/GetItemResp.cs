﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class GetItemResp
    {
        public int itM_ID { get; set; }    
        public string itM_ItemName { get; set; }
        public string itM_ItemDescriptionEnquiry { get; set; }
        public string itM_ItemDescriptionWorkOrder { get; set; }
        public string itM_ItemDescriptionInvoice { get; set; }
        public string itM_Code { get; set; }
        public int itM_crtDId { get; set; }
        public int itM_itgMId { get; set; }
        public int itM_CatMId { get; set; }
        public int itM_giMId { get; set; }
        public int itm_HSNCode { get; set; }
        public string crtD_No { get; set; }
        public string crtD_Description { get; set; }
        public string crtD_CCENo { get; set; }
        public string crtD_DGMSNo { get; set; }
    }

    public class GetItemGroupResp
    {
        public int itgM_Id { get; set; }
        public string itgM_Name { get; set; }
        public string itgM_ShowCols { get; set; }
        public int itgM_catMId { get; set; }
    }
}