﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class GetRawMaterialResp
    {
        public int rawM_Id { get; set; }
        public string rawM_Code { get; set; }
        public string rawM_Name { get; set; }
        public string rawM_Description { get; set; }
        public int rawM_catMId { get; set; }
        public string rawM_Make { get; set; }
        public string rawM_Unit { get; set; }
        public string rawM_PricingMethod { get; set; }
        public decimal rawM_ReorderLevel { get; set; }
        public decimal rawM_OpQty { get; set; }
        public decimal rawM_QtyIn { get; set; }
        public double rawM_QtyOut { get; set; }
    }

    public class GetRawCategoryInfoResp
    {
        public int rawC_Id { get; set; }
        public string rawC_Name { get; set; }
        public int rawC_ParentId { get; set; }
        public string rawC_Code { get; set; }
    }
    public class GetRawCategoryResp
    {
        public int raw_Id { get; set; }
        public string raw_Cat1 { get; set; }
        public string raw_Cat2 { get; set; }
        public string raw_Cat3 { get; set; }
        public string raw_Cat4 { get; set; }
    }

    public class PricingMethod
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }


}

