﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel.Location
{
    public class LocationResp
    {
        public int LcM_Id { get; set; }
        public int LcM_clMId { get; set; }
        public string LcM_Code { get; set; }
        public string LcM_Address { get; set; }
        public string LcM_City { get; set; }
        public string LcM_Country { get; set; }
        public string LcM_Zip { get; set; }
        public string LcM_State { get; set; }
        public string LcM_ECC { get; set; }
        public string LcM_ER { get; set; }
        public string LcM_CST { get; set; }
        public string LcM_VAT { get; set; }
        public string LcM_GSTiN { get; set; }
        public string LCM_Flag { get; set; }
        //for company master only
        public string LcnM_Range { get; set; }
        public string LcnM_Division { get; set; }
        public string LcnM_Commissionerate { get; set; }
        public string LcnM_LocationName { get; set; }
        public string LcnM_ST { get; set; }
    }

    public class LocationContactsResp
    {
        public int vcntM_Id { get; set; }
        public int vcntM_vLcMId { get; set; }
        public string vcntM_ContactPerson { get; set; }
        public string vcntM_Mobile { get; set; }
        public string vcntM_Resi { get; set; }
        public string vcntM_eMail { get; set; }
        public string vcntM_Phone1 { get; set; }
        public string vcntM_Phone2 { get; set; }
        public string vcntM_FAX { get; set; }
        public string vcntM_Flag { get; set; }
    }
}