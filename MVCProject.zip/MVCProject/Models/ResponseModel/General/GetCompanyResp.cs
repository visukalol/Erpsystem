﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class GetCompanyResp
    {
        public string cmpM_CompanyName { get; set; }
        public string cmpM_ContactPerson { get; set; }
        public string cmpM_Address { get; set; }
        public string cmpM_MobileNo { get; set; }
        public string cmpM_ContactNumber1 { get; set; }
        public string cmpM_ContactNumber2 { get; set; }
        public string cmpM_Email { get; set; }
        public string cmpM_Fax { get; set; }
        public string cmpM_PAN { get; set; }
        public string cmpM_CST { get; set; }
        public string cmpM_VAT { get; set; }
        public string cmpM_GST { get; set; }
        public int? cmpM_Id { get; set; }
        //public byte[] cmpM_picLeft { get; set; }
        //public byte[] cmpM_picCenter { get; set; }
        //public byte[] cmpM_picRight { get; set; }
        public string cmpM_ReportHeading { get; set; }
        public string cmpM_ReportSubHeading { get; set; }
        public DateTime? yrM_DateFrom { get; set; }
        public DateTime? yrM_DateTo { get; set; }
        public bool? yrM_Current { get; set; }
        public int? yrM_cmpMId { get; set; }
        public string yrM_Name { get; set; }
        public string cmpM_Acronym { get; set; }
        //new column addition
        public string cmpM_TAN { get; set; }
        public string cmpM_CIN { get; set; }
        public string cmpM_TEC { get; set; }
        //new column addition
    }

    public class GetCompanyLocationResp
    {
        public int lcnM_Id { get; set; }
        public Nullable<int> lcnM_cmpMId { get; set; }
        public string lcnM_LocationName { get; set; }
        public string lcnM_Address { get; set; }
        public string lcnM_CST { get; set; }
        public string lcnM_VAT { get; set; }
        public string lcnM_ECC { get; set; }
        public string lcnM_ST { get; set; }
        public string lcnM_Range { get; set; }
        public string lcnM_Division { get; set; }
        public string lcnM_Commissionerate { get; set; }
        public string lcnM_PAN { get; set; }
        public string lcnM_GSTiN { get; set; }
    }

}