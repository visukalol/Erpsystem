﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class GetCategoryResp
    {
        public int catM_Id { get; set; }
        public string catM_Name { get; set; }
        public string catM_Description { get; set; }
        public string catM_Code { get; set; }
    }
}