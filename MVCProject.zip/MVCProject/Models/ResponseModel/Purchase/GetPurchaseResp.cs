﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class PurchaseInfoResp
    {
        public int? poM_Id { get; set; }
        public DateTime poM_Date { get; set; }
        public string poM_No { get; set; }
        public int? poM_VendorId { get; set; }
        public int? poM_stsMId { get; set; }
        public int? poM_stfMId { get; set; }
        public int? poM_Approvedby { get; set; }
        public string poM_Remarks { get; set; }
        public int? poM_yrMId { get; set; }
        public string poM_ChallanNo { get; set; }
        public DateTime poM_ChallanDate { get; set; }
        public int? poM_EstMId { get; set; }
        public int? poM_RFQId { get; set; }
        public decimal poM_Amount { get; set; }
        public decimal poM_FinalAmount { get; set; }
        public int? poM_lcnMId { get; set; }
        public DateTime poM_DeliveryDate { get; set; }
        public int? poM_vLcMId { get; set; }
        public string vndM_ContactPerson { get; set; }
    }

    public class PurchaseDetailInfoResp
    {
        public int poD_Id { get; set; }
        public int pod_poMId { get; set; }
        public int poD_rawMId { get; set; }
        public Decimal poD_Quantity { get; set; }
        public Decimal poD_Rate { get; set; }
        public Decimal poD_Amount { get; set; }
        public string poD_DetailDescription { get; set; }
        public int poD_ItemRank { get; set; }

    }

    public class PurchaseTaxDetailInfoResp
    {
        public int txD_Id { get; set; }
        public int txD_PODId { get; set; }
        public int txD_POMId { get; set; }
        public int txD_txMId { get; set; }
        public Decimal txD_Percentage { get; set; }
        public decimal txD_Amount { get; set; }
        public string txD_FormName { get; set; }
    }

    public class PurchaseTnCInfoResp
    {
        public int TncPO_Id { get; set; }
        public int tncPO_POMId { get; set; }
        public int tncPO_TncMId { get; set; }
        public string tncPO_Description { get; set; }
    }
}