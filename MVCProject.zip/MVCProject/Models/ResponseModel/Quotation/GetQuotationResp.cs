﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class QTHeaderResp
    {
        public int qtM_Id { get; set; }
        public string qtM_No { get; set; }
        public int qtM_enqMId { get; set; }
        public int qtM_RevNo { get; set; }
        public DateTime qtM_Date { get; set; }
        public decimal qtM_Amount { get; set; }
        public int qtM_stfMId { get; set; }
        public string status { get; set; }
        public bool qtM_Type { get; set; }
        public string qtM_CurrencyName { get; set; }
        public string qtM_StandardDeviation { get; set; }
        public int qtM_yrMId { get; set; }
        public int ccD_clMId1 { get; set; }
        public int ccD_lcMId1 { get; set; }
        public int ccD_cntMId1 { get; set; }
        public int ccD_dsgMId1 { get; set; }
        public int ccD_clMId2 { get; set; }
        public int ccD_lcMId2 { get; set; }
        public int ccD_cntMId2 { get; set; }
        public int ccD_dsgMId2 { get; set; }
        // ObjectParameter ccD_Id,
        //ObjectParameter outQuotationId
        public DateTime enqM_RegDate { get; set; }
        public string enqM_TenderNo { get; set; }
        public DateTime enqM_TenderDate { get; set; }
        public string enqM_ProjectName { get; set; }
        public DateTime enqM_ClosingDate { get; set; }
        //public int clM_Id { get; set; }
        //public string clM_Code { get; set; }
        public string enqMNo { get; set; }
        public string stfM_Name { get; set; }
        public string cmpM_CompanyName { get; set; }
        public string qtM_Description { get; set; }
        public int Id { get; set; }
        public string prcode { get; set; }
        public string qty { get; set; }
        public string qta_id { get; set; }
    }

    public class QTDetailResp
    {
        public int qtD_Id { get; set; }
        public int qtD_qtMId { get; set; }
        public int qtD_itMId { get; set; }
        public int qtgC_ItgMId { get; set; }
        public int qtgC_crtDId { get; set; }
        public string qtD_DetailDescription { get; set; }
        public string qtD_ItemDescriptionEnquiry { get; set; }
        public string qtgC_CertificateDescription { get; set; }
        public decimal qtD_Quantity { get; set; }
        public decimal qtD_Rate { get; set; }
        public decimal qtD_Amount { get; set; }
        public int qtD_ItemRank { get; set; }
    }

    public class QTActivityResp
    {
        public int qAct_qtMId { get; set; }
        public int enquiryId { get; set; }
        public int qAct_StfMId { get; set; }
        public int qAct_StaffMIdAssign { get; set; }
        public string qStatus { get; set; }
        public string qAct_Remarks { get; set; }
        public int qAct_yrMId { get; set; }
        //ObjectParameter qAct_Id
    }

    public class QTGroupCertificateResp
    {
        public int qtgC_qtGId { get; set; }
        public int qtgC_ItgMId { get; set; }
        public int qtgC_crtDId { get; set; }
        public int qtgC_Amount { get; set; }
    }

    public class QTGroupDetailResp
    {
        public int qtgD_qtgCId { get; set; }
        public int qtgD_qtgId { get; set; }
        public int qtgD_itMId { get; set; }
        public string qtgD_DetailDescription { get; set; }
        public string qtgD_DetailParticulars { get; set; }
        public decimal qtgD_Quantity { get; set; }
        public decimal qtgD_Rate { get; set; }
        public decimal qtgD_Amount { get; set; }
    }

    public class QTGroupItemParameterResp
    {
        public int qtgP_qtgDId { get; set; }
        public string qtgP_Description { get; set; }
        public int qtgP_qtGId { get; set; }
        public int qtgP_itDId { get; set; }
    }

    public class QTGroupParameterDetailResp
    {
        public int qtgPd_qtgPId { get; set; }
        public int qtgPd_qtgDId { get; set; }
        public string qtgPd_Description { get; set; }
        public string qtgPd_Make { get; set; }
        public string qtgPd_No { get; set; }
        public int qtgPd_qtMId { get; set; }
    }

    public class QTParameterResp
    {
        public int qtP_QtDId { get; set; }
        public int qtP_QtMId { get; set; }
        public string qtP_DetailName { get; set; }
        public string qtP_Description { get; set; }
        public int qtP_qtPId { get; set; }
        public int qtP_Rank { get; set; }
        public int qtP_ParentQtPId { get; set; }
    }

    public class QTTnCResp
    {
        public int tncQ_QtMId { get; set; }
        public int tncQ_TncMId { get; set; }
        public int tncQ_TncDId { get; set; }
        public bool tnCQ_Type { get; set; }
        public string tnCQ_Description { get; set; }
    }

    public class PrcodeResp
    {
        public int Id { get; set; }
        public string prcode { get; set; }
        public string qty { get; set; }
        public string qta_id { get; set; }
    }
}