﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class QuotationResp
    {
        public int MyProperty { get; set; }
    }
}