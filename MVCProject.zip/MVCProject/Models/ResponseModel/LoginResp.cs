﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class LoginResp
    {
        public bool stfM_isActive { get; set; }

        public string RoleName { get; set; }
    }
}