﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class GetClientResp
    {
        public int clM_Id { get; set; }
        public string clM_Code { get; set; }
        public string clM_ContactPerson { get; set; }
        public string clM_CompanyName { get; set; }
        public string clM_Address { get; set; }
        public string clM_ContactNumber1 { get; set; }
        public string clM_ContactNumber2 { get; set; }
        public string clM_Email { get; set; }
        public string clM_Fax { get; set; }
        public string clM_PAN { get; set; }
        public string clM_CST { get; set; }
        public string clM_VAT { get; set; }
        public string clM_Creditlimit { get; set; }
        public bool clM_Active { get; set; }
        public string LcM_city { get; set; }
        public string LcM_State { get; set; }
        public string ClientContactPerson { get; set; }
        public string clM_TAN { get; set; }
        public string clM_CIN { get; set; }
    }   

    public class GetClientLocationResp
    {
        public int LcM_Id { get; set; }
        public int LcM_clMId { get; set; }
        public string LcM_Code { get; set; }
        public string LcM_Address { get; set; }
        public string LcM_City { get; set; }
        public string LcM_Country { get; set; }
        public string LcM_Zip { get; set; }
        public string LcM_State { get; set; }
        public string LcM_ECC { get; set; }
        public string LcM_ER { get; set; }
        public string LcM_CST { get; set; }
        public string LcM_VAT { get; set; }
        public string LcM_GSTiN { get; set; }

        public string LcnM_Range { get; set; }
        public string LcnM_Division { get; set; }
        public string LcnM_Commissionerate { get; set; }
        public string LcnM_LocationName { get; set; }
        public string LcnM_ST { get; set; }
    }


    public class GetClientContactsResp
    {
        public int cntM_Id { get; set; }
        public int cntM_vLcMId { get; set; }
        public string cntM_ContactPerson { get; set; }
        public string cntM_Mobile { get; set; }
        public string cntM_Resi { get; set; }
        public string cntM_eMail { get; set; }
        public string cntM_Phone1 { get; set; }
        public string cntM_Phone2 { get; set; }
        public string cntM_FAX { get; set; }
        public string cntM_Flag { get; set; }
    }

    public class ClientBankMasterResp
    {
        public int clM_Id { get; set; }
        public string bnkM_Name { get; set; }
        public string bnkM_Branch { get; set; }
        public string bnkM_IFSC { get; set; }
        public string bnkM_AcNo { get; set; }
        public string bnkM_AcName { get; set; }
        public string bnkM_MICR { get; set; }
        public int bnkM_Id { get; set; }
        public string bnkM_Flag { get; set; }
    }
}