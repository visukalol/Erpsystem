﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class WorkOrderInfoResp
    {
        public string stfM_Designation { get; set; }
        public string stfM_DepartmentName { get; set; }
        public string stfM_Email { get; set; }
        public string stfM_ContactNumber2 { get; set; }
        public string stfM_ContactNumber1 { get; set; }
        public string stfM_Address { get; set; }
        public string AssignedTo { get; set; }
        public string stfM_Initials { get; set; }
        public string LcM_Address { get; set; }
        public string LcM_City { get; set; }
        public string LcM_Country { get; set; }
        public string LcM_State { get; set; }
        public string LcM_Zip { get; set; }
        public string LcM_Code { get; set; }
        public string LcM_ECC { get; set; }
        public string LcM_ER { get; set; }
        public string LcM_CST { get; set; }
        public string LcM_VAT { get; set; }
        public string clM_CompanyName { get; set; }
        public string clM_Code { get; set; }
        public string ConsigneeName { get; set; }
        public string ConsigneeLocationCode { get; set; }
        public string consAdd { get; set; }
        public string consCity { get; set; }
        public string consCountry { get; set; }
        public string consZip { get; set; }
        public string consState { get; set; }
        public string consECC { get; set; }
        public string consER { get; set; }
        public string consCST { get; set; }
        public string consVAT { get; set; }
        public long? woMNo { get; set; }
        public int? woM_Id { get; set; }
        public string woM_No { get; set; }
        public DateTime woM_Date { get; set; }
        public string woM_PONo { get; set; }
        public DateTime woM_PODate { get; set; }
        public int? woM_RevNo { get; set; }
        public decimal woM_Amount { get; set; }
        public DateTime woM_DeliveryDate { get; set; }
        public int? woM_ClMId { get; set; }
        public int? woM_LcMId { get; set; }
        public int? woM_ConsigneeId { get; set; }
        public int? woM_ConsigneelcMId { get; set; }
        public char woM_CurrencyName { get; set; }
        public int? woM_woActId { get; set; }
        public string woM_DespatchMode { get; set; }
        public string woM_AgentName { get; set; }
        public decimal woM_AgentPercentage { get; set; }
        public int? woM_stsMId { get; set; }
        public string woM_Remarks { get; set; }
        public int? woM_stfMId { get; set; }
        public byte woM_yrMId { get; set; }
        public string woM_AccountOf { get; set; }
        public string woM_TransportName { get; set; }
        public string clM_PAN { get; set; }
        public string consPAN { get; set; }
        public int? woM_unitMId { get; set; }
        public short woM_weekNo { get; set; }
        public int? woM_qtMId { get; set; }
        public string woM_QuotationNo { get; set; }
        public DateTime woM_QuotationDate { get; set; }
        //public string woM_QtnNo { get; set; }
        //public DateTime woM_QtnDate { get; set; }
        public string clM_CreditLimit { get; set; }
        public string lcnM_LocationName { get; set; }
        public int? clM_Id { get; set; }

        public string unit_name { get; set; }
        public string giM_Name { get; set; }

        public int? Id { get; set; }
        public int? giM_Id { get; set; }
        //public int? unit_Id { get; set; }
    }

    public class WorkOrderDetailInfoResp
    {
        public int woD_Id { get; set; }
        public int woD_woMId { get; set; }
        public int woD_itMId { get; set; }
        public decimal woD_Quantity { get; set; }
        public decimal woD_Rate { get; set; }
        public decimal woD_Amount { get; set; }
        public string woD_ItemDescriptionWorkOrder { get; set; }
        public string itM_ItemName { get; set; }
        public int woD_ItemRank { get; set; }
        public string woDIds { get; set; }
        public int woDwoMId { get; set; }
    }

    public class WorkOrderDetailTaxInfoResp
    {
        public int wotxD_Id { get; set; }
        public int wotxD_woDId { get; set; }
        public int wotxD_woMId { get; set; }
        public int wotxD_txMId { get; set; }
        public decimal wotxD_Percentage { get; set; }
        public decimal wotxD_Amount { get; set; }
        public string txM_Code { get; set;}
    }

    public class workOrderTnCInfoResp
    {        
        public int TncWO_Id { get; set; }
        public int TncWO_WOMId { get; set; }                   
        public int TncWO_TncMId { get; set; }
        public string TncWO_Description { get; set; }
        public string tncM_Text { get; set; }

    }

}