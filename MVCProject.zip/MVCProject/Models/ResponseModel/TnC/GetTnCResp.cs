﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class TnCMasterResp
    {
        public int tncM_Id { get; set; }
        public string tncM_Text { get; set; }
        public bool tncM_isDefault { get; set; }
    }

    public class TnCDescriptionInfoResp
    {
        public int tncM_Id { get; set; }
        public int tncD_Id { get; set; }
        public int tncD_tncMId { get; set; }
        public string tncD_Description { get; set; }
        public bool tncD_isDefault { get; set; }
    }
}