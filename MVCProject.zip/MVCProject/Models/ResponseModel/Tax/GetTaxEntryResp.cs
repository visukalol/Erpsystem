﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVCProject.Models.ResponseModel
{
    public class GetTaxEntryResp
    {
        public int txM_Id { get; set; }
        public string txM_Code { get; set; }
        public string txM_TaxName { get; set; }
        public string txM_TaxDescription { get; set; }
        public bool txM_isPercentage { get; set; }
        public decimal txM_Amount { get; set; }
        public string txM_Parameters { get; set; }
        public bool txM_Active { get; set; }
        public string txM_FormName { get; set; }
        public string txM_TaxFormula { get; set; }
        [Display(Name = "Under")]
        public bool txM_isUnder { get; set; }
        [Display(Name = "Against")]
        public bool txM_isAgainst { get; set; }        
        public string txM_Group { get; set; }
        public Int16 txM_GroupIndex { get; set; }
    }

    public class FormnameResp
    {
        public int giM_Id { get; set; }
        public string giM_Name { get; set; }
        public int giM_itgMId { get; set; }
        public int giM_Type { get; set; }
    }

    public class GetTaxDetailResp
    {
        public int txD_ID { get; set; }
        public string txD_FormName { get; set; }
    }
}