﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;


namespace MVCProject.Models.ResponseModel
{
    public class GetStaffResp
    {
        public int? stfM_Id { get; set; }
        public bool stfM_IsActive { get; set; }
        public string stfM_Name { get; set; }
        public bool stfM_Gender { get; set; }
        public DateTime stfM_DOB { get; set; }
        public string stfM_Address { get; set; }
        public string stfM_ContactNumber1 { get; set; }
        public string stfM_ContactNumber2 { get; set; }
        public string stfM_Email { get; set; }        
        public string stfM_DepartmentName { get; set; }
        public string stfM_Designation { get; set; }
        public Guid? stfM_userId { get; set; }
        public string stfM_Initials { get; set; }
        public string UserName { get; set; }
        [DataType(DataType.Password)]
        public string stfM_password { get; set; }
        public string RoleName { get; set; }
        public string LoweredRoleName { get; set; }
        public string stfM_Location { get; set; }
        public string Location { get; set; }
    }
   
}