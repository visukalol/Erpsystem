﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{

    public class ListBuyerConsigneeResp
    {
        public int clM_Id { get; set; }
        public string clM_CompanyName { get; set; }
    }

    public class ListBuyerConsigneeLocationResp
    {
        public int Id { get; set; }
        public string Location { get; set; }
    }

    public class ListUnitsResp
    {
        public Int16 unit_Id { get; set; }
        public string unit_name { get; set; }
    }

    public class ListDispatchModeResp
    {
        public int giM_Id { get; set; }
        public string giM_Name { get; set; }
    }

    public class ListDesigationResp
    {
        public int giM_Id { get; set; }
        public string giM_Name { get; set; }
        public int giM_Type { get; set; }
        public int giM_itgMId { get; set; }
    }

    public class ListContactsResp
    {
        public int cntM_Id { get; set; }
        public string cntM_ContactPerson { get; set; }
    }

    public class ListStatusResp
    {
        public int stsM_Id { get; set; }
        public string stsM_StatusName { get; set; }        
    }

    public class ListProjectResp
    {
        public int itM_ID { get; set; }
        public string itM_ItemName { get; set; }
    }
    public class ListProductResp
    {
        public int itG_ID { get; set; }
        public string itG_ItemCode { get; set; }

    }

    public class ListProductGroupResp
    {
        public int itgM_Id { get; set; }
        public string itgM_Name { get; set; }
    }

    public class ListDepartmentResp
    {
        public int stfM_Id { get; set; }
        public string stfM_DepartmentName { get; set; }
    }

    public class ListStaffResp
    {
        public int stfM_Id { get; set; }
        public string stfM_Name { get; set; }
    }

    //list for Department wise Staff
    public class ListDepartmentStaffResp
    {
        public int stfM_Id { get; set; }
        public string stfM_Name { get; set; }
        public string stfM_DepartmentName { get; set; }
    }

    public class ListRegNoResp
    {
        public int enqM_Id { get; set; }
        public string enqM_RegNo { get; set; }
    }

    public class ListDistributorResp
    {
        public int dstM_Id { get; set; }
        public string dstM_CompanyName { get; set; }
    }

    public class ListCategoryResp
    {
        public int catM_Id { get; set; }
        public string catM_Code { get; set; }
    }

    public class ListVendorResp
    {
        public int vndM_Id { get; set; }
        public string vndM_CompanyName { get; set; }
    }

    public class ListMaterialResp
    {
        public int giM_Id { get; set; }
        public string giM_Name { get; set; }
    }

    public class ListCertificateResp
    {
        public int crtD_Id { get; set; }
        public string crtD_No { get; set; }
    }

    public class ListFinanceYearResp
    {
        public int yrM_Id { get; set; }
        public string yrM_Name { get; set; }
        //public DateTime yrM_DateFrom { get; set; }
        //public DateTime yrM_DateTo { get; set; }
    }

    public class ListRolesResp
    {
        public Guid RoleId { get; set; }
        public string RoleName { get; set; }
    }

    public class ListCat1Resp
    {
        public int rawC_Id { get; set; }
        public string rawC_Name { get; set; }
    }

    public class ListCompanyResp
    {
        public int cmpM_Id { get; set; }
        public string cmpM_CompanyName { get; set; }
    }

    public class ListEnquiryResp
    {
        public int enqM_Id { get; set; }
        public string enqM_RegNo { get; set; }
    }

    public class ListQuotationResp
    {
        public string enqM_RegNo { get; set; }
        public DateTime enqM_RegDate { get; set; }
        public string enqM_TenderNo { get; set; }
        public DateTime enqM_TenderDate { get; set; }
        public DateTime enqM_ClosingDate { get; set; }
        public string enqM_ProjectName { get; set; }
    }

    public class ListCompanyCodeResp
    {
        public int clM_Id { get; set; }
        public string clM_Code { get; set; }
    }
    public class ListContactResp
    {
        public int cntM_Id { get; set; }
        public string cntM_ContactPerson { get; set; }
    }

    public class ListLocationResp
    {
        public int Id { get; set; }
        public string Location { get; set; }
    }

    public class ListQuotatiionResp
    {
        public string qtM_No { get; set; }
        public int qtM_RevNo { get; set; }
        public DateTime qtM_Date { get; set; }
        public int qtM_enqMId { get; set; }
        public int qtM_Amount { get; set; }
        public int qtM_stsMId { get; set; }
    }

    public class ListDesignationResp
    {
        public int giM_Id { get; set; }
        public string giM_Name { get; set; }
    }

  
}