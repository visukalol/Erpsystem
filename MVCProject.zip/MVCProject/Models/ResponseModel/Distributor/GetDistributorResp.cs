﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCProject.Models.ResponseModel
{
    public class GetDistributorResp
    {
        public int dstM_Id { get; set; }
        public string dstM_CompanyName { get; set; }
        public string dstM_ContactPerson { get; set; }
        public string dstM_Address { get; set; }
        public string dstM_MobileNo { get; set; }
        public string dstM_ContactNumber1 { get; set; }
        public string dstM_ContactNumber2 { get; set; }
        public string dstM_Email { get; set; }
        public string dstM_Fax { get; set; }
        public string dstM_PAN { get; set; }
        public string dstM_CST { get; set; }
        public string dstM_VAT { get; set; }
        public Boolean dstM_Type { get; set; }
        public string dstM_GSTiN { get; set; }

        public string dstM_TAN { get; set; }
        public string dstM_CIN { get; set; }
        public string dstM_City { get; set; }
        public string dstM_State { get; set; }
        public string dstM_Region { get; set; }
        public string dstM_Pincode { get; set; }
    }

    public class DistributorBankMasterReq
    {
        public int dstM_Id { get; set; }
        public string bnkM_Name { get; set; }
        public string bnkM_Branch { get; set; }
        public string bnkM_IFSC { get; set; }
        public string bnkM_AcNo { get; set; }
        public string bnkM_AcName { get; set; }
        public string bnkM_MICR { get; set; }
        public int bnkM_Id { get; set; }
    }
}